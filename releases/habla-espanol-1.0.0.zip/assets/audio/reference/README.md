Reviewed reference recordings go here, one WAV per phrase, named by the phrase slug
(see habla/voice.py `slug()`), e.g. `como_te_llamas.wav` and `como_te_llamas.slow.wav`.
`tools/generate_reference_audio.py` writes them from ElevenLabs. Any phrase without a
file is spoken by the Mac's built-in Spanish voice.
