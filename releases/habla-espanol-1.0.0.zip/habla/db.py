"""Local SQLite persistence for Habla.

Design rules (from the approved spec):
- Completion, demonstrated ability and retention are separate concepts.
- No single proficiency "level"; evidence dimensions are independent columns.
- Every resume step is saved atomically (checkpoint + module/session status
  in one transaction), so a crash can never leave them disagreeing.
- Nothing here talks to the network.
"""
from __future__ import annotations

import json
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCHEMA_VERSION = 1
SCHEMA_FILE = Path(__file__).with_name("schema.sql")

SKILLS = ("listening", "construction", "speaking", "interaction")


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


class Database:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # isolation_level=None -> we control transactions explicitly.
        self.conn = sqlite3.connect(self.path, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA synchronous = FULL")
        self.migrate()

    # ---------- infrastructure ----------
    @contextmanager
    def tx(self):
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield self.conn
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise
        else:
            self.conn.execute("COMMIT")

    def schema_version(self) -> int:
        try:
            row = self.conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            return int(row[0]) if row else 0
        except sqlite3.OperationalError:
            return 0

    def migrate(self) -> None:
        current = self.schema_version()
        if current == SCHEMA_VERSION:
            return
        if current > SCHEMA_VERSION:
            raise RuntimeError(f"Database is newer ({current}) than this app ({SCHEMA_VERSION}).")
        if current > 0 and self.path.exists():
            # Recoverable migrations: keep a copy before touching an existing DB.
            backup = self.path.with_suffix(f".v{current}.bak")
            self.backup_to(backup)
        sql = SCHEMA_FILE.read_text(encoding="utf-8")
        with self.tx() as c:
            for stmt in [s.strip() for s in sql.split(";") if s.strip()]:
                if stmt.upper().startswith("PRAGMA"):
                    continue
                c.execute(stmt)
            c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
            c.execute("INSERT OR IGNORE INTO learner(id, display_name) VALUES (1, '')")

    def backup_to(self, dest: Path | str) -> Path:
        dest = Path(dest)
        out = sqlite3.connect(dest)
        with out:
            self.conn.backup(out)
        out.close()
        return dest

    def export(self, dest: Path | str) -> Path:
        """Export all progress to a single file the learner can keep."""
        return self.backup_to(dest)

    @staticmethod
    def restore(src: Path | str, into: Path | str) -> "Database":
        """Restore from an export. Validates before replacing."""
        src, into = Path(src), Path(into)
        probe = sqlite3.connect(src)
        try:
            ok = probe.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            ver = int(probe.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0])
        finally:
            probe.close()
        if not ok or ver > SCHEMA_VERSION:
            raise ValueError("Export file is damaged or from a newer version.")
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(into) + suffix)
            if p.exists():
                p.unlink()
        shutil.copyfile(src, into)
        return Database(into)

    def close(self):
        self.conn.close()

    # ---------- learner ----------
    def learner(self) -> sqlite3.Row:
        return self.conn.execute("SELECT * FROM learner WHERE id=1").fetchone()

    def set_display_name(self, name: str) -> None:
        with self.tx() as c:
            c.execute("UPDATE learner SET display_name=? WHERE id=1", (name.strip(),))

    # ---------- completion + resume ----------
    def completed_sessions(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM session_progress WHERE status='completed'").fetchone()[0]

    def session_completed_at(self, n: int):
        """When session n was completed (aware UTC datetime), or None."""
        r = self.conn.execute("SELECT completed_at FROM session_progress WHERE session_no=? AND status='completed'",
                              (n,)).fetchone()
        if not r or not r[0]:
            return None
        dt = datetime.fromisoformat(r[0].replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)

    def session_started(self, n: int) -> bool:
        if self.module_status(n):
            return True
        cp = self.checkpoint()
        return cp is not None and cp["session_no"] == n

    def current_session(self, total: int) -> int:
        """First session not yet completed (sessions unlock in order)."""
        done = {r[0] for r in self.conn.execute(
            "SELECT session_no FROM session_progress WHERE status='completed'")}
        for n in range(1, total + 1):
            if n not in done:
                return n
        return total

    def module_status(self, session_no: int) -> dict[int, str]:
        rows = self.conn.execute(
            "SELECT module_no, status FROM module_progress WHERE session_no=?", (session_no,))
        return {r["module_no"]: r["status"] for r in rows}

    def checkpoint(self) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM resume_checkpoint WHERE id=1").fetchone()

    def save_step(self, *, curriculum_version: str, session: dict, module_no: int,
                  exercise_id: str, step_state: dict | None = None) -> None:
        """Learner is now at `exercise_id`. Atomically saves the exact resume point
        and marks the module/session in progress."""
        s = session["no"]
        now = iso(utcnow())
        with self.tx() as c:
            c.execute(
                "INSERT INTO resume_checkpoint(id,curriculum_version,session_no,module_no,exercise_id,step_state,saved_at) "
                "VALUES(1,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET curriculum_version=excluded.curriculum_version, "
                "session_no=excluded.session_no, module_no=excluded.module_no, exercise_id=excluded.exercise_id, "
                "step_state=excluded.step_state, saved_at=excluded.saved_at",
                (curriculum_version, s, module_no, exercise_id, json.dumps(step_state or {}), now))
            c.execute(
                "INSERT INTO session_progress(session_no,status,started_at) VALUES(?, 'in_progress', ?) "
                "ON CONFLICT(session_no) DO UPDATE SET status=CASE WHEN status='completed' THEN status ELSE 'in_progress' END",
                (s, now))
            c.execute(
                "INSERT INTO module_progress(session_no,module_no,status,updated_at) VALUES(?,?, 'in_progress', ?) "
                "ON CONFLICT(session_no,module_no) DO UPDATE SET "
                "status=CASE WHEN status IN ('completed','needs_review') THEN status ELSE 'in_progress' END, updated_at=excluded.updated_at",
                (s, module_no, now))

    def complete_module(self, session: dict, module_no: int, needs_review: bool = False) -> bool:
        """Marks required activities of a module done. Returns True if the whole
        session is now complete. Completion != mastery: concepts that were not
        demonstrated stay flagged via evidence/review, not here."""
        s = session["no"]
        now = iso(utcnow())
        status = "needs_review" if needs_review else "completed"
        with self.tx() as c:
            c.execute(
                "INSERT INTO module_progress(session_no,module_no,status,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(session_no,module_no) DO UPDATE SET status=excluded.status, updated_at=excluded.updated_at",
                (s, module_no, status, now))
            done = c.execute(
                "SELECT COUNT(*) FROM module_progress WHERE session_no=? AND status IN ('completed','needs_review')",
                (s,)).fetchone()[0]
            if done >= len(session["modules"]):
                c.execute(
                    "INSERT INTO session_progress(session_no,status,started_at,completed_at) VALUES(?, 'completed', ?, ?) "
                    "ON CONFLICT(session_no) DO UPDATE SET status='completed', completed_at=excluded.completed_at",
                    (s, now, now))
                c.execute("DELETE FROM resume_checkpoint WHERE id=1")
                return True
        return False

    # ---------- activity + evidence ----------
    def record_attempt(self, *, curriculum_version: str, exercise_id: str, session_no: int, module_no: int,
                       input_type: str, response_type: str, response=None, hints_used=0, replays_used=0,
                       retry_no=0, technical_status="ok", started_at: datetime | None = None,
                       evidence: list[dict] | None = None, finished_at: datetime | None = None) -> int:
        """Store one attempt and any evidence it produces, in one transaction."""
        start = started_at or utcnow()
        with self.tx() as c:
            cur = c.execute(
                "INSERT INTO attempt(curriculum_version,exercise_id,session_no,module_no,input_type,response_type,"
                "response,hints_used,replays_used,retry_no,started_at,finished_at,technical_status) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (curriculum_version, exercise_id, session_no, module_no, input_type, response_type,
                 json.dumps(response) if response is not None else None, hints_used, replays_used,
                 retry_no, iso(start), iso(finished_at or utcnow()), technical_status))
            attempt_id = cur.lastrowid
            for ev in evidence or []:
                # A technical failure is never evidence about the learner.
                outcome = ev["outcome"] if technical_status == "ok" else "unassessed"
                c.execute(
                    "INSERT INTO evidence(attempt_id,learning_target,skill,independence,transfer,retention,"
                    "delay_seconds,intervening_exposures,context,outcome,assessment_source) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (attempt_id, ev["learning_target"], ev["skill"], ev["independence"], ev["transfer"],
                     ev["retention"], ev.get("delay_seconds"), ev.get("intervening_exposures"),
                     ev.get("context"), outcome, ev["assessment_source"]))
                if outcome != "unassessed":
                    self._schedule_review(c, ev["learning_target"], ev.get("practice_type", "listen_respond"), outcome)
        return attempt_id

    @staticmethod
    def _schedule_review(c, target: str, practice_type: str, outcome: str) -> None:
        row = c.execute("SELECT interval_days, ease, due_at FROM review_item WHERE learning_target=?", (target,)).fetchone()
        interval, ease = (row["interval_days"], row["ease"]) if row else (0.0, 2.5)
        not_due_yet = bool(row) and row["due_at"] > iso(utcnow())
        if outcome == "successful":
            if not_due_yet and interval >= 1:
                return      # extra practice before it's due doesn't stretch the schedule
            interval = 1.0 if interval < 1 else min(round(interval * ease, 2), 180.0)
            ease = min(ease + 0.1, 3.0)
        elif outcome == "partial":
            interval = 1.0
        else:  # unsuccessful
            interval = 0.0  # due again today
            ease = max(ease - 0.2, 1.3)
        due = utcnow() + timedelta(days=interval)
        c.execute(
            "INSERT INTO review_item(learning_target,practice_type,due_at,interval_days,ease,last_outcome) "
            "VALUES(?,?,?,?,?,?) ON CONFLICT(learning_target) DO UPDATE SET practice_type=excluded.practice_type, "
            "due_at=excluded.due_at, interval_days=excluded.interval_days, ease=excluded.ease, last_outcome=excluded.last_outcome",
            (target, practice_type, iso(due), interval, ease, outcome))

    def review_queue(self, limit: int = 4) -> list[sqlite3.Row]:
        return list(self.conn.execute(
            "SELECT * FROM review_item ORDER BY due_at ASC LIMIT ?", (limit,)))

    def skill_summary(self) -> dict[str, dict]:
        """Per-skill description built only from evidence. No percentages."""
        out = {}
        for skill in SKILLS:
            rows = self.conn.execute(
                "SELECT independence, transfer, retention, outcome, assessment_source FROM evidence WHERE skill=?",
                (skill,)).fetchall()
            assessed = [r for r in rows if r["outcome"] != "unassessed"]
            ok = [r for r in assessed if r["outcome"] == "successful"]
            info = {"evidence": len(rows), "assessed": len(assessed), "successful": len(ok)}
            if not assessed:
                info["state"] = "participation_only" if rows else "unassessed"
            elif any(r["retention"] == "delayed" for r in ok):
                info["state"] = "retained"
            elif any(r["transfer"] == "novel" for r in ok):
                info["state"] = "transferred"
            elif any(r["independence"] == "independent" for r in ok):
                info["state"] = "independent"
            elif ok:
                info["state"] = "guided"
            else:
                info["state"] = "attempted"
            out[skill] = info
        return out

    def target_states(self, targets: list[str]) -> str:
        """Objective status from evidence on its learning targets."""
        if not targets:
            return "pending"
        q = ",".join("?" * len(targets))
        rows = self.conn.execute(
            f"SELECT independence, outcome FROM evidence WHERE learning_target IN ({q}) AND outcome='successful'",
            targets).fetchall()
        if not rows:
            return "pending"
        if any(r["independence"] == "independent" for r in rows):
            return "demonstrated"
        return "practiced"

    # ---------- queries for the app screens ----------
    def last_evidence_at(self, target: str) -> datetime | None:
        row = self.conn.execute(
            "SELECT MAX(recorded_at) FROM evidence WHERE learning_target=?", (target,)).fetchone()
        if not row or not row[0]:
            return None
        return datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)

    def due_reviews(self, limit: int = 10) -> list[sqlite3.Row]:
        return list(self.conn.execute(
            "SELECT * FROM review_item WHERE due_at <= ? ORDER BY due_at ASC LIMIT ?", (iso(utcnow()), limit)))

    def review_count_due(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM review_item WHERE due_at <= ?", (iso(utcnow()),)).fetchone()[0]

    def active_minutes(self) -> int:
        """Time spent on exercises (each attempt capped at 5 minutes)."""
        from .practice_time import total_minutes
        return total_minutes(self.conn)

    def exit_scores(self) -> dict[int, tuple[int, int]]:
        """Latest exit check per session: (correct, total) on first attempts."""
        out: dict[int, tuple[int, int]] = {}
        rows = self.conn.execute(
            "SELECT a.session_no, a.exercise_id, a.retry_no, a.id, "
            "  (SELECT MIN(CASE e.outcome WHEN 'successful' THEN 1 ELSE 0 END) FROM evidence e WHERE e.attempt_id=a.id) ok "
            "FROM attempt a WHERE a.module_no=7 AND a.exercise_id LIKE '%#i%' AND a.retry_no=0 ORDER BY a.id")
        latest: dict[tuple[int, str], int] = {}
        for r in rows:
            latest[(r["session_no"], r["exercise_id"])] = 1 if r["ok"] == 1 else 0
        for (s, _), ok in latest.items():
            c, t = out.get(s, (0, 0))
            out[s] = (c + ok, t + 1)
        return out

    def evidence_counts(self) -> dict:
        r = self.conn.execute(
            "SELECT COUNT(*) total, SUM(outcome='successful') ok, "
            "SUM(retention='delayed' AND outcome='successful') retained, "
            "SUM(independence='independent' AND outcome='successful') independent, "
            "SUM(transfer='novel' AND outcome='successful') novel FROM evidence").fetchone()
        return {k: (r[k] or 0) for k in ("total", "ok", "retained", "independent", "novel")}

    def recordings(self) -> list[sqlite3.Row]:
        return list(self.conn.execute("SELECT * FROM recording ORDER BY id"))

    def delete_recordings(self) -> None:
        with self.tx() as c:
            c.execute("DELETE FROM recording")

    def reset_progress(self) -> None:
        with self.tx() as c:
            for t in ("evidence", "attempt", "recording", "conversation_turn", "review_item", "session_progress",
                      "module_progress", "resume_checkpoint", "calibration_observation", "adaptation_decision"):
                c.execute(f"DELETE FROM {t}")
