"""Serves bundled Lucide SVG icons to QML, recolored on request.

Usage in QML: source: "image://icon/<name>/<hexcolor>"
"""
from pathlib import Path

from PySide6.QtCore import QByteArray, QSize, Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtQuick import QQuickImageProvider
from PySide6.QtSvg import QSvgRenderer


class IconProvider(QQuickImageProvider):
    def __init__(self, icon_dir: Path):
        super().__init__(QQuickImageProvider.ImageType.Image)
        self._dir = Path(icon_dir)
        self._cache: dict[str, str] = {}

    def _svg(self, name: str) -> str:
        if name not in self._cache:
            p = self._dir / f"{name}.svg"
            self._cache[name] = p.read_text(encoding="utf-8") if p.exists() else ""
        return self._cache[name]

    def requestImage(self, id_: str, size: QSize, requested: QSize) -> QImage:
        name, _, color = id_.partition("/")
        color = color or "ffffff"
        svg = self._svg(name).replace("currentColor", "#" + color[-6:])
        w = requested.width() if requested.width() > 0 else 48
        h = requested.height() if requested.height() > 0 else 48
        img = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(Qt.GlobalColor.transparent)
        if svg:
            r = QSvgRenderer(QByteArray(svg.encode("utf-8")))
            p = QPainter(img)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            r.render(p)
            p.end()
        return img


class RoundedImageProvider(QQuickImageProvider):
    """image://rounded/<relative path>?r=<radius px at requested size>

    Crops to the requested aspect (like PreserveAspectCrop) and rounds the
    corners in software, so it works on every scene-graph backend."""

    def __init__(self, base: Path):
        super().__init__(QQuickImageProvider.ImageType.Image)
        self._base = Path(base)

    def requestImage(self, id_: str, size: QSize, requested: QSize) -> QImage:
        from PySide6.QtGui import QPainterPath
        from PySide6.QtCore import QRectF
        rel, _, q = id_.partition("?")
        radius = 0.0
        for part in q.split("&"):
            if part.startswith("r="):
                radius = float(part[2:])
        src = QImage(str(self._base / rel))
        w = requested.width() if requested.width() > 0 else src.width()
        h = requested.height() if requested.height() > 0 else src.height()
        out = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
        out.fill(Qt.GlobalColor.transparent)
        if src.isNull():
            return out
        scaled = src.scaled(w, h, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
        x = (scaled.width() - w) // 2
        y = (scaled.height() - h) // 2
        p = QPainter(out)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), radius, radius)
        p.setClipPath(path)
        p.drawImage(0, 0, scaled, x, y, w, h)
        p.end()
        return out
