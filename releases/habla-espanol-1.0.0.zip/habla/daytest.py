"""End-of-day test: 30 questions built from that day's material. Pass with 90% or more
to open the next day. Every attempt draws a fresh mix: different questions, a new
order, and shuffled answer choices."""
from __future__ import annotations

import random
import re

from .checking import check_build, check_typed
from .content import personalize

QUESTIONS = 30
PASS = 0.9
# how many of each kind (filled from generated multiple choice when the day has fewer)
MIX = {"listen_reuse": 6, "build": 4, "type": 4, "es_en": 6, "en_es": 5, "listen_meaning": 5}


def _same(a: str, b: str) -> bool:
    """Same sentence, ignoring accents, capitals and punctuation."""
    import re
    import unicodedata

    def n(x):
        x = unicodedata.normalize("NFD", (x or "").lower())
        x = "".join(c for c in x if unicodedata.category(c) != "Mn")
        return re.sub(r"[^a-z0-9ñ ]+", "", x).strip()
    return bool(n(a)) and n(a) == n(b)


def _sounds(x: str) -> str:
    """Rough Mexican-Spanish sound key: silent h, b=v, s=z=soft c, y=ll."""
    k = _key(x)
    k = re.sub(r"(?<!c)h", "", k)
    k = k.replace("v", "b").replace("z", "s").replace("ll", "y")
    k = re.sub(r"c([ei])", r"s\1", k)
    return k


def _key(x: str) -> str:
    """Compare answers ignoring accents, capitals, punctuation and "…"."""
    import re
    import unicodedata
    x = unicodedata.normalize("NFD", (x or "").lower())
    x = "".join(c for c in x if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ]+", " ", x).strip()


def _items(session: dict) -> list[dict]:
    """The day's words and phrases: {es, en, targets}, without near-duplicates."""
    seen_es, seen_en, out = set(), set(), []
    for cid, c in session.get("concepts", {}).items():
        if c.get("es") and c.get("en") and _key(c["es"]) not in seen_es and _key(c["en"]) not in seen_en:
            seen_es.add(_key(c["es"])); seen_en.add(_key(c["en"]))
            out.append({"es": c["es"], "en": c["en"], "targets": [cid]})
    for p in session.get("phrases", []):
        if p.get("es") and p.get("en") and _key(p["es"]) not in seen_es and _key(p["en"]) not in seen_en:
            seen_es.add(_key(p["es"])); seen_en.add(_key(p["en"]))
            out.append({"es": p["es"], "en": p["en"], "targets": []})
    return out


def _exercises(session: dict, kind: str) -> list[dict]:
    out = []
    for m in session.get("modules", []):
        for e in m.get("exercises", []):
            if e.get("type") == kind:
                out.append(e)
            if e.get("type") == "exit":
                out += [it for it in e.get("items", []) if it.get("type") == kind]
    return out


def _choice(rng, prompt, correct, distractors, audio="", show_text=True, targets=None, skill="listening", extra=""):
    """A multiple-choice question with the options shuffled."""
    opts, keys = [correct], {_key(correct)}
    for d in distractors:                      # no two choices that read the same
        if len(opts) == 4:
            break
        if d and _key(d) not in keys:
            keys.add(_key(d)); opts.append(d)
    rng.shuffle(opts)
    return {"kind": "choice", "prompt": prompt, "audio": audio, "show_text": show_text, "options": opts,
            "answer": opts.index(correct), "targets": targets or [], "skill": skill, "extra": extra}


def build(cur, n: int, name: str, rng: random.Random | None = None) -> list[dict]:
    rng = rng or random.Random()
    s = cur.sessions[n]
    items = _items(s)
    # distractor pools: this day first, then earlier days
    earlier = [it for k in range(1, n) for it in _items(cur.sessions[k])]           # all earlier days: more same-shape wrong answers
    pairs = items + earlier
    today = {id(x) for x in items}

    def mc(it, field):
        """(the item asked, shown right answer, wrong answers) with matching shapes."""
        from .distractors import pick, simplify
        one = simplify(it, rng)
        shown, wrong = pick(one, pairs, field, rng, same_group=lambda x: id(x) in today, original=it)
        return one, shown, wrong

    qs: list[dict] = []
    # reused listening questions, with their options reshuffled
    lc = _exercises(s, "listen_choose")
    rng.shuffle(lc)
    used = 0
    for e in lc:
        if used >= MIX["listen_reuse"]:
            break
        correct = e["options"][e["answer"]]
        audio, show = e.get("audio", ""), bool(e.get("show_text"))
        prompt = e.get("prompt", "")
        if any(_same(audio, o) for o in e["options"]):
            if re.search(r"did you hear|you heard|^listen|escuchaste", prompt, re.I):
                show = False                  # a real listening question: play it, never show it
                if any(_sounds(o) == _sounds(correct) for o in e["options"] if not _same(o, correct)):
                    continue                  # e.g. Hola / Ola sound the same: not fair by ear
            elif re.search(r"[\"“”']", prompt):
                audio, show = "", False       # "Which sentence means '…'?": hearing it would give it away
            else:
                continue
        used += 1
        qs.append(_choice(rng, e.get("prompt", "Listen and choose."), correct,
                          [o for i, o in enumerate(e["options"]) if i != e["answer"]],   # its own choices only, reshuffled
                          audio=audio, show_text=show, targets=e.get("targets", [])))
    # build a sentence: tiles shuffled
    bl = _exercises(s, "build")
    rng.shuffle(bl)
    for e in bl[:MIX["build"]]:
        tiles = list(e["tiles"])
        rng.shuffle(tiles)
        qs.append({"kind": "build", "prompt": e.get("prompt", "Build the sentence."), "tiles": tiles,
                   "answer_tiles": e["answer"], "alts": e.get("alt_answers") or [], "targets": e.get("targets", []),
                   "skill": "construction"})
    # type it
    ty = _exercises(s, "type")
    rng.shuffle(ty)
    for e in ty[:MIX["type"]]:
        qs.append({"kind": "type", "prompt": e.get("prompt", "Type it in Spanish."), "accept": e.get("accept", []),
                   "model": e.get("model", (e.get("accept") or [""])[0]), "hint": e.get("hint", ""),
                   "targets": e.get("targets", []), "skill": "construction"})

    # generated multiple choice from the day's words and phrases
    def es_en(it):
        one, shown, wrong = mc(it, "en")
        return _choice(rng, "What does this mean?", shown, wrong, audio=one["es"],
                       show_text=True, targets=it["targets"], skill="listening", extra=one["es"])

    def en_es(it):
        one, shown, wrong = mc(it, "es")
        return _choice(rng, f"How do you say: “{one['en']}”?", shown, wrong,
                       targets=it["targets"], skill="construction")

    def listen_meaning(it):
        one, shown, wrong = mc(it, "en")
        return _choice(rng, "Listen. What did you hear?", shown, wrong, audio=one["es"],
                       show_text=False, targets=it["targets"], skill="listening")

    gens = [("es_en", es_en), ("en_es", en_es), ("listen_meaning", listen_meaning)]
    for key, fn in gens:
        picks = list(items)
        rng.shuffle(picks)
        for it in picks[:MIX[key]]:
            qs.append(fn(it))
    # top up to 30 with more generated questions (any direction), avoiding exact repeats
    seen = {(q["kind"], q.get("prompt"), q.get("extra"), q.get("audio"), str(q.get("options"))) for q in qs}
    tries = 0
    while len(qs) < QUESTIONS and items and tries < 400:
        tries += 1
        key, fn = rng.choice(gens)
        q = fn(rng.choice(items))
        sig = (q["kind"], q.get("prompt"), q.get("extra"), q.get("audio"), str(sorted(q["options"])))
        if sig in seen:
            continue
        seen.add(sig)
        qs.append(q)
    rng.shuffle(qs)
    qs = qs[:QUESTIONS]
    for k, q in enumerate(qs):
        q["no"] = k + 1
    return personalize(qs, name) if name else qs


def grade(q: dict, response, name: str = "") -> dict:
    """{correct, review}: review=True when a typed answer needs the learner's own check."""
    if q["kind"] == "choice":
        i = int(response)
        same = 0 <= i < len(q["options"]) and _key(q["options"][i]) == _key(q["options"][q["answer"]])
        return {"correct": i == q["answer"] or same, "review": False}    # a twin that differs only by punctuation counts
    if q["kind"] == "build":
        ans = q["answer_tiles"]
        ok = check_build(list(response), ans, q.get("alts")) or (
            bool(name) and check_build(list(response), personalize(ans, name), personalize(q.get("alts") or [], name)))
        return {"correct": ok, "review": False}
    res = check_typed(str(response), personalize(q.get("accept", []), name) if name else q.get("accept", []))
    if res["correct"]:
        return {"correct": True, "review": False}
    # not in the accepted answers: could still be right in other words, so the learner compares with the model
    return {"correct": False, "review": not res.get("meaning_note") and bool(str(response).strip())}


def public(q: dict) -> dict:
    """What the screen needs (no answers)."""
    keep = ("no", "kind", "prompt", "audio", "show_text", "options", "tiles", "hint", "extra")
    return {k: q[k] for k in keep if k in q}
