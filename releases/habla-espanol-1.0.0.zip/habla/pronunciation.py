"""Transcribe a spoken attempt and rate the pronunciation with Azure Speech.

Uses the same Azure Speech resource (key in the Keychain, region in Settings)
as the realistic voices. The clip is sent once to Microsoft's speech-to-text
REST API with Pronunciation Assessment against the exercise's phrase; nothing
else leaves the Mac. Free tier (F0) includes 5 audio hours a month.
"""
from __future__ import annotations

import base64
import re
import io
import json
import urllib.error
import wave
from pathlib import Path

import numpy as np
from . import usage
from PySide6.QtCore import Property, QObject, QThread, Signal, Slot

from . import azure_voices as az

LANG = "es-MX"
RATE = 16000

# Score bands for the 0-100 pronunciation score (Azure's PronScore).
BANDS = [(85, "Excellent", "successful"), (70, "Good", "successful"),
         (50, "Getting there", "partial"), (0, "Keep practicing", "unsuccessful")]


# ---------- pure helpers (unit-tested) ----------
def to_wav16k(samples: np.ndarray, rate: int) -> bytes:
    """Mono float samples at any rate -> 16 kHz 16-bit mono WAV bytes (what Azure expects)."""
    if rate != RATE and samples.size:
        n = max(1, int(round(samples.size * RATE / rate)))
        samples = np.interp(np.linspace(0, samples.size - 1, n), np.arange(samples.size), samples)
    pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def read_wav(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path)) as w:
        rate, ch, width = w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    if width != 2:
        raise ValueError("Expected 16-bit audio")
    a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    if ch > 1:
        a = a[: len(a) - len(a) % ch].reshape(-1, ch).mean(axis=1)
    return a, rate


def band(score: float) -> tuple[str, str]:
    """(label, evidence outcome) for a 0-100 score."""
    for floor, label, outcome in BANDS:
        if score >= floor:
            return label, outcome
    return BANDS[-1][1], BANDS[-1][2]


def _pa(d: dict) -> dict:
    """Scores sit either at the top level or under 'PronunciationAssessment', depending on API version."""
    return d.get("PronunciationAssessment") or d


def parse_result(data: dict) -> dict:
    status = data.get("RecognitionStatus", "")
    if status != "Success" or not data.get("NBest"):
        return {"ok": False, "heard": "",
                "error": "Habla didn't hear any speech. Get a little closer to the microphone and try again."
                if status in ("NoMatch", "InitialSilenceTimeout", "BabbleTimeout", "") else
                f"Azure couldn't process the audio ({status})."}
    best = data["NBest"][0]
    s = _pa(best)
    score = float(s.get("PronScore", s.get("AccuracyScore", 0)) or 0)
    label, outcome = band(score)
    words = []
    for w in best.get("Words", []):
        ws = _pa(w)
        words.append({"word": w.get("Word", ""), "accuracy": round(float(ws.get("AccuracyScore", 0) or 0)),
                      "error": ws.get("ErrorType", "None") or "None"})
    heard = best.get("Display") or data.get("DisplayText") or best.get("Lexical", "")
    return {"ok": True, "heard": heard, "score": round(score), "label": label, "outcome": outcome,
            "accuracy": round(float(s.get("AccuracyScore", 0) or 0)),
            "fluency": round(float(s.get("FluencyScore", 0) or 0)),
            "completeness": round(float(s.get("CompletenessScore", 0) or 0)),
            "words": words, "error": ""}


# ---------- one-sentence tip ----------
_VOWELS = "aeiouáéíóú"


def _sound_hint(word: str) -> str:
    """The Spanish sound in this word that English speakers most often miss."""
    w = word.lower().strip("¿¡?!.,;:\"'«»")
    q = f"“{word.strip('¿¡?!.,;:')}”"
    if "rr" in w or w.startswith("r"):
        return f"roll the r in {q}: let the tip of your tongue flutter behind your top teeth"
    if re.search(r"[" + _VOWELS + r"]r|r[" + _VOWELS + r"]", w) or "r" in w:
        return f"tap the r in {q} once, quickly, like the tt in American “butter”"
    if "j" in w or re.search(r"g[eiéí]", w) or w in ("méxico", "mexico", "oaxaca"):
        return f"make the j sound in {q} a breathy h from the back of your throat"
    if "ll" in w or re.search(r"(^|[" + _VOWELS + r"])y[" + _VOWELS + r"]", w):
        return f"say the ll/y in {q} like the y in “yes”"
    if "ñ" in w:
        return f"say the ñ in {q} like the ny in “canyon”"
    if w.startswith("h"):
        return f"keep the h in {q} silent"
    if re.search(r"[" + _VOWELS + r"]d[" + _VOWELS + r"]|d$", w):
        return f"soften the d in {q}, almost like the th in “this”"
    if "qu" in w or re.search(r"gu[eiéí]", w):
        return f"keep the u silent in {q}"
    if "v" in w:
        return f"say the v in {q} like a soft b, lips barely touching"
    if "z" in w or re.search(r"c[eiéí]", w):
        return f"say the z/c in {q} like an s"
    acc = re.search(r"[áéíóú]", w)
    if acc:
        return f"lean on the {acc.group()} in {q}, that's the stressed syllable"
    return f"keep the vowels in {q} short and pure (o isn't “oh-oo”, e isn't “ay”)"


def make_tip(res: dict) -> str:
    """One sentence on the single most useful thing to fix next."""
    if not res.get("ok"):
        return ""
    words = [w for w in res.get("words", []) if w.get("word")]
    skipped = [w["word"] for w in words if w.get("error") == "Omission"]
    said = [w for w in words if w.get("error") not in ("Omission", "Insertion")]
    weakest = min(said, key=lambda w: w["accuracy"]) if said else None
    flu, acc = res.get("fluency", 100), res.get("accuracy", 100)
    if skipped:
        miss = ", ".join(f"“{x}”" for x in skipped[:2])
        return f"You left out {miss}; play the slow version and say every word, even if it takes longer."
    word_tip = _sound_hint(weakest["word"]) if weakest and weakest["accuracy"] < 85 else ""
    if flu < 80 and word_tip:
        return f"Say it as one smooth phrase without stopping between words, and {word_tip}."
    if flu < 80:
        return "Say it as one smooth phrase without stopping between words; listen once, then match the normal-speed audio."
    if word_tip:
        return word_tip[0].upper() + word_tip[1:] + "."
    if acc >= 90 and flu >= 90:
        return "Sounds great. To sound even more natural, match the rhythm of the normal-speed audio."
    return "Nice and clear. Try it a little faster, linking the words together like the normal-speed audio."


def _sound_hint_en(word: str) -> str:
    """For a Spanish speaker saying an English word: the usual trouble spot, in Spanish."""
    w = word.lower().strip("?!.,;:\"'")
    q = f"“{word.strip('?!.,;:')}”"
    if "th" in w:
        return f"en {q}, pon la punta de la lengua entre los dientes para la th"
    if re.match(r"s[ptkcmnlw]", w):
        return f"empieza {q} directo con la s, sin decir “es-” antes"
    if "v" in w:
        return f"en {q}, la v se hace con los dientes de arriba sobre el labio de abajo, no como b"
    if w.startswith("h"):
        return f"la h de {q} suena: un soplido suave, como una j muy ligera"
    if w.startswith(("j", "y")):
        return f"en {q}, la {w[0]} inicial suena como “ye” suave (y como en “yes”)"
    if "ee" in w or "ea" in w:
        return f"alarga la i en {q}: “iii”, más larga que en español"
    if re.search(r"[bcdfgkmnpstvz]$", w) and len(w) > 2:
        return f"termina {q} con su última consonante bien clara: “{w[-1]}”"
    if "w" in w:
        return f"la w de {q} suena como “gu” suave, con los labios redondos"
    return f"di {q} más relajado: en inglés las vocales sin acento se dicen cortitas"


def make_tip_es(res: dict) -> str:
    """One sentence, in Spanish, for a Spanish speaker practicing English."""
    if not res.get("ok"):
        return ""
    words = [w for w in res.get("words", []) if w.get("word")]
    skipped = [w["word"] for w in words if w.get("error") == "Omission"]
    said = [w for w in words if w.get("error") not in ("Omission", "Insertion")]
    weakest = min(said, key=lambda w: w["accuracy"]) if said else None
    flu, acc = res.get("fluency", 100), res.get("accuracy", 100)
    if skipped:
        return "Te faltó " + ", ".join(f"“{x}”" for x in skipped[:2]) + "; escúchalo despacio y di cada palabra."
    hint = _sound_hint_en(weakest["word"]) if weakest and weakest["accuracy"] < 85 else ""
    if flu < 80 and hint:
        return f"Dilo como una sola frase, sin pausas entre palabras, y {hint}."
    if flu < 80:
        return "Dilo como una sola frase, sin pausas entre palabras."
    if hint:
        return hint[0].upper() + hint[1:] + "."
    if acc >= 90 and flu >= 90:
        return "¡Suena muy bien! Para sonar más natural, une las palabras como en el audio."
    return "Muy claro. Intenta decirlo un poco más rápido, uniendo las palabras."


def assess(key: str, region: str, wav: bytes, reference: str, lang: str = "") -> dict:
    """reference = the phrase to say (scripted), or "" to rate free speech (unscripted)."""
    cfg = {"ReferenceText": reference, "GradingSystem": "HundredMark", "Granularity": "Word",
           "Dimension": "Comprehensive", "EnableMiscue": bool(reference)}
    url = (f"https://{region}.stt.speech.microsoft.com/speech/recognition/conversation/"
           f"cognitiveservices/v1?language={lang or LANG}&format=detailed")
    try:
        with az._request(url, key, wav, {
                "Content-Type": f"audio/wav; codecs=audio/pcm; samplerate={RATE}",
                "Accept": "application/json",
                "Pronunciation-Assessment": base64.b64encode(json.dumps(cfg).encode()).decode()}, timeout=30) as r:
            res = parse_result(json.loads(r.read().decode("utf-8")))
            res["tip"] = make_tip_es(res) if (lang or LANG).startswith("en") else make_tip(res)
            return res
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"ok": False, "heard": "", "error": "Azure rejected the key. Check it in Settings › Realistic voices."}
        if e.code == 429:
            return {"ok": False, "heard": "", "error": "Azure is busy (free-tier limit). Wait a few seconds and try again."}
        return {"ok": False, "heard": "", "error": f"Azure returned an error ({e.code})."}
    except (urllib.error.URLError, TimeoutError, OSError):
        return {"ok": False, "heard": "", "error": "Couldn't reach Azure. Check your internet connection and try again."}


# ---------- Qt controller ----------
class _Worker(QThread):
    result = Signal("QVariantMap")

    def __init__(self, key, region, path: Path, reference: str, lang: str = ""):
        super().__init__()
        self.key, self.region, self.path, self.reference, self.lang = key, region, Path(path), reference, lang

    def run(self):
        try:
            samples, rate = read_wav(self.path)
            usage.add_stt(len(samples) / max(1, rate))      # Azure counts seconds of audio
            res = assess(self.key, self.region, to_wav16k(samples, rate), self.reference, self.lang)
            res["free"] = not self.reference
        except Exception as e:      # never let a bad file crash the app
            res = {"ok": False, "heard": "", "error": f"Couldn't check this take ({e})."}
        self.result.emit(res)


class SpeechCheck(QObject):
    """Exposed to QML as `speech`. After each take: transcript + pronunciation rating."""
    changed = Signal()
    rated = Signal("QVariantMap")          # AppState stores the evidence

    def __init__(self, audio, recordings_dir: Path, settings, parent=None):
        super().__init__(parent)
        self._dir = Path(recordings_dir)
        self._settings = settings
        self._ref = ""
        self._state = "idle"               # idle | checking | done | error
        self._res: dict = {}
        self._worker = None
        self._free = False
        self._lang = ""                     # "" = Mexican Spanish
        self._record = True                 # False for date night: nothing is kept
        self._last: Path | None = None      # kept only so the take can be re-rated
        audio.recordingSaved.connect(self._on_saved)

    state = Property(str, lambda self: self._state, notify=changed)
    result = Property("QVariantMap", lambda self: self._res, notify=changed)
    free = Property(bool, lambda self: self._free, notify=changed)
    configured = Property(bool, lambda self: bool(self._key() and self._region()), notify=changed)

    def _key(self):
        return az.keychain_get()

    def _region(self):
        return str(self._settings.value("azure_region", "") or "") if self._settings is not None else ""

    def _drop_take(self):
        if self._last is not None:
            try:
                self._last.unlink()
            except OSError:
                pass
            self._last = None

    @Slot(str, bool)
    def setReference(self, text: str, free: bool):
        """A speaking exercise opened. free=True rates whatever you say (your own words)."""
        self._drop_take()
        self._ref, self._free, self._state, self._res = text, free, "idle", {}
        self._lang, self._record = "", True
        self.changed.emit()

    @Slot(str, str)
    def setPracticeReference(self, text: str, lang: str):
        """Date night: rate this phrase in this language ("es-MX" or "en-US"); not saved as progress."""
        self._drop_take()
        self._ref, self._free, self._state, self._res = text, False, "idle", {}
        self._lang, self._record = lang, False
        self.changed.emit()

    @Slot()
    def setLabReply(self):
        """Conversation Lab: transcribe whatever the learner says as his reply; not saved as lesson progress."""
        self._drop_take()
        self._ref, self._free, self._state, self._res = "(reply)", True, "idle", {}
        self._lang, self._record = "", False
        self.changed.emit()

    @Slot(bool)
    def setFree(self, free: bool):
        """Switch between 'say this phrase' and 'my own words'; re-rates the last take."""
        if free == self._free:
            return
        self._free = free
        self.changed.emit()
        if self._last is not None and self._last.exists() and self._state != "checking":
            self._check(self._last)

    def _on_saved(self, name: str, duration_ms: int, rate: int, tech: str):
        if tech != "ok" or not name or not self._ref:
            return
        self._drop_take()
        self._last = self._dir / name
        self._check(self._last)

    def _check(self, path: Path):
        key, region = self._key(), self._region()
        if not key or not region:
            self._state = "error"
            self._res = {"ok": False, "error": "To get a transcript and a rating, add your Azure Speech key in "
                                               "Settings › Realistic voices (the same key works for both)."}
            self.changed.emit()
            return
        self._state, self._res = "checking", {}
        self.changed.emit()
        w = _Worker(key, region, path, "" if self._free else self._ref, self._lang)
        w.result.connect(self._on_result)
        w.finished.connect(w.deleteLater)
        self._worker = w
        w.start()

    def _on_result(self, res: dict):
        self._res = dict(res)
        self._state = "done" if res.get("ok") else "error"
        self.changed.emit()
        if res.get("ok") and self._record:
            self.rated.emit(self._res)

    def shutdown(self):
        """App quitting: the take was only needed for rating."""
        self._drop_take()
