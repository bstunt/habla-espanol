"""Reference playback + microphone capture for the listening/speaking lab.

States (from the spec): unavailable, permission_required, ready, recording,
processing, saved, playback, failed.

Everything here is local: bundled reference files in, WAV files out.
Recording is never treated as a pronunciation assessment.
"""
from __future__ import annotations

import os
import time
import wave
from pathlib import Path

import numpy as np
from PySide6.QtCore import Property, QObject, QTimer, QUrl, Signal, Slot

STATE_LABELS = {
    "unavailable": "Microphone unavailable",
    "permission_required": "Permission needed",
    "ready": "Ready — press the mic and speak",
    "recording": "Listening…",
    "processing": "Processing…",
    "saved": "Got it",
    "playback": "Playing",
    "failed": "Couldn't hear you",
}

MIN_SECONDS = 0.35
SILENCE_PEAK = 1e-4   # full-scale float; macOS feeds pure zeros when access is denied


# ---------- pure helpers (unit-tested without audio hardware) ----------
def pcm_to_float(raw: bytes, sample_format: str, channels: int) -> np.ndarray:
    """Interleaved PCM bytes -> mono float32 in [-1, 1]."""
    if sample_format == "Int16":
        a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    elif sample_format == "Int32":
        a = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
    elif sample_format == "Float":
        a = np.frombuffer(raw, dtype="<f4").astype(np.float32)
    elif sample_format == "UInt8":
        a = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    else:
        raise ValueError(f"Unsupported sample format {sample_format}")
    if channels > 1:
        usable = len(a) - len(a) % channels
        a = a[:usable].reshape(-1, channels).mean(axis=1)
    return a


def level(chunk: np.ndarray) -> float:
    """0..1 loudness for the input meter (RMS, gently compressed)."""
    if chunk.size == 0:
        return 0.0
    rms = float(np.sqrt(np.mean(chunk ** 2)))
    return min(1.0, (rms * 8) ** 0.6)


def classify_capture(samples: np.ndarray, rate: int) -> tuple[str, str]:
    """Decide if a capture is usable. Returns (status, reason).
    A technical failure must never be recorded as a learner failure."""
    seconds = samples.size / float(rate) if rate else 0
    if seconds < MIN_SECONDS:
        return "capture_failed", "That was too short to hear. Try again and say the whole phrase."
    if float(np.max(np.abs(samples))) < SILENCE_PEAK:
        return "capture_failed", ("No sound reached the microphone. Check the permission in "
                                  "System Settings › Privacy & Security › Microphone.")
    return "ok", ""


def write_wav(path: Path, samples: np.ndarray, rate: int) -> None:
    pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".part")
    with wave.open(str(tmp), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    os.replace(tmp, path)   # atomic: never leave a half-written file


class EndPointer:
    """Decides when the speaker has finished, from the loudness of incoming audio.

    Learns the background noise during the first moments, waits for speech to
    start, then reports "done" after `silence_ms` of quiet. If no speech ever
    starts, gives up after `no_speech_ms`.
    """
    CALIBRATE_MS = 300
    MIN_SPEECH_MS = 250

    def __init__(self, silence_ms: int = 1200, no_speech_ms: int = 8000):
        self.silence_ms, self.no_speech_ms = silence_ms, no_speech_ms
        self.t = 0.0                 # ms of audio seen
        self.floor = None            # background RMS
        self._cal: list[float] = []
        self.speech_ms = 0.0
        self.quiet_ms = 0.0
        self.started = False

    def feed(self, rms: float, ms: float) -> bool:
        """Add one chunk (its RMS and length). Returns True when recording should stop."""
        self.t += ms
        if self.t <= self.CALIBRATE_MS:
            self._cal.append(rms)
            return False
        if self.floor is None:
            self.floor = float(np.median(self._cal)) if self._cal else 0.0
        speak_th = max(0.02, self.floor * 3.0)
        quiet_th = max(0.012, self.floor * 1.8)
        if rms >= speak_th:
            self.speech_ms += ms
            self.quiet_ms = 0.0
            if self.speech_ms >= self.MIN_SPEECH_MS:
                self.started = True
        elif rms < quiet_th:
            self.quiet_ms += ms
            if not self.started:
                self.speech_ms = 0.0            # a cough or click isn't speech
        if self.started:
            return self.quiet_ms >= self.silence_ms
        return self.t >= self.no_speech_ms


# ---------- Qt controller ----------
class AudioController(QObject):
    changed = Signal()
    playbackFinished = Signal()    # a say()/compare() sequence has finished
    recordingSaved = Signal(str, int, int, str)   # file name, duration ms, rate, technical status

    def __init__(self, reference_dir: Path, recordings_dir: Path, enabled: bool = True, voice=None,
                 voices_dir: Path | None = None, settings=None, parent=None, bundled_dir: Path | None = None):
        super().__init__(parent)
        # voices packed inside the app, then downloaded voices, then bundled reference recordings
        self._ref_dirs = [Path(d) for d in (bundled_dir, voices_dir, reference_dir) if d]
        self._voice = voice
        if voice is not None:
            voice.finished.connect(self._on_voice_finished)
        self._ref = Path(reference_dir)
        self._rec_dir = Path(recordings_dir)
        self._enabled = enabled
        self._state = "unavailable"
        self._detail = ""
        self._level = 0.0
        self._duration_ms = 0
        self._last_file: Path | None = None
        self._buf = bytearray()
        self._source = None
        self._io = None
        self._fmt_name = "Int16"
        self._channels = 1
        self._rate = 48000
        self._queue: list[Path] = []
        self._t0 = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(100)
        self._timer.timeout.connect(self._tick)
        self._player = None
        self._probe = None
        self._settings = settings
        self._mic_id = str(settings.value("microphone", "") or "") if settings is not None else ""
        self._monitor = None
        self._monitor_io = None
        self._auto_stop = (str(settings.value("auto_stop", "true")).lower() != "false") if settings is not None else True
        self._pause_ms = 1200
        self._ep: EndPointer | None = None
        self._monitor_fmt = ("Int16", 1)
        if enabled:
            from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer
            self._devices = QMediaDevices(self)
            self._devices.audioInputsChanged.connect(self._on_inputs_changed)
            self._out = QAudioOutput(self)
            self._player = QMediaPlayer(self)
            self._player.setAudioOutput(self._out)
            self._player.mediaStatusChanged.connect(self._on_media_status)
            self._player.errorOccurred.connect(lambda *_: self._set("failed", "Couldn't play the audio."))
        self.refresh()

    # ---- QML properties ----
    def _get_state(self): return self._state
    def _get_label(self): return STATE_LABELS.get(self._state, self._state)
    def _get_detail(self): return self._detail
    def _get_level(self): return self._level
    def _get_duration(self): return self._duration_ms
    def _get_has(self): return self._last_file is not None and self._last_file.exists()

    state = Property(str, _get_state, notify=changed)
    stateLabel = Property(str, _get_label, notify=changed)
    detail = Property(str, _get_detail, notify=changed)
    level = Property(float, _get_level, notify=changed)
    durationMs = Property(int, _get_duration, notify=changed)
    hasRecording = Property(bool, _get_has, notify=changed)

    # ---- microphone choice ----
    def _inputs(self):
        if not self._enabled:
            return []
        from PySide6.QtMultimedia import QMediaDevices
        return list(QMediaDevices.audioInputs())

    @staticmethod
    def _dev_id(dev) -> str:
        return bytes(dev.id().data()).hex()

    def _input_device(self):
        """The microphone chosen in Settings, or the Mac's default if it isn't connected."""
        from PySide6.QtMultimedia import QMediaDevices
        if self._mic_id:
            for d in self._inputs():
                if self._dev_id(d) == self._mic_id:
                    return d
        return QMediaDevices.defaultAudioInput()

    def _get_input_names(self):
        from PySide6.QtMultimedia import QMediaDevices
        default = QMediaDevices.defaultAudioInput() if self._enabled else None
        first = "Mac default" + (f" ({default.description()})" if default is not None and not default.isNull() else "")
        return [first] + [d.description() for d in self._inputs()]

    def _get_input_index(self):
        if self._mic_id:
            for i, d in enumerate(self._inputs()):
                if self._dev_id(d) == self._mic_id:
                    return i + 1
        return 0

    def _get_input_missing(self):
        return bool(self._mic_id) and self._get_input_index() == 0

    def _get_monitoring(self):
        return self._monitor is not None

    def _get_auto_stop(self):
        return self._auto_stop

    autoStop = Property(bool, _get_auto_stop, notify=changed)

    @Slot(bool)
    def setAutoStop(self, on: bool):
        self._auto_stop = on
        if self._settings is not None:
            self._settings.setValue("auto_stop", "true" if on else "false")
        self.changed.emit()

    @Slot(int)
    def setPauseMs(self, ms: int):
        """How long a pause ends the take (longer when speaking freely)."""
        self._pause_ms = ms

    inputNames = Property("QVariantList", _get_input_names, notify=changed)
    inputIndex = Property(int, _get_input_index, notify=changed)
    inputMissing = Property(bool, _get_input_missing, notify=changed)
    monitoring = Property(bool, _get_monitoring, notify=changed)

    @Slot(int)
    def setInput(self, index: int):
        """0 = follow the Mac's default; otherwise an entry of inputNames."""
        devs = self._inputs()
        self._mic_id = self._dev_id(devs[index - 1]) if 0 < index <= len(devs) else ""
        if self._settings is not None:
            self._settings.setValue("microphone", self._mic_id)
        was = self._monitor is not None
        self.stopMonitor()
        self.refresh()
        if was:
            self.startMonitor()
        self.changed.emit()

    def _on_inputs_changed(self):
        if self._monitor is not None:
            self.stopMonitor()
        self.refresh()
        self.changed.emit()

    @Slot()
    def startMonitor(self):
        """Live input meter for Settings, so you can see which microphone hears you."""
        if not self._enabled or self._monitor is not None or self._state == "recording":
            return
        from PySide6.QtMultimedia import QAudioSource
        dev = self._input_device()
        if dev.isNull():
            return
        fmt = dev.preferredFormat()
        self._monitor_fmt = (fmt.sampleFormat().name, fmt.channelCount())
        self._monitor = QAudioSource(dev, fmt, self)
        self._monitor_io = self._monitor.start()
        if self._monitor_io is None:
            self._monitor = None
            return
        self._monitor_io.readyRead.connect(self._on_monitor_data)
        self.changed.emit()

    def _on_monitor_data(self):
        if self._monitor_io is None:
            return
        data = bytes(self._monitor_io.readAll().data())
        try:
            self._level = level(pcm_to_float(data[-4096:], *self._monitor_fmt))
        except ValueError:
            self._level = 0.0
        self.changed.emit()

    @Slot()
    def stopMonitor(self):
        if self._monitor is not None:
            self._monitor.stop()
            self._monitor = None
            self._monitor_io = None
            self._level = 0.0
            self.changed.emit()

    def _set(self, state: str, detail: str = ""):
        self._state, self._detail = state, detail
        self.changed.emit()

    # ---- availability + permission ----
    @Slot()
    def refresh(self):
        if self._state in ("recording", "processing"):
            return
        if not self._enabled:
            self._set("unavailable", "Audio is turned off in this environment.")
            return
        from PySide6.QtCore import QCoreApplication, QMicrophonePermission, Qt
        from PySide6.QtMultimedia import QMediaDevices
        if self._input_device().isNull():
            self._set("unavailable", "Connect a microphone to practice pronunciation. You can continue with the other activities.")
            return
        status = QCoreApplication.instance().checkPermission(QMicrophonePermission())
        if status == Qt.PermissionStatus.Granted:
            self._set("ready", "Press the button and say the phrase out loud.")
        elif status == Qt.PermissionStatus.Denied:
            self._set("permission_required", "Microphone access is blocked. Turn it on in System Settings › Privacy & Security › Microphone.")
        else:
            self._set("permission_required", "Habla needs your permission to use the microphone so it can hear and rate what you say.")

    @Slot()
    def requestPermission(self):
        if not self._enabled:
            return
        from PySide6.QtCore import QCoreApplication, QMicrophonePermission
        QCoreApplication.instance().requestPermission(QMicrophonePermission(), self, lambda _p: self.refresh())
        self._probe_microphone()

    def _probe_microphone(self):
        """Open the input device for a moment. On macOS this makes the system show its
        own microphone prompt even if Qt's permission request couldn't."""
        from PySide6.QtMultimedia import QAudioSource, QMediaDevices
        dev = self._input_device()
        if dev.isNull():
            return
        self._probe = QAudioSource(dev, dev.preferredFormat(), self)
        self._probe.start()
        self._set("permission_required", "Look for the macOS prompt and click Allow. "
                  "If none appears, open System Settings › Privacy & Security › Microphone and turn on Habla.")

        def done():
            if self._probe is not None:
                self._probe.stop()
                self._probe = None
            msg = self._detail
            self.refresh()
            if self._state == "permission_required":
                self._set("permission_required", msg)   # keep the guidance while the prompt is up
        QTimer.singleShot(1500, done)

    # ---- recording ----
    @Slot()
    def startRecording(self):
        if not self._enabled or self._state not in ("ready", "saved", "failed", "playback"):
            return
        from PySide6.QtMultimedia import QAudioFormat, QAudioSource, QMediaDevices
        if self._player:
            self._player.stop()
        self.stopMonitor()
        dev = self._input_device()
        fmt = QAudioFormat()
        fmt.setSampleRate(48000)
        fmt.setChannelCount(1)
        fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
        if not dev.isFormatSupported(fmt):
            fmt = dev.preferredFormat()
        self._fmt_name = fmt.sampleFormat().name
        self._channels = fmt.channelCount()
        self._rate = fmt.sampleRate()
        self._buf = bytearray()
        self._source = QAudioSource(dev, fmt, self)
        self._io = self._source.start()
        if self._io is None:
            self._set("failed", "Couldn't open the microphone.")
            return
        self._io.readyRead.connect(self._on_data)
        self._t0 = time.monotonic()
        self._duration_ms = 0
        self._ep = EndPointer(self._pause_ms) if self._auto_stop else None
        self._timer.start()
        self._set("recording", "Say it now. Habla stops when you finish." if self._auto_stop
                  else "Say the phrase. Press again to stop.")

    def _on_data(self):
        data = bytes(self._io.readAll().data())
        self._buf.extend(data)
        try:
            chunk = pcm_to_float(data, self._fmt_name, self._channels)
        except ValueError:
            self._level = 0.0
            return
        self._level = level(chunk[-2048:])
        if self._ep is not None and chunk.size and self._rate:
            rms = float(np.sqrt(np.mean(chunk ** 2)))
            if self._ep.feed(rms, chunk.size * 1000.0 / self._rate):
                QTimer.singleShot(0, self.stopRecording)   # finished speaking

    def _tick(self):
        self._duration_ms = int((time.monotonic() - self._t0) * 1000)
        self.changed.emit()
        if self._duration_ms > 30000:   # safety cap for a single phrase
            self.stopRecording()

    @Slot()
    def stopRecording(self):
        if self._state != "recording":
            return
        self._timer.stop()
        self._source.stop()
        self._level = 0.0
        self._set("processing")
        try:
            samples = pcm_to_float(bytes(self._buf), self._fmt_name, self._channels)
        except ValueError as e:
            self._set("failed", str(e))
            self.recordingSaved.emit("", 0, self._rate, "capture_failed")
            return
        status, reason = classify_capture(samples, self._rate)
        self._duration_ms = int(samples.size * 1000 / self._rate) if self._rate else 0
        if status != "ok":
            self._set("failed", reason)
            self.recordingSaved.emit("", self._duration_ms, self._rate, status)
            return
        name = time.strftime("rec-%Y%m%d-%H%M%S") + ".wav"
        path = self._rec_dir / name
        write_wav(path, samples, self._rate)
        self._last_file = path
        self._set("saved", "Got it.")
        self.recordingSaved.emit(name, self._duration_ms, self._rate, "ok")

    # ---- playback ----
    def _ref_file(self, text: str, slow: bool) -> Path | None:
        from .voice import slug
        base = slug(text)
        for name in ([f"{base}.slow.m4a", f"{base}.slow.wav"] if slow else []) + [f"{base}.m4a", f"{base}.wav"]:
            for d in self._ref_dirs:
                p = d / name
                if p.exists():
                    return p
        return None

    def _play(self, path: Path):
        if not self._player or not path.exists():
            return
        if self._voice:
            self._voice.stop()
        self._player.stop()
        self._player.setSource(QUrl.fromLocalFile(str(path)))
        self._player.play()

    def _say(self, text: str, slow: bool) -> bool:
        """Recorded reference if present, otherwise the Mac's Spanish voice."""
        f = self._ref_file(text, slow)
        if f is not None:
            self._play(f)
            return True
        if self._player:
            self._player.stop()
        return bool(self._voice and self._voice.speak(text, slow))

    @Slot(str, bool)
    def say(self, text: str, slow: bool):
        self._queue.clear()
        self._say(text, slow)

    @Slot(str, str, bool)
    def sayIn(self, text: str, lang: str, slow: bool):
        """Date night: Spanish lines use the usual voices; English lines the Mac's English voice."""
        self._queue.clear()
        if not lang.startswith("en"):
            self._say(text, slow)
            return
        if self._player:
            self._player.stop()
        if self._voice:
            self._voice.speak_in(text, lang, slow)

    @Slot(str, bool)
    def playReference(self, text: str, slow: bool):   # kept for older QML call sites
        self.say(text, slow)

    @Slot()
    def stopAll(self):
        self._queue.clear()
        if self._player:
            self._player.stop()
        if self._voice:
            self._voice.stop()

    @Slot()
    def playRecording(self):
        if self._get_has():
            self._queue.clear()
            self._set("playback", "Your recording.")
            self._play(self._last_file)

    @Slot(str)
    def compare(self, text: str):
        """Reference, then the learner's take, back to back."""
        if not self._get_has():
            return
        self._queue = [self._last_file]
        self._set("playback", "Reference, then your recording.")
        if not self._say(text, False):
            self._play(self._queue.pop(0))

    @Slot()
    def clearRecording(self):
        """New exercise: forget the previous take (the file stays on disk)."""
        self._last_file = None
        self._duration_ms = 0
        self.refresh()

    def _advance_queue(self):
        if self._queue:
            self._play(self._queue.pop(0))
            return
        if self._state == "playback":
            self._set("saved", "Press the mic to try again.")
        self.playbackFinished.emit()

    def _on_voice_finished(self):
        self._advance_queue()

    def _on_media_status(self, status):
        from PySide6.QtMultimedia import QMediaPlayer
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._advance_queue()
