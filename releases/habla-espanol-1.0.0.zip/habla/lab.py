"""Conversation Lab: a message arrives, you work out what it means, then you reply yourself.

Flow for one message (a "card"):
  meaning   - pick what the message means (comprehension, tracked separately)
  respond   - reply at level 1 (arrange tiles), 2 (English goal, type or say it) or 3 (just reply)
  breakdown - word by word, what it might mean, three replies in different tones
  transfer  - the same pattern with someone else (a coworker, a friend…)
  done

Replies are checked against the curated answers first (offline). Anything else is sent
to ChatGPT for a real judgment when the learner has added an OpenAI key; otherwise the
learner compares with the model answers himself (never marked wrong by a machine that
can't tell). Results live in the lab_item / lab_attempt tables; time spent counts toward
practice time through the shared attempt table (session 0, module 9, no evidence rows, so
the lesson review queue isn't touched).
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PySide6.QtCore import Property, QObject, QThread, Signal, Slot

from . import ai_replies as ai
from . import azure_voices as az
from .checking import check_build, check_typed, norm
from .db import iso, utcnow

CATEGORIES = [
    ("everyday", "Everyday", "Día a día", "sun"),
    ("questions", "Questions & follow-ups", "Preguntas", "message-circle-reply"),
    ("work", "Work", "Trabajo", "briefcase"),
    ("friends", "Friends", "Amigos", "users"),
    ("family", "Family", "Familia", "house"),
    ("humor", "Humor & teasing", "Bromas", "smile"),
    ("feelings", "Feelings", "Sentimientos", "heart"),
    ("plans", "Plans & invitations", "Planes", "calendar"),
    ("clarifying", "Clarifying", "¿Cómo?", "circle-help"),
    ("mexican", "Mexican expressions", "Mexicanismos", "sparkles"),
]
LEVELS = {1: "Understand", 2: "Respond", 3: "Converse", 4: "Natural"}

NAMES = {
    "f": ["Ana", "Sofía", "Daniela", "Mariana", "Fernanda", "Valeria", "Lupita", "Karla", "Paola", "Ximena",
          "Andrea", "Gaby", "Mónica", "Itzel", "Renata"],
    "m": ["Carlos", "Diego", "Luis", "Javier", "Memo", "Toño", "Rafa", "Andrés", "Emilio", "Beto", "Iván", "Omar"],
}
FAMILY = {"f": ["Mom", "Sister", "Cousin", "Aunt"], "m": ["Dad", "Brother", "Cousin", "Uncle"]}
FAMILY_NAME = {"Mom": "Mamá", "Dad": "Papá"}
COLORS = ["#E85D75", "#3498F5", "#34A875", "#F0A04B", "#9B7BF0", "#1FA3B5", "#D9558C", "#E9A93B"]

TABLES = """
CREATE TABLE IF NOT EXISTS lab_item (
    item_id     TEXT PRIMARY KEY,
    seen        INTEGER NOT NULL DEFAULT 0,
    comp_ok     INTEGER NOT NULL DEFAULT 0,
    comp_n      INTEGER NOT NULL DEFAULT 0,
    prod_ok     INTEGER NOT NULL DEFAULT 0,
    prod_n      INTEGER NOT NULL DEFAULT 0,
    best_level  INTEGER NOT NULL DEFAULT 0,
    last        TEXT,
    interval    REAL NOT NULL DEFAULT 0,
    due_at      TEXT,
    updated_at  TEXT
);
CREATE TABLE IF NOT EXISTS lab_attempt (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id    TEXT NOT NULL,
    part       TEXT NOT NULL,
    level      INTEGER NOT NULL DEFAULT 0,
    response   TEXT,
    outcome    TEXT NOT NULL,
    source     TEXT NOT NULL,
    hints      INTEGER NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL,
    finished_at TEXT NOT NULL
)
"""


def load(folder: Path) -> dict:
    folder = Path(folder)
    msgs = []
    for f in sorted(folder.glob("messages_*.json")):
        try:
            msgs += json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
    out = {"messages": msgs, "decoder": [], "texting": []}
    for k in ("decoder", "texting"):
        p = folder / f"{k}.json"
        if p.exists():
            try:
                out[k] = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    return out


def spanish_lines(content: dict) -> list[str]:
    """Every Spanish line the Lab can play, for the Azure voice download."""
    out = []
    for m in content.get("messages", []):
        out.append(m.get("standard", ""))
        out += [r.get("es", "") for r in m.get("replies", [])]
        t = m.get("task", {})
        out += (t.get("accept") or [])[:1]
        tr = m.get("transfer", {})
        out += [tr.get("es", ""), tr.get("model", "")]
        out += [b.get("es", "") for b in m.get("breakdown", [])]
    for d in content.get("decoder", []):
        out.append(d.get("es", ""))
        for ex in d.get("examples", []):
            out += [l.get("es", "") for l in ex]
        out.append((d.get("listen") or {}).get("es", ""))
        r = d.get("respond") or {}
        out += [r.get("incoming_es", ""), r.get("model", "")]
    for t in content.get("texting", []):
        out.append(t.get("example_standard", ""))
    seen, res = set(), []
    for x in out:
        x = (x or "").strip()
        if x and x not in seen:
            seen.add(x)
            res.append(x)
    return res


def contact(sender: dict, rng: random.Random) -> dict:
    """A random person to send the message: name, small label, avatar color."""
    g = sender.get("gender", "any")
    g = g if g in ("f", "m") else rng.choice(["f", "m"])
    rel = sender.get("relation", "anyone")
    role = sender.get("role_en", "")
    name = rng.choice(NAMES[g])
    if rel == "family":
        role = role or rng.choice(FAMILY[g])
        if role in FAMILY_NAME:
            name = FAMILY_NAME[role]
        label = role if role not in FAMILY_NAME else "Family"
    elif rel == "friend":
        label = role or "Friend"
    elif rel == "coworker":
        label = role or "Coworker"
    elif rel == "partner":
        label = role or ""
    else:
        label = role or ""
    return {"name": name, "label": label, "initial": name[:1], "color": rng.choice(COLORS), "gender": g,
            "relation": rel}


def who(c: dict) -> str:
    """How the sender is described to ChatGPT."""
    rel = {"friend": "a friend", "coworker": "a coworker", "family": f"their {c.get('label', 'relative').lower()}"}
    return f"{c['name']}, " + rel.get(c.get("relation"), "someone they know") + \
        (" (female)" if c.get("gender") == "f" else " (male)" if c.get("gender") == "m" else "")


def check_offline(text: str, accept: list[str]) -> dict:
    return check_typed(text, [a for a in accept if a])


class _Job(QThread):
    done = Signal("QVariantMap")

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn())
        except Exception as e:  # pragma: no cover
            self.done.emit({"ok": False, "error": f"Couldn't check that ({e})."})


OUTCOME = {"natural": "successful", "good": "successful", "fix": "partial", "off": "unsuccessful"}


class Lab(QObject):
    """Exposed to QML as `lab`."""
    changed = Signal()
    cardChanged = Signal()

    def __init__(self, folder: Path, db, settings, curriculum_version: str = "v1", parent=None, rng=None):
        super().__init__(parent)
        self.db, self.settings, self.version = db, settings, curriculum_version
        self.content = load(folder)
        self.by_id = {m["id"]: m for m in self.content["messages"]}
        self.rng = rng or random.Random()
        self._salt = self.rng.random()
        # listening options shuffled once per run; the answer stays here, not in what QML sees
        self._dec_answer = {}
        pub = []
        for d in self.content["decoder"]:
            li = d.get("listen") or {}
            opts = list(li.get("options", []))
            right = opts[li.get("answer", 0)] if opts else ""
            self.rng.shuffle(opts)
            self._dec_answer[d["id"]] = opts.index(right) if opts else 0
            pub.append(dict(d, listen={"es": li.get("es", ""), "options": opts}))
        self._decoder_public = pub
        self._card: dict = {}
        self._jobs: list = []
        self._seq = 0
        self._started = utcnow()
        with db.tx() as c:
            for stmt in [s.strip() for s in TABLES.split(";") if s.strip()]:
                c.execute(stmt)

    # ---------- keys ----------
    def _openai(self):
        model = str(self.settings.value("openai_model", "") or "") if self.settings is not None else ""
        return az.keychain_get(ai.KEYCHAIN_SERVICE), (model or ai.DEFAULT_MODEL)

    aiReady = Property(bool, lambda self: bool(self._openai()[0]), notify=changed)
    aiModel = Property(str, lambda self: self._openai()[1], notify=changed)

    @Slot(str, str)
    def setOpenAI(self, key: str, model: str):
        if key.strip():
            az.keychain_set(key.strip(), ai.KEYCHAIN_SERVICE)
        if self.settings is not None:
            self.settings.setValue("openai_model", model.strip() or ai.DEFAULT_MODEL)
        self.changed.emit()

    @Slot()
    def forgetOpenAI(self):
        az.keychain_delete(ai.KEYCHAIN_SERVICE)
        self.changed.emit()

    # ---------- stored results ----------
    def _rows(self) -> dict:
        return {r["item_id"]: r for r in self.db.conn.execute("SELECT * FROM lab_item")}

    def _save_item(self, item_id: str, **upd):
        row = self.db.conn.execute("SELECT * FROM lab_item WHERE item_id=?", (item_id,)).fetchone()
        cur = dict(row) if row else {"item_id": item_id, "seen": 0, "comp_ok": 0, "comp_n": 0, "prod_ok": 0,
                                     "prod_n": 0, "best_level": 0, "last": None, "interval": 0.0, "due_at": None}
        cur.update(upd)
        cur["updated_at"] = iso(utcnow())
        cols = list(cur)
        with self.db.tx() as c:
            c.execute(f"INSERT OR REPLACE INTO lab_item({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                      [cur[k] for k in cols])
        return cur

    def _log(self, item_id: str, part: str, level: int, response, outcome: str, source: str, hints: int = 0):
        now = utcnow()
        start = self._started if (now - self._started).total_seconds() < 600 else now - timedelta(minutes=5)
        with self.db.tx() as c:
            c.execute("INSERT INTO lab_attempt(item_id,part,level,response,outcome,source,hints,started_at,finished_at) "
                      "VALUES(?,?,?,?,?,?,?,?,?)",
                      (item_id, part, level, json.dumps(response, ensure_ascii=False), outcome, source, hints,
                       iso(start), iso(now)))
        # counts toward practice time (no evidence rows: the lesson review queue is left alone)
        self.db.record_attempt(curriculum_version=self.version, exercise_id=f"{item_id}#{part}", session_no=0,
                               module_no=9, input_type="text", response_type="typed", response=response,
                               hints_used=hints, started_at=start, finished_at=now)
        self._started = utcnow()

    def _schedule(self, item_id: str, outcome: str, level: int, hints: int):
        row = self.db.conn.execute("SELECT * FROM lab_item WHERE item_id=?", (item_id,)).fetchone()
        interval = float(row["interval"]) if row else 0.0
        now = utcnow()
        on_own = level >= 2 and hints == 0
        if outcome == "successful" and on_own:
            interval = 1.0 if interval < 1 else min(interval * 2.5, 120.0)
            due = now + timedelta(days=interval)
        elif outcome == "successful":            # with tiles or hints: come back soon, one level up
            interval, due = 1.0, now + timedelta(days=1)
        elif outcome == "partial":
            interval, due = 0.5, now + timedelta(hours=12)
        else:
            interval, due = 0.0, now + timedelta(minutes=10)
        best = max(int(row["best_level"]) if row else 0, level if outcome == "successful" and hints == 0 else 0)
        self._save_item(item_id, interval=interval, due_at=iso(due), last=outcome,
                        prod_n=(row["prod_n"] if row else 0) + 1,
                        prod_ok=(row["prod_ok"] if row else 0) + (outcome == "successful" and on_own),
                        best_level=best)

    # ---------- home ----------
    def _stats(self) -> dict:
        rows = self._rows()
        msgs = self.content["messages"]
        seen = sum(1 for m in msgs if m["id"] in rows and rows[m["id"]]["seen"])
        comp = [r for r in rows.values() if r["comp_n"]]
        understood = sum(1 for r in comp if r["comp_ok"])
        own = sum(1 for m in msgs if m["id"] in rows and rows[m["id"]]["best_level"] >= 2)
        now = iso(utcnow())
        due = sum(1 for m in msgs if m["id"] in rows and rows[m["id"]]["due_at"] and rows[m["id"]]["due_at"] <= now)
        # comprehension vs production, from first tries
        att = list(self.db.conn.execute("SELECT part, outcome, level, hints FROM lab_attempt"))
        c_n = sum(1 for a in att if a["part"] == "meaning")
        c_ok = sum(1 for a in att if a["part"] == "meaning" and a["outcome"] == "successful")
        p = [a for a in att if a["part"] in ("respond", "transfer", "decoder")]
        p_ok = sum(1 for a in p if a["outcome"] == "successful" and a["level"] >= 2 and not a["hints"])
        days = sorted({r[0][:10] for r in self.db.conn.execute("SELECT finished_at FROM lab_attempt")}, reverse=True)
        streak, d = 0, datetime.now().date()
        dayset = set(days)
        while d.isoformat() in dayset or (streak == 0 and (d - timedelta(days=1)).isoformat() in dayset and d.isoformat() not in dayset):
            if d.isoformat() in dayset:
                streak += 1
            d -= timedelta(days=1)
            if streak == 0 and d.isoformat() not in dayset:
                break
        stage = 1
        if own >= 8:
            stage = 2
        if own >= 25:
            stage = 3
        if own >= 45:
            stage = 4
        return {"total": len(msgs), "seen": seen, "understood": understood, "own": own, "due": due,
                "compPct": round(100 * c_ok / c_n) if c_n else -1, "prodPct": round(100 * p_ok / len(p)) if p else -1,
                "compN": c_n, "prodN": len(p), "stage": stage, "stageName": LEVELS[stage], "streak": streak,
                "gap": bool(c_n >= 5 and p and (c_ok / c_n) - (p_ok / len(p)) >= 0.25)}

    stats = Property("QVariantMap", _stats, notify=changed)

    def _categories(self) -> list:
        rows = self._rows()
        out = []
        for cid, title, title_es, icon in CATEGORIES:
            ms = [m for m in self.content["messages"] if m.get("category") == cid]
            if not ms:
                continue
            done = sum(1 for m in ms if m["id"] in rows and rows[m["id"]]["best_level"] >= 2)
            seen = sum(1 for m in ms if m["id"] in rows and rows[m["id"]]["seen"])
            out.append({"id": cid, "title": title, "title_es": title_es, "icon": icon, "count": len(ms),
                        "done": done, "seen": seen, "sample": ms[0].get("standard", "")})
        return out

    categories = Property("QVariantList", _categories, notify=changed)

    def pick(self, category: str = "") -> dict | None:
        """Next message: due ones first, then new ones (easiest first), then the soonest due."""
        rows = self._rows()
        msgs = [m for m in self.content["messages"] if not category or m.get("category") == category]
        if not msgs:
            return None
        now = iso(utcnow())
        current = self._card.get("id")
        due = [m for m in msgs if m["id"] in rows and rows[m["id"]]["due_at"] and rows[m["id"]]["due_at"] <= now
               and m["id"] != current]
        if due:
            return min(due, key=lambda m: rows[m["id"]]["due_at"])
        new = [m for m in msgs if m["id"] not in rows or not rows[m["id"]]["seen"]]
        if new:
            if not category:      # spread across categories: the least practiced first
                cats = self._categories()
                practiced = {c["id"]: c["seen"] for c in cats}
                new.sort(key=lambda m: (m.get("difficulty", 1), practiced.get(m.get("category"), 0), self._order(m)))
            else:
                new.sort(key=lambda m: (m.get("difficulty", 1), self._order(m)))
            return new[0]
        rest = [m for m in msgs if m["id"] != current] or msgs
        return min(rest, key=lambda m: rows[m["id"]]["due_at"] or "")

    def _order(self, m: dict) -> float:
        """A shuffled but stable order (so 'Next up' is the one that opens)."""
        return random.Random(f"{self._salt}:{m['id']}").random()

    def _recommended(self) -> dict:
        m = self.pick("")
        if not m:
            return {}
        rows = self._rows()
        r = rows.get(m["id"])
        why = "Due again" if r and r["due_at"] and r["due_at"] <= iso(utcnow()) else ("New" if not r or not r["seen"] else "Practice")
        cat = dict((c[0], c[1]) for c in CATEGORIES).get(m.get("category"), "")
        return {"id": m["id"], "text": m.get("texting", ""), "category": cat, "why": why}

    recommended = Property("QVariantMap", _recommended, notify=changed)
    decoder = Property("QVariantList", lambda self: self._decoder_public, constant=True)
    texting = Property("QVariantList", lambda self: self.content["texting"], constant=True)

    # ---------- the card ----------
    card = Property("QVariantMap", lambda self: self._card, notify=cardChanged)

    def _emit(self):
        self.cardChanged.emit()

    @Slot(str)
    def openCategory(self, category: str):
        m = self.pick(category)
        if m:
            self._open(m, category)

    @Slot(str)
    def openMessage(self, item_id: str):
        m = self.by_id.get(item_id)
        if m:
            self._open(m, self._card.get("category_filter", ""))

    @Slot()
    def nextMessage(self):
        self.openCategory(self._card.get("category_filter", ""))

    def _suggest_level(self, item_id: str) -> int:
        r = self.db.conn.execute("SELECT best_level FROM lab_item WHERE item_id=?", (item_id,)).fetchone()
        best = int(r["best_level"]) if r else 0
        return min(3, max(1, best + 1)) if best else 1

    def _open(self, m: dict, category_filter: str = ""):
        rng = self.rng
        who_ = contact(m.get("sender", {}), rng)
        opts = list(m["meaning"]["options"])
        right = opts[m["meaning"]["answer"]]
        rng.shuffle(opts)
        t = m.get("task", {})
        tiles = list(t.get("answer", [])) + list(t.get("extra_tiles", []))
        rng.shuffle(tiles)
        tr = m.get("transfer", {})
        cat = {c[0]: c[1] for c in CATEGORIES}.get(m.get("category"), "")
        self._card = {
            "id": m["id"], "category": cat, "category_filter": category_filter, "difficulty": m.get("difficulty", 1),
            "contact": who_, "texting": m.get("texting", ""), "standard": m.get("standard", ""),
            "meaningOptions": opts, "_meaningAnswer": opts.index(right),
            "step": "meaning", "level": self._suggest_level(m["id"]),
            "intent": t.get("intent", ""), "tiles": tiles, "hintsShown": [], "hintsLeft": len(t.get("hints", [])),
            "result": {}, "meaningResult": {}, "transfer": {"contact": contact(tr.get("sender", {}), rng),
                                                            "es": tr.get("es", ""), "intent": tr.get("intent", "")},
            "transferResult": {}, "checking": False, "time": datetime.now().strftime("%-I:%M %p"),
        }
        self._started = utcnow()
        row = self.db.conn.execute("SELECT seen FROM lab_item WHERE item_id=?", (m["id"],)).fetchone()
        self._save_item(m["id"], seen=(row["seen"] if row else 0) + 1)
        self._emit()
        self.changed.emit()

    def _msg(self) -> dict:
        return self.by_id.get(self._card.get("id", ""), {})

    @Slot(int, result="QVariantMap")
    def answerMeaning(self, index: int) -> dict:
        m, c = self._msg(), self._card
        if not m or c.get("step") != "meaning":
            return {}
        ok = index == c["_meaningAnswer"]
        first = not c["meaningResult"]
        if first:
            row = self.db.conn.execute("SELECT comp_ok, comp_n FROM lab_item WHERE item_id=?", (m["id"],)).fetchone()
            self._save_item(m["id"], comp_n=row["comp_n"] + 1, comp_ok=row["comp_ok"] + ok)
            self._log(m["id"], "meaning", 0, c["meaningOptions"][index], "successful" if ok else "unsuccessful",
                      "deterministic")
        res = {"correct": ok, "answer": c["_meaningAnswer"], "picked": index, "en": m.get("en", ""),
               "firstTry": ok and first}
        c["meaningResult"] = res if (ok or first) else dict(res, firstTry=False)
        self._emit()
        return res

    @Slot()
    def toRespond(self):
        if self._card:
            self._card["step"] = "respond"
            self._card["result"] = {}
            self._started = utcnow()
            self._emit()

    @Slot(int)
    def setLevel(self, level: int):
        if self._card and self._card.get("step") == "respond" and not self._card.get("result", {}).get("final"):
            self._card["level"] = max(1, min(3, level))
            self._card["result"] = {}
            self._emit()

    @Slot(result=str)
    def hint(self) -> str:
        m, c = self._msg(), self._card
        hints = m.get("task", {}).get("hints", [])
        k = len(c.get("hintsShown", []))
        if k >= len(hints):
            return ""
        c["hintsShown"] = c["hintsShown"] + [hints[k]]
        c["hintsLeft"] = len(hints) - k - 1
        self._emit()
        return hints[k]

    def _accept(self, level: int) -> list[str]:
        m = self._msg()
        t = m.get("task", {})
        acc = list(t.get("accept", []))
        if level >= 3:
            acc += [r["es"] for r in m.get("replies", [])] + list(m.get("accept_more", []))
        return acc

    def _model(self) -> dict:
        m = self._msg()
        t = m.get("task", {})
        return {"es": (t.get("accept") or [""])[0], "intent": t.get("intent", "")}

    @Slot("QVariantList", result="QVariantMap")
    def submitTiles(self, chosen) -> dict:
        m, c = self._msg(), self._card
        t = m.get("task", {})
        chosen = [str(x) for x in chosen]
        ok = check_build(chosen, t.get("answer", []), t.get("alts"))
        tries = c.get("result", {}).get("tries", 0) + 1
        res = {"kind": "tiles", "correct": ok, "tries": tries, "final": ok or tries >= 2,
               "model": self._model()["es"], "verdict": "natural" if ok else "", "source": "deterministic"}
        if res["final"]:
            outcome = "successful" if ok else "unsuccessful"
            hints = len(c.get("hintsShown", []))
            self._log(m["id"], "respond", 1, chosen, outcome, "deterministic", hints)
            self._schedule(m["id"], outcome, 1, hints)
        c["result"] = res
        self._emit()
        self.changed.emit()
        return res

    @Slot(str, bool)
    def submitText(self, text: str, spoken: bool):
        """Level 2/3 reply, typed or spoken (the transcript)."""
        m, c = self._msg(), self._card
        text = (text or "").strip()
        if not m or not text or c.get("checking"):
            return
        level = int(c.get("level", 2))
        hints = len(c.get("hintsShown", []))
        res = check_offline(text, self._accept(level))
        base = {"kind": "text", "text": text, "spoken": spoken, "model": self._model()["es"], "level": level}
        if res["correct"]:
            c["result"] = dict(base, correct=True, final=True, verdict="natural", source="deterministic",
                               accentNote=bool(res.get("accent_note")) and not spoken,
                               feedback="That's one of the natural replies.")
            self._log(m["id"], "respond", level, text, "successful", "deterministic", hints)
            self._schedule(m["id"], "successful", level, hints)
            self._emit()
            self.changed.emit()
            return
        self._ask_ai("result", base, m.get("standard", ""), m.get("en", ""), c["contact"],
                     text, c.get("intent", "") if level < 3 else "", m["id"], "respond", level, hints)

    def _ask_ai(self, slot: str, base: dict, es: str, en: str, who_: dict, text: str, intent: str,
                item_id: str, part: str, level: int, hints: int):
        c = self._card
        key, model = self._openai()
        if not key:
            # no judge available: the learner compares with the model answers himself
            c[slot] = dict(base, correct=None, final=False, verdict="compare", source="self")
            self._emit()
            return
        self._seq += 1
        seq, card_id = self._seq, c.get("id")
        c["checking"] = True
        c[slot] = dict(base, correct=None, final=False, verdict="checking")
        self._emit()
        job = _Job(lambda: ai.check_reply(key, model, es, en, who(who_), text, intent))

        def done(r, s=seq):
            if s != self._seq or self._card.get("id") != card_id:
                return
            self._card["checking"] = False
            if not r.get("ok"):
                self._card[slot] = dict(base, correct=None, final=False, verdict="compare", source="self",
                                        aiError=r.get("error", ""))
            else:
                outcome = OUTCOME[r["verdict"]]
                self._card[slot] = dict(base, **{k: r[k] for k in ("verdict", "means", "feedback", "corrected", "natural", "natural_en")},
                                        correct=outcome == "successful", final=True, source="ai")
                self._log(item_id, part, level, text, outcome, "ai", hints)
                if part == "respond":
                    self._schedule(item_id, outcome, level, hints)
                self.changed.emit()
            self._emit()
        job.done.connect(done)
        job.finished.connect(lambda j=job: self._jobs.remove(j) if j in self._jobs else None)
        self._jobs.append(job)
        job.start()

    @Slot(bool)
    def selfReview(self, matched: bool):
        """No ChatGPT: the learner says whether his reply matched one of the model answers."""
        c, m = self._card, self._msg()
        for slot, part in (("result", "respond"), ("transferResult", "transfer")):
            r = c.get(slot) or {}
            if r.get("verdict") == "compare" and not r.get("final"):
                outcome = "successful" if matched else "partial"
                level = int(r.get("level", c.get("level", 2)))
                hints = len(c.get("hintsShown", [])) if part == "respond" else 0
                c[slot] = dict(r, final=True, correct=matched, verdict="good" if matched else "fix")
                self._log(m["id"], part, level, r.get("text", ""), outcome, "self", hints)
                if part == "respond":
                    self._schedule(m["id"], outcome, level, hints)
                break
        self._emit()
        self.changed.emit()

    @Slot()
    def giveUp(self):
        c, m = self._card, self._msg()
        if not m or c.get("step") != "respond" or c.get("result", {}).get("final"):
            return
        level = int(c.get("level", 1))
        self._log(m["id"], "respond", level, "", "unsuccessful", "deterministic", len(c.get("hintsShown", [])))
        self._schedule(m["id"], "unsuccessful", level, 1)
        c["result"] = {"kind": "gaveup", "correct": False, "final": True, "model": self._model()["es"], "verdict": "shown"}
        self._emit()
        self.changed.emit()

    @Slot()
    def retry(self):
        c = self._card
        if c.get("step") == "respond":
            c["result"] = {}
            self._started = utcnow()
            self._emit()

    @Slot()
    def toBreakdown(self):
        m, c = self._msg(), self._card
        if not m:
            return
        c["step"] = "breakdown"
        c["en"] = m.get("en", "")
        c["breakdown"] = m.get("breakdown", [])
        c["notes"] = m.get("notes", [])
        c["reading"] = m.get("reading", "")
        c["replies"] = m.get("replies", [])
        c["tones"] = m.get("tones", "")
        c["model"] = self._model()["es"]
        self._emit()

    @Slot()
    def toTransfer(self):
        if self._card:
            self._card["step"] = "transfer"
            self._card["transferResult"] = {}
            self._started = utcnow()
            self._emit()

    @Slot(str, bool)
    def submitTransfer(self, text: str, spoken: bool):
        m, c = self._msg(), self._card
        text = (text or "").strip()
        if not m or not text or c.get("checking"):
            return
        tr = m.get("transfer", {})
        res = check_offline(text, tr.get("accept", []))
        base = {"kind": "text", "text": text, "spoken": spoken, "model": tr.get("model", ""), "en": tr.get("en", ""),
                "level": 2}
        if res["correct"]:
            c["transferResult"] = dict(base, correct=True, final=True, verdict="natural", source="deterministic",
                                       feedback="Same pattern, new situation. Nice.")
            self._log(m["id"], "transfer", 2, text, "successful", "deterministic")
            self._emit()
            self.changed.emit()
            return
        self._ask_ai("transferResult", base, tr.get("es", ""), tr.get("en", ""), c["transfer"]["contact"], text,
                     tr.get("intent", ""), m["id"], "transfer", 2, 0)

    @Slot()
    def showTransferAnswer(self):
        m, c = self._msg(), self._card
        tr = m.get("transfer", {})
        if not c.get("transferResult", {}).get("final"):
            self._log(m["id"], "transfer", 2, "", "unsuccessful", "deterministic")
        c["transferResult"] = {"kind": "gaveup", "final": True, "correct": False, "model": tr.get("model", ""),
                               "en": tr.get("en", ""), "verdict": "shown"}
        self._emit()

    @Slot()
    def finish(self):
        if self._card:
            self._card["step"] = "done"
            self._emit()
            self.changed.emit()

    @Slot()
    def close(self):
        self._seq += 1
        self._card = {}
        self._emit()
        self.changed.emit()

    # ---------- decoder ----------
    @Slot(str, int, result="QVariantMap")
    def decoderListen(self, dec_id: str, index: int) -> dict:
        d = next((x for x in self.content["decoder"] if x["id"] == dec_id), None)
        if not d:
            return {}
        ans = self._dec_answer.get(dec_id, 0)
        ok = index == ans
        self._started = utcnow() - timedelta(seconds=20)
        self._log(dec_id, "decoder_listen", 0, index, "successful" if ok else "unsuccessful", "deterministic")
        return {"correct": ok, "answer": ans}

    decoderResultChanged = Signal()
    decoderResult = Property("QVariantMap", lambda self: self._dec, notify=decoderResultChanged)
    _dec: dict = {}

    @Slot(str, str)
    def decoderRespond(self, dec_id: str, text: str):
        d = next((x for x in self.content["decoder"] if x["id"] == dec_id), None)
        text = (text or "").strip()
        if not d or not text:
            return
        r = d["respond"]
        res = check_offline(text, r.get("accept", []))
        base = {"id": dec_id, "text": text, "model": r.get("model", "")}
        self._started = utcnow() - timedelta(seconds=30)
        if res["correct"]:
            self._dec = dict(base, final=True, correct=True, verdict="natural", feedback="Natural. That's how it's used.")
            self._log(dec_id, "decoder", 2, text, "successful", "deterministic")
            self.decoderResultChanged.emit()
            self.changed.emit()
            return
        key, model = self._openai()
        if not key:
            self._dec = dict(base, final=False, verdict="compare")
            self.decoderResultChanged.emit()
            return
        self._seq += 1
        seq = self._seq
        self._dec = dict(base, final=False, verdict="checking")
        self.decoderResultChanged.emit()
        job = _Job(lambda: ai.check_reply(key, model, r["incoming_es"], r["incoming_en"], "a friend", text, r.get("intent", "")))

        def done(res2, s=seq):
            if s != self._seq:
                return
            if not res2.get("ok"):
                self._dec = dict(base, final=False, verdict="compare", aiError=res2.get("error", ""))
            else:
                outcome = OUTCOME[res2["verdict"]]
                self._dec = dict(base, final=True, correct=outcome == "successful", source="ai",
                                 **{k: res2[k] for k in ("verdict", "means", "feedback", "corrected", "natural", "natural_en")})
                self._log(dec_id, "decoder", 2, text, outcome, "ai")
                self.changed.emit()
            self.decoderResultChanged.emit()
        job.done.connect(done)
        job.finished.connect(lambda j=job: self._jobs.remove(j) if j in self._jobs else None)
        self._jobs.append(job)
        job.start()

    @Slot()
    def clearDecoder(self):
        self._seq += 1
        self._dec = {}
        self.decoderResultChanged.emit()

    @Slot()
    def refresh(self):
        self.changed.emit()

    def progress_summary(self) -> dict:
        """For the Progress page: understand vs respond."""
        return self._stats()
