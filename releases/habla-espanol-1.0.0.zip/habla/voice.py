"""Spoken Spanish for every lesson line.

Order of preference for each phrase:
  1. A reviewed recording in assets/audio/reference/<slug>.wav (ElevenLabs, later).
  2. The Mac's built-in Mexican Spanish voice (offline), via Qt TextToSpeech.
So every line in every lesson can be heard today, and recordings replace the
synthetic voice phrase by phrase as they are produced.
"""
from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import Property, QLocale, QObject, Signal, Slot

from .checking import strip_accents


def slug(text: str) -> str:
    s = strip_accents(text.lower()).replace("ñ", "n")
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return s[:80] or "_"


class Voice(QObject):
    """Wraps QTextToSpeech; picks a Spanish (prefer es-MX) voice."""
    changed = Signal()
    finished = Signal()          # emitted when an utterance finishes

    def __init__(self, enabled: bool = True, preferred: str = "", rate: float = 0.0, parent=None):
        super().__init__(parent)
        self._tts = None
        self._voices = []
        self._voice_name = ""
        self._rate = rate
        self._speaking = False
        if not enabled:
            return
        try:
            from PySide6.QtTextToSpeech import QTextToSpeech
        except ImportError:
            return
        engines = [e for e in QTextToSpeech.availableEngines() if e != "mock"]
        for eng in engines:
            t = QTextToSpeech(eng, self)
            if t.state() != QTextToSpeech.State.Error:
                self._tts = t
                break
        if self._tts is None:
            return
        self._tts.stateChanged.connect(self._on_state)
        self._load_voices()
        self.select(preferred)

    def _load_voices(self):
        all_v = []
        for loc in self._tts.availableLocales():
            if loc.language() != QLocale.Language.Spanish:
                continue
            self._tts.setLocale(loc)
            for v in self._tts.availableVoices():
                all_v.append(v)
        # es-MX first, then other Latin American, then Spain
        def rank(v):
            terr = v.locale().territory()
            if terr == QLocale.Country.Mexico:
                return 0
            if terr == QLocale.Country.Spain:
                return 2
            return 1
        seen, out = set(), []
        for v in sorted(all_v, key=rank):
            if v.name() not in seen:
                seen.add(v.name())
                out.append(v)
        self._voices = out

    def _on_state(self, st):
        from PySide6.QtTextToSpeech import QTextToSpeech
        speaking = st == QTextToSpeech.State.Speaking
        if self._speaking and not speaking:
            self._speaking = False
            self.finished.emit()
        self._speaking = speaking

    # ---- properties for Settings ----
    def _get_available(self): return bool(self._voices)
    def _get_names(self): return [f"{v.name()} ({v.locale().bcp47Name()})" for v in self._voices]
    def _get_current(self): return self._voice_name
    def _get_rate(self): return self._rate

    available = Property(bool, _get_available, notify=changed)
    voiceNames = Property("QStringList", _get_names, notify=changed)
    currentVoice = Property(str, _get_current, notify=changed)
    rate = Property(float, _get_rate, notify=changed)

    @Slot(str)
    def select(self, label: str):
        if not self._voices:
            return
        v = next((x for x in self._voices if label and label.startswith(x.name())), self._voices[0])
        self._tts.setLocale(v.locale())
        self._tts.setVoice(v)
        self._voice_name = f"{v.name()} ({v.locale().bcp47Name()})"
        self.changed.emit()

    @Slot(float)
    def setRate(self, r: float):
        self._rate = max(-0.6, min(0.4, r))
        self.changed.emit()

    def _english_voice(self):
        """An American English voice for date night (Samantha if present)."""
        if getattr(self, "_en", None) is not None:
            return self._en
        best = None
        for loc in self._tts.availableLocales():
            if loc.language() != QLocale.Language.English:
                continue
            self._tts.setLocale(loc)
            for v in self._tts.availableVoices():
                score = (0 if v.locale().territory() == QLocale.Country.UnitedStates else 1,
                         0 if v.name().startswith(("Samantha", "Ava", "Allison", "Alex")) else 1)
                if best is None or score < best[0]:
                    best = (score, v)
        self._en = best[1] if best else False
        self._switched = True
        return self._en

    def speak_in(self, text: str, lang: str, slow: bool = False) -> bool:
        if not self._tts:
            return False
        if not lang.startswith("en"):
            return self.speak(text, slow)
        v = self._english_voice()
        if not v:
            return False
        self._tts.stop()
        self._tts.setLocale(v.locale())
        self._tts.setVoice(v)
        self._switched = True
        self._tts.setRate(self._rate - (0.35 if slow else 0.0))
        self._tts.say(text)
        return True

    def speak(self, text: str, slow: bool = False) -> bool:
        if not self._tts or not self._voices:
            return False
        self._tts.stop()
        if getattr(self, "_switched", False):          # back to the Spanish voice after English
            self._switched = False
            self.select(self._voice_name)
        self._tts.setRate(self._rate - (0.35 if slow else 0.0))
        self._tts.say(text.replace("…", ", "))
        return True

    def stop(self):
        if self._tts:
            self._tts.stop()
