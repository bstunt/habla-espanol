"""Active practice time. Each answer counts up to 5 minutes, and time that overlaps
(e.g. a test's 30 answers that share one start time) is only counted once."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

CAP = timedelta(minutes=5)


def _parse(ts):
    if not ts:
        return None
    try:
        if "T" in ts:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        else:
            dt = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def intervals(conn) -> list[tuple[datetime, datetime]]:
    out = []
    for r in conn.execute("SELECT started_at, finished_at FROM attempt WHERE finished_at IS NOT NULL"):
        a, b = _parse(r[0]), _parse(r[1])
        if a and b and b > a:
            out.append((max(a, b - CAP), b))          # the last 5 minutes before each answer at most
    return out


def merge(spans):
    spans = sorted(spans)
    out = []
    for a, b in spans:
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def minutes_by_day(conn, tz) -> dict:
    """{local date: minutes}"""
    days: dict = {}
    for a, b in merge(intervals(conn)):
        a, b = a.astimezone(tz), b.astimezone(tz)
        while a < b:                                   # split at midnight
            end = min(b, (a + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0))
            days[a.date()] = days.get(a.date(), 0) + (end - a).total_seconds() / 60
            a = end
    return days


def total_minutes(conn) -> int:
    return int(round(sum((b - a).total_seconds() for a, b in merge(intervals(conn))) / 60))
