"""Wrong answers that don't give the right one away: same shape (length, question or
statement, trailing "…"), no near-duplicates, and "A / B" phrases asked one half at a time."""
from __future__ import annotations

import random
import re
import unicodedata


def key(x: str) -> str:
    x = unicodedata.normalize("NFD", (x or "").lower())
    x = "".join(c for c in x if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ]+", " ", x).strip()


def simplify(item: dict, rng: random.Random) -> dict:
    """"Ya no tenemos… / Se nos terminó…" + "We don't have any more… / We ran out of…" -> one matching half."""
    es = [p.strip() for p in re.split(r"\s+/\s+", item.get("es", "")) if p.strip()]
    en = [p.strip() for p in re.split(r"\s+/\s+", item.get("en", "")) if p.strip()]
    if len(es) > 1 and len(es) == len(en):
        k = rng.randrange(len(es))
        return dict(item, es=es[k], en=en[k])
    if len(es) > 1 or len(en) > 1:
        return dict(item, es=es[0] if es else item.get("es", ""), en=en[0] if en else item.get("en", ""))
    return item


def _shape(s: str) -> tuple:
    s = s.strip()
    return (s.endswith(("…", "...")), s.startswith(("¿", "¡")) or s.endswith(("?", "!")), len(s.split()),
            s.endswith("."))


def _halves(x: str) -> set:
    return {key(p) for p in re.split(r"\s+/\s+", x or "") if key(p)}


def pick(item: dict, pool: list[dict], field: str, rng: random.Random, k: int = 3, same_group=None,
         original: dict | None = None) -> tuple[str, list[str]]:
    """Returns (shown correct answer, k wrong answers) for `field` ("es" or "en").
    Nothing that shares a meaning with any half of the original phrase is used."""
    correct = item[field]
    src = original or item
    bad_es = _halves(src.get("es", "")) | {key(item.get("es", ""))}
    bad_en = _halves(src.get("en", "")) | {key(item.get("en", ""))}
    want = _shape(correct)
    seen = {key(correct)}
    cands = []
    for raw in pool:
        if _halves(raw.get("es", "")) & bad_es or _halves(raw.get("en", "")) & bad_en:
            continue                                  # same phrase, or another way to say the same thing
        p = simplify(raw, rng)
        txt = p.get(field, "")
        kk = key(txt)
        ck = key(correct)
        if not txt or kk in seen:
            continue
        if ck and (kk.startswith(ck) or ck.startswith(kk) or f" {ck} " in f" {kk} "):
            continue                                  # "¿A qué hora empiezas…?" would also be right for "At what time…?"
        seen.add(kk)
        sh = _shape(txt)
        score = ((3 if sh[0] == want[0] else 0) + (2 if sh[1] == want[1] else 0) + (1 if sh[3] == want[3] else 0)
                 - min(abs(sh[2] - want[2]), 6) * 0.6)
        if same_group is not None and same_group(raw):
            score += 1.5
        cands.append((score + rng.random() * 0.8, txt))   # a little randomness so retakes differ
    cands.sort(reverse=True)
    wrong = [t for _, t in cands[:k]]
    # if the wrong answers don't share the right one's trailing "…", drop it from the right one too
    if want[0] and not all(_shape(w)[0] for w in wrong):
        correct = re.sub(r"\s*(…|\.\.\.)\s*$", "", correct)
    return correct, wrong
