"""Weekly report card: what the learner covered in one calendar week (Mon–Sun) and
school-style grades per subject. Everything comes from the local database. A subject
with too little work that week gets "I" (incomplete) instead of a made-up grade."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

MONTHS_ES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
             "septiembre", "octubre", "noviembre", "diciembre"]
DAYS_EN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
DAYS_ES = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]

# subject key → (English, Spanish, minimum checked answers for a grade)
SUBJECTS = [
    ("listening", "Listening", "Comprensión auditiva", 4),
    ("construction", "Grammar & sentence building", "Gramática y construcción de frases", 4),
    ("speaking", "Pronunciation", "Pronunciación", 2),
    ("interaction", "Conversation", "Conversación", 4),
    ("memory", "Vocabulary memory (reviews)", "Memoria de vocabulario (repasos)", 3),
    ("attendance", "Attendance & effort", "Asistencia y esfuerzo", 0),
]

GRADE_STEPS = [(97, "A+"), (93, "A"), (90, "A-"), (87, "B+"), (83, "B"), (80, "B-"),
               (77, "C+"), (73, "C"), (70, "C-"), (67, "D+"), (63, "D"), (60, "D-"), (0, "F")]

T = {
    "en": {"title": "Report Card", "school": "Spanish in 30 Days", "student": "Student", "week": "Week",
           "level": "Grade level", "levelv": "Day {d} of 30", "subject": "Subject", "grade": "Grade", "score": "Score",
           "comment": "Teacher's comment", "overall": "Overall", "gpa": "GPA", "learned": "What we learned this week",
           "days": "Course days finished", "phrases": "New phrases you used on your own",
           "basics": "Basics units", "scen": "Real-life scenarios", "none": "Nothing finished this week.",
           "note": "Teacher's note", "attendance": "Days practiced", "minutes": "{m} min of practice",
           "sign": "Maestra Habla", "incomplete": "Not enough work in these 7 days to grade.",
           "scale": "A 90–100 · B 80–89 · C 70–79 · D 60–69 · F below 60 · I incomplete",
           "practiced": "{n} phrases practiced in total", "more": "+{n} more"},
    "es": {"title": "Boleta de calificaciones", "school": "Español en 30 días", "student": "Alumno(a)", "week": "Semana",
           "level": "Grado", "levelv": "Día {d} de 30", "subject": "Materia", "grade": "Calificación", "score": "Puntaje",
           "comment": "Comentario de la maestra", "overall": "Promedio general", "gpa": "Escala de 4:", "learned": "Lo que aprendimos esta semana",
           "days": "Días del curso terminados", "phrases": "Frases nuevas que usaste solo(a)",
           "basics": "Unidades de Básicos", "scen": "Situaciones de la vida real", "none": "Nada terminado esta semana.",
           "note": "Nota de la maestra", "attendance": "Días de práctica", "minutes": "{m} min de práctica",
           "sign": "Maestra Habla", "incomplete": "No hubo suficiente trabajo en estos 7 días para calificar.",
           "scale": "A 90–100 · B 80–89 · C 70–79 · D 60–69 · F menos de 60 · I incompleto",
           "practiced": "{n} frases practicadas en total", "more": "+{n} más"},
}

COMMENTS = {
    "A": ("Excellent work. {d}", "¡Excelente trabajo! {d}"),
    "B": ("Solid. {d} {tip}", "Muy bien. {d} {tip}"),
    "C": ("Getting there. {d} {tip}", "Vas bien. {d} {tip}"),
    "D": ("Needs attention. {d} {tip}", "Necesita atención. {d} {tip}"),
    "F": ("Let's rebuild this one slowly. {d} {tip}", "Vamos a reforzarlo con calma. {d} {tip}"),
}
TIPS = {
    "listening": ("Replay the dialogues at slow speed.", "Vuelve a escuchar los diálogos a velocidad lenta."),
    "construction": ("Redo the sentence-building lessons.", "Repite las lecciones de construir frases."),
    "speaking": ("Listen slowly, then say it again.", "Escucha despacio y vuelve a decirlo."),
    "interaction": ("Replay the conversation missions.", "Repite las misiones de conversación."),
    "memory": ("Do your reviews the day they're due.", "Haz tus repasos el día que tocan."),
    "attendance": ("Aim for five days, even 15 minutes each.", "Intenta cinco días, aunque sean 15 minutos."),
}


def letter(pct: float) -> str:
    for cut, g in GRADE_STEPS:
        if pct >= cut:
            return g
    return "F"


def _parse(ts: str | None, tz):
    if not ts:
        return None
    try:
        if "T" in ts:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        else:
            dt = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(tz)
    except Exception:
        return None


def week_bounds(now: datetime, offset: int):
    """The last 7 days, ending today (offset -1 = the 7 days before that, and so on)."""
    end = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(weeks=offset)
    return end - timedelta(days=7), end


def week_label(start: datetime, lang: str) -> str:
    end = start + timedelta(days=6)
    if lang == "es":
        if start.month == end.month:
            return f"{start.day} – {end.day} de {MONTHS_ES[start.month - 1]} de {end.year}"
        return f"{start.day} de {MONTHS_ES[start.month - 1]} – {end.day} de {MONTHS_ES[end.month - 1]} de {end.year}"
    if start.month == end.month:
        return f"{start.strftime('%b')} {start.day} – {end.day}, {end.year}"
    return f"{start.strftime('%b')} {start.day} – {end.strftime('%b')} {end.day}, {end.year}"


def build(state, offset: int = 0, lang: str = "en") -> dict:
    lang = "es" if lang == "es" else "en"
    t, es = T[lang], lang == "es"
    db, cur = state.db, state.cur
    now = state._now()
    tz = now.tzinfo
    start, end = week_bounds(now, offset)

    def inweek(ts):
        dt = _parse(ts, tz)
        return dt is not None and start <= dt < end

    def concept(target):
        c = cur.concepts.get(target)
        if not c:
            for sc in state._scen.values():
                if target in sc.get("concepts", {}):
                    return sc["concepts"][target]
        return c or {}

    r0 = db.conn.execute("SELECT MIN(started_at) FROM attempt").fetchone()
    first = _parse(r0[0], tz) if r0 else None
    ev = [r for r in db.conn.execute(
        "SELECT e.learning_target t, e.skill k, e.outcome o, e.independence i, e.retention ret, e.recorded_at at "
        "FROM evidence e ORDER BY e.id").fetchall()]
    week_ev = [r for r in ev if inweek(r["at"])]
    assessed = [r for r in week_ev if r["o"] in ("successful", "partial", "unsuccessful")]

    # practice days and minutes
    from .practice_time import minutes_by_day
    by_day = minutes_by_day(db.conn, tz)
    day_minutes = [by_day.get((start + timedelta(days=k)).date(), 0.0) for k in range(7)]
    days_practiced = sum(1 for m in day_minutes if m > 0)
    minutes = round(sum(day_minutes))

    # pronunciation takes
    takes = []
    for r in db.conn.execute("SELECT started_at, response FROM attempt WHERE response_type='spoken' AND response LIKE '%score%'"):
        if inweek(r[0]):
            try:
                sc = json.loads(r[1]).get("score")
                if sc:                                  # skip failed takes (Azure heard nothing: 0)
                    takes.append(int(sc))
            except Exception:
                pass

    subjects = []
    for key, en, es_name, need in SUBJECTS:
        if key == "speaking":
            n = len(takes)
            pct = sum(takes) / n if n else None
            detail = (f"Average rating {round(pct)} of 100 over {n} takes." if not es else
                      f"Calificación promedio {round(pct)} de 100 en {n} intentos.") if n else ""
        elif key == "memory":
            rows = [r for r in assessed if r["ret"] == "delayed"]
            n = len(rows); ok = sum(1 for r in rows if r["o"] == "successful")
            pct = ok * 100 / n if n else None
            detail = (f"Remembered {ok} of {n} on later reviews." if not es else
                      f"Recordaste {ok} de {n} en repasos posteriores.") if n else ""
        elif key == "attendance":
            n = 7
            pct = min(100.0, days_practiced * 100 / 5)        # five days a week earns full marks
            detail = (f"Practiced {days_practiced} of 7 days, {minutes} min in all." if not es else
                      f"Practicaste {days_practiced} de 7 días, {minutes} min en total.")
            if days_practiced == 0 and (first is None or end <= first):
                pct = None                                   # no grade before you started, or for a week just begun
        else:
            rows = [r for r in assessed if r["k"] == key]
            n = len(rows); ok = sum(1 for r in rows if r["o"] == "successful")
            pct = ok * 100 / n if n else None
            detail = (f"{ok} of {n} answers correct." if not es else f"{ok} de {n} respuestas correctas.") if n else ""
        graded = pct is not None and n >= need
        g = letter(pct) if graded else "I"
        comment = (COMMENTS[g[0]][1 if es else 0].format(d=detail, tip=TIPS[key][1 if es else 0]).strip()
                   if graded else t["incomplete"])
        subjects.append({"key": key, "name": es_name if es else en, "grade": g,
                         "score": round(pct) if graded else None, "comment": comment, "graded": graded})

    graded = [s for s in subjects if s["graded"]]
    overall_pct = round(sum(s["score"] for s in graded) / len(graded)) if graded else None
    gpa_pts = {"A": 4.0, "B": 3.0, "C": 2.0, "D": 1.0, "F": 0.0}
    gpa = None
    if graded:
        tot = 0.0
        for s in graded:
            v = gpa_pts[s["grade"][0]] + (0.3 if s["grade"].endswith("+") and s["grade"][0] != "A" else 0) \
                - (0.3 if s["grade"].endswith("-") else 0)
            tot += v
        gpa = round(tot / len(graded), 2)

    # what we learned
    days = []
    for r in db.conn.execute("SELECT session_no, completed_at FROM session_progress WHERE status='completed' ORDER BY session_no"):
        if inweek(r[1]):
            s = state._session(r[0])
            days.append({"no": r[0], "title": s.get("title_es" if es else "title", "") or s["title"],
                         "sub": s["title"] if es else s.get("title_es", "")})
    first_own: dict = {}
    for r in ev:
        if r["o"] == "successful" and r["i"] == "independent" and r["t"] not in first_own:
            first_own[r["t"]] = r["at"]
    new_phr = []
    for target, at in first_own.items():
        if inweek(at):
            c = concept(target)
            if c.get("es"):
                new_phr.append({"es": c["es"], "en": c.get("en", "")})
    practiced = len({r["t"] for r in week_ev})
    basics = []
    try:
        for r in db.conn.execute("SELECT unit_id, completed_at FROM basics_progress WHERE completed_at IS NOT NULL"):
            if inweek(r[1]):
                u = next((u for u in state._basics_units if u["id"] == r[0]), None)
                if u:
                    basics.append(u.get("title_es") if es else u["title"])
    except Exception:
        pass
    scen = []
    try:
        for r in db.conn.execute("SELECT scenario_id, completed_at FROM scenario_progress WHERE completed_at IS NOT NULL"):
            if inweek(r[1]) and r[0] in state._scen:
                sc = state._scen[r[0]]
                scen.append(sc.get("title_es") if es else sc.get("title", r[0]))
    except Exception:
        pass

    # teacher's note
    note = ""
    if graded:
        best = max(graded, key=lambda s: s["score"])
        worst = min(graded, key=lambda s: s["score"])
        if es:
            note = f"Tu punto fuerte esta semana fue {best['name'].lower()} ({best['grade']})."
            if worst is not best and worst["score"] < 85:
                note += f" Para la próxima semana, enfócate en {worst['name'].lower()} ({worst['grade']})."
            note += " ¡Sigue así!" if overall_pct and overall_pct >= 80 else " Poco a poco se llega lejos."
        else:
            note = f"Your strongest subject this week was {best['name'].lower()} ({best['grade']})."
            if worst is not best and worst["score"] < 85:
                note += f" Next week, focus on {worst['name'].lower()} ({worst['grade']})."
            note += " Keep it up!" if overall_pct and overall_pct >= 80 else " Little by little, you'll get far."
    else:
        note = ("No hubo práctica calificable esta semana. Un poco cada día hace la diferencia."
                if es else "There wasn't enough practice to grade this week. A little every day makes the difference.")

    current = db.current_session(cur.total_sessions)
    return {
        "lang": lang, "offset": offset, "labels": t,
        "weekLabel": week_label(start, lang),
        "fileStem": f"Habla {'boleta' if es else 'report card'} {start.strftime('%Y-%m-%d')}",
        "isCurrent": offset == 0, "hasEarlier": (first is not None and first < start),
        "student": state._name() or ("Estudiante" if es else "Student"),
        "levelValue": t["levelv"].format(d=current),
        "subjects": subjects,
        "overallGrade": letter(overall_pct) if overall_pct is not None else "I",
        "overallScore": overall_pct, "gpa": gpa,
        "days": days, "newPhrases": new_phr[:12], "newPhrasesMore": max(0, len(new_phr) - 12),
        "newPhraseCount": len(new_phr), "practicedCount": practiced,
        "basics": basics, "scenarios": scen,
        "attendance": [{"d": (DAYS_ES if es else DAYS_EN)[(start + timedelta(days=k)).weekday()], "on": day_minutes[k] > 0,
                        "m": round(day_minutes[k])} for k in range(7)],
        "minutes": minutes, "daysPracticed": days_practiced,
        "note": note,
    }
