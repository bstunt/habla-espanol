"""Counts what Habla sends to Azure, per calendar month (UTC, like Azure's free tier):
characters turned into speech, and seconds of audio sent for pronunciation ratings.
Azure's own meter can't be read with a Speech key, so this is Habla's count on this Mac."""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path

FREE_TTS_CHARS = 500_000          # neural text-to-speech, F0 tier, per month
FREE_STT_SECONDS = 5 * 3600       # speech-to-text (pronunciation ratings), F0 tier, per month
FREE_TR_CHARS = 2_000_000         # Azure Translator, F0 tier, per month

_lock = threading.Lock()
_path: Path | None = None


def configure(path: Path) -> None:
    global _path
    _path = Path(path)


def month_key(now: datetime | None = None) -> str:
    return (now or datetime.now(timezone.utc)).astimezone(timezone.utc).strftime("%Y-%m")


def _load() -> dict:
    if _path is None:
        return {}
    try:
        return json.loads(_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: dict) -> None:
    if _path is None:
        return
    _path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _path.with_suffix(".part")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    tmp.replace(_path)


def _add(field: str, amount: float, now: datetime | None = None) -> None:
    with _lock:
        data = _load()
        m = data.setdefault(month_key(now), {})
        m[field] = m.get(field, 0) + amount
        _save(data)


def add_tts(chars: int, now: datetime | None = None) -> None:
    _add("tts", int(chars), now)


def add_translate(chars: int, now: datetime | None = None) -> None:
    _add("tr", int(chars), now)


def add_ai(tokens: int, now: datetime | None = None) -> None:
    _add("ai", int(tokens), now)
    _add("ai_calls", 1, now)


def add_stt(seconds: float, now: datetime | None = None) -> None:
    _add("stt", round(float(seconds), 2), now)


def this_month(now: datetime | None = None) -> dict:
    with _lock:
        m = _load().get(month_key(now), {})
    return {"tts": int(m.get("tts", 0)), "stt": float(m.get("stt", 0)), "tr": int(m.get("tr", 0)),
            "ai": int(m.get("ai", 0)), "ai_calls": int(m.get("ai_calls", 0)),
            "estimated": bool(m.get("estimated"))}


def backfill(months: dict[str, int]) -> None:
    """One-time estimate for downloads made before Habla started counting
    ({"YYYY-MM": characters}, from the downloaded files' dates)."""
    with _lock:
        data = _load()
        if data.get("_backfilled"):
            return
        for k, chars in months.items():
            m = data.setdefault(k, {})
            m["tts"] = m.get("tts", 0) + int(chars)
            m["estimated"] = True
        data["_backfilled"] = True
        _save(data)
