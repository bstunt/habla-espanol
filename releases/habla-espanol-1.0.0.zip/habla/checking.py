"""Deterministic answer checking. Honest and forgiving about form, strict about meaning.

- Case, ¿¡.,!;: and extra spaces never matter.
- Missing accents are accepted but reported (accent_note), because they matter in writing.
- {name} in an accepted answer matches the learner's name or any 1–3 words.
"""
from __future__ import annotations

import re
import unicodedata

_PUNCT = re.compile(r"[¿?¡!.,;:…\"“”'()\-]+")


def strip_accents(s: str) -> str:
    # keep ñ distinct from n (it is a different letter)
    s = s.replace("ñ", "\0").replace("Ñ", "\1")
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return s.replace("\0", "ñ").replace("\1", "Ñ")


def norm(s: str, accents: bool = True) -> str:
    s = _PUNCT.sub(" ", s.lower())
    if not accents:
        s = strip_accents(s)
    return " ".join(s.split())


def _pattern(accepted: str, accents: bool) -> re.Pattern:
    parts = norm(accepted, accents).split("{name}")
    rx = r"[a-zà-ÿñ]+(?: [a-zà-ÿñ]+){0,2}"
    body = rx.join(re.escape(p) for p in parts)
    return re.compile("^" + body + "$")


# Words where the accent changes the meaning, so a missing accent is a different word,
# not a spelling slip. (ñ vs n is already always distinct.)
MEANING_ACCENTS = {
    "papá": "Careful: papá (with the accent) is dad; papa is potato.",
    "papás": "Careful: papás (with the accent) is parents or dads; papas is potatoes.",
    "mamá": "Careful: write mamá with the accent for mom.",
}


def _meaning_slip(answer_exact: str, accepted: str) -> str:
    a, b = answer_exact.split(), norm(accepted, True).split()
    if len(a) != len(b):
        return ""
    for x, y in zip(a, b):
        if y in MEANING_ACCENTS and x != y and x == strip_accents(y):
            return MEANING_ACCENTS[y]
    return ""


def check_typed(answer: str, accept: list[str]) -> dict:
    """Returns {correct, accent_note, meaning_note}."""
    a_exact = norm(answer, True)
    a_loose = norm(answer, False)
    if not a_loose:
        return {"correct": False, "accent_note": False}
    for acc in accept:
        acc = acc.replace("{name}", "{name}")
        if _pattern(acc, True).match(a_exact):
            return {"correct": True, "accent_note": False, "meaning_note": ""}
    for acc in accept:
        if _pattern(acc, False).match(a_loose):
            slip = _meaning_slip(a_exact, acc)
            if slip:
                return {"correct": False, "accent_note": False, "meaning_note": slip}
            return {"correct": True, "accent_note": True}
    return {"correct": False, "accent_note": False}


def check_build(chosen: list[str], answer: list[str], alts: list[list[str]] | None = None) -> bool:
    return chosen == answer or any(chosen == a for a in (alts or []))
