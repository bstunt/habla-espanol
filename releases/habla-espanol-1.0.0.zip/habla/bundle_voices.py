"""Bundled voices for the gift edition.

The first time this app opens on a Mac that also has the full Habla (with its Azure
voices downloaded), it copies the voices this edition needs into its own app bundle,
compressed to AAC (.m4a, about 6x smaller than WAV). After that the app carries
every voice inside it, so it can be zipped and given to someone: they never need
an Azure key just to hear the lessons.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .voice import slug

MARKER = "bundle.json"
PLACEHOLDER = "Zqxvname"          # lines with the learner's name are skipped (the friend's name differs)


def bundled(dest: Path) -> bool:
    return (Path(dest) / MARKER).exists()


def needed(lines: list[dict]) -> list[tuple[str, str]]:
    """(source wav, target m4a) file names for every line the app can play."""
    out = []
    for ln in lines:
        if PLACEHOLDER.lower() in ln["text"].lower():
            continue
        base = slug(ln["text"])
        out.append((f"{base}.wav", f"{base}.m4a"))
        if ln.get("slow"):
            out.append((f"{base}.slow.wav", f"{base}.slow.m4a"))
    return out


def _convert(src: Path, dst: Path) -> bool:
    if dst.exists():
        return True
    tmp = dst.with_name(dst.stem + ".part.m4a")
    if sys.platform == "darwin" and Path("/usr/bin/afconvert").exists():
        r = subprocess.run(["/usr/bin/afconvert", "-f", "m4af", "-d", "aac", "-b", "56000", str(src), str(tmp)],
                           capture_output=True, timeout=60)
        if r.returncode != 0 or not tmp.exists():
            return False
        tmp.replace(dst)
        return True
    shutil.copyfile(src, dst.with_suffix(".wav"))        # elsewhere (tests): keep the WAV
    return True


def import_voices(src: Path, dest: Path, lines: list[dict], log=print) -> dict:
    src, dest = Path(src), Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    jobs = [(src / a, dest / b) for a, b in needed(lines) if (src / a).exists()]
    log(f"bundle_voices: {len(jobs)} voices to pack from {src}")
    with ThreadPoolExecutor(max_workers=8) as ex:
        ok = sum(ex.map(lambda j: _convert(*j), jobs))
    info = {"voices": ok, "of": len(needed(lines))}
    (dest / MARKER).write_text(json.dumps(info), encoding="utf-8")
    log(f"bundle_voices: packed {ok} voices")
    return info


def notify(msg: str):
    if sys.platform == "darwin":
        subprocess.Popen(["/usr/bin/osascript", "-e", f'display notification "{msg}" with title "Habla Español"'],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def all_lines(root: Path) -> list[dict]:
    """Every Spanish line this edition can play (lines with the learner's name are left out)."""
    import json as _json
    from .azure_voices import collect_lines
    from .content import Curriculum, load_basics, load_scenarios
    from .lab import load as lab_load, spanish_lines as lab_lines
    root = Path(root)
    cur = Curriculum.load(root / "content" / "v1" / "curriculum.json")
    basics = load_basics(root / "content" / "v1" / "basics.json")
    _, scenarios = load_scenarios(root / "content" / "v1" / "scenarios")
    extra = ["Hola, ¿cómo estás? Me llamo Ana. Mucho gusto."]
    try:
        extra += [w.get("es", "") for w in _json.loads((root / "content" / "v1" / "discover.json").read_text(encoding="utf-8")).get("words", [])]
    except Exception:
        pass
    extra += lab_lines(lab_load(root / "content" / "v1" / "lab"))
    return [ln for ln in collect_lines(cur, PLACEHOLDER, basics, list(scenarios.values()), extra)
            if PLACEHOLDER.lower() not in ln["text"].lower()]
