"""Automatic updates for Habla Español.

New versions are published on GitHub (manifest.json + a code zip, and sometimes a
voice pack). This app checks the manifest at launch and every few hours; when a newer
version exists it shows a banner and a Mac notification. "Update now" downloads the
files, checks their SHA-256, swaps the app's code folder (keeping the packed voices),
and restarts. Progress, settings and keys live outside the app, so they're untouched.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

from PySide6.QtCore import Property, QObject, QThread, QTimer, Signal, Slot

CHECK_EVERY_MS = 4 * 3600 * 1000


def parse_version(v: str) -> tuple:
    out = []
    for p in str(v or "0").strip().lstrip("v").split("."):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def newer(a: str, b: str) -> bool:
    """Is version a newer than b?"""
    return parse_version(a) > parse_version(b)


def _get(url: str, timeout=30):
    from .azure_voices import _request
    return _request(url, "", None, {"Accept": "application/octet-stream"}, timeout=timeout)


def fetch_manifest(url: str) -> dict:
    with _get(url + ("&" if "?" in url else "?") + f"t={int(time.time())}", timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


def download(url: str, dest: Path, sha256: str, progress=None) -> None:
    h = hashlib.sha256()
    with _get(url, timeout=60) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            got += len(chunk)
            if progress and total:
                progress(got / total)
    if sha256 and h.hexdigest() != sha256.lower():
        raise ValueError("the download didn't match (checksum). Nothing was changed.")


def _safe_extract(z: zipfile.ZipFile, dest: Path):
    dest = dest.resolve()
    for m in z.infolist():
        target = (dest / m.filename).resolve()
        if not str(target).startswith(str(dest)):
            raise ValueError("unsafe path in update")
    z.extractall(dest)


def apply_update(root: Path, code_zip: Path, voice_zips: list[Path]) -> None:
    """Swap Resources/habla for the new code; the packed voices move across."""
    root = Path(root)
    new = root.with_name(root.name + ".new")
    old = root.with_name(root.name + ".old")
    for d in (new, old):
        if d.exists():
            shutil.rmtree(d)
    new.mkdir()
    with zipfile.ZipFile(code_zip) as z:
        _safe_extract(z, new)
    if not (new / "main.py").exists():
        shutil.rmtree(new)
        raise ValueError("the update is incomplete. Nothing was changed.")
    voices_old = root / "assets" / "audio" / "voices"
    voices_new = new / "assets" / "audio" / "voices"
    if voices_old.is_dir():
        if voices_new.exists():
            shutil.rmtree(voices_new)
        voices_new.parent.mkdir(parents=True, exist_ok=True)
        os.rename(voices_old, voices_new)
    voices_new.mkdir(parents=True, exist_ok=True)
    for vz in voice_zips:
        with zipfile.ZipFile(vz) as z:
            _safe_extract(z, voices_new)
    os.rename(root, old)
    try:
        os.rename(new, root)
    except OSError:
        os.rename(old, root)                    # put it back exactly as it was
        if voices_new.is_dir() and not voices_old.exists():
            os.rename(voices_new, voices_old)
        raise
    shutil.rmtree(old, ignore_errors=True)


class _Job(QThread):
    done = Signal("QVariantMap")
    progress = Signal(float)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(self.progress.emit))
        except Exception as e:
            self.done.emit({"ok": False, "error": str(e)})


class Updater(QObject):
    """Exposed to QML as `updater`."""
    changed = Signal()

    def __init__(self, root: Path, settings=None, parent=None, auto=True):
        super().__init__(parent)
        self.root = Path(root)
        self.settings = settings
        try:
            self.version = (self.root / "VERSION").read_text(encoding="utf-8").strip()
        except OSError:
            self.version = "1.0.0"
        try:
            self.manifest_url = json.loads((self.root / "update.json").read_text(encoding="utf-8")).get("manifest", "")
        except Exception:
            self.manifest_url = ""
        self._m: dict = {}
        self._state = "idle"          # idle | checking | available | downloading | restarting | error | current
        self._error = ""
        self._progress = 0.0
        self._job = None
        self._notified = ""
        self._checked = ""
        if auto and self.manifest_url:
            QTimer.singleShot(8000, self.check)
            self._timer = QTimer(self)
            self._timer.setInterval(CHECK_EVERY_MS)
            self._timer.timeout.connect(self.check)
            self._timer.start()

    current = Property(str, lambda self: self.version, constant=True)
    enabled = Property(bool, lambda self: bool(self.manifest_url), constant=True)
    state = Property(str, lambda self: self._state, notify=changed)
    available = Property(bool, lambda self: self._state in ("available", "downloading", "error") and bool(self._m)
                         and newer(self._m.get("version", ""), self.version), notify=changed)
    latest = Property(str, lambda self: self._m.get("version", ""), notify=changed)
    notes = Property(str, lambda self: self._m.get("notes", ""), notify=changed)
    error = Property(str, lambda self: self._error, notify=changed)
    progress = Property(float, lambda self: self._progress, notify=changed)
    lastChecked = Property(str, lambda self: self._checked, notify=changed)

    def _busy(self):
        return self._job is not None and self._job.isRunning()

    @Slot()
    def check(self):
        if not self.manifest_url or self._busy() or self._state in ("downloading", "restarting"):
            return
        self._state, self._error = "checking", ""
        self.changed.emit()
        url = self.manifest_url
        self._run(lambda p: {"ok": True, "manifest": fetch_manifest(url)}, self._on_checked)

    def _on_checked(self, r):
        self._checked = time.strftime("%-I:%M %p")
        if not r.get("ok"):
            self._state, self._error = "idle", ""          # offline etc.: stay quiet, try again later
            self.changed.emit()
            return
        self._m = r["manifest"] or {}
        if newer(self._m.get("version", ""), self.version):
            self._state = "available"
            v = self._m.get("version", "")
            if self._notified != v:
                self._notified = v
                notify(f"Version {v} is ready. Open Habla Español to update.")
        else:
            self._state = "current"
        self.changed.emit()

    @Slot()
    def update(self):
        if not self._m or self._busy():
            return
        m = dict(self._m)
        root = self.root
        self._state, self._error, self._progress = "downloading", "", 0.0
        self.changed.emit()

        def work(progress):
            tmp = Path(tempfile.mkdtemp(prefix="habla-update-"))
            try:
                code = m.get("code") or {}
                packs = m.get("voices") or []
                parts = 1 + len(packs)
                cz = tmp / "code.zip"
                download(code["url"], cz, code.get("sha256", ""), lambda f: progress(f / parts))
                vz = []
                for k, p in enumerate(packs):
                    d = tmp / f"voices{k}.zip"
                    download(p["url"], d, p.get("sha256", ""), lambda f, k=k: progress((k + 1 + f) / parts))
                    vz.append(d)
                apply_update(root, cz, vz)
                return {"ok": True}
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        self._run(work, self._on_updated)

    def _on_updated(self, r):
        if not r.get("ok"):
            self._state, self._error = "error", "Couldn't update: " + r.get("error", "") + " Try again later."
            self.changed.emit()
            return
        self._state = "restarting"
        self.changed.emit()
        QTimer.singleShot(600, self.restart)

    @Slot()
    def restart(self):
        app = self.root.resolve().parent.parent.parent
        if sys.platform == "darwin" and app.suffix == ".app":
            subprocess.Popen(["/bin/sh", "-c", 'sleep 2; /usr/bin/open "$0"', str(app)])
        from PySide6.QtGui import QGuiApplication
        QGuiApplication.instance().quit()

    def _run(self, fn, done):
        job = _Job(fn)
        job.done.connect(done)
        job.progress.connect(self._on_progress)
        self._job = job
        job.start()

    def _on_progress(self, f):
        self._progress = max(0.0, min(1.0, float(f)))
        self.changed.emit()


def notify(msg: str):
    if sys.platform == "darwin":
        subprocess.Popen(["/usr/bin/osascript", "-e", f'display notification "{msg}" with title "Habla Español update"'],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
