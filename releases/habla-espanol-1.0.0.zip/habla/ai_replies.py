"""ChatGPT (OpenAI) checks of replies written in Conversation Lab. Optional: without a key,
the learner compares with the model replies. Sends only the message and the reply, as text."""
from __future__ import annotations

import json
import urllib.error

from . import azure_voices as az
from . import usage

KEYCHAIN_SERVICE = "Habla Espanol OpenAI"
URL = "https://api.openai.com/v1/chat/completions"
DEFAULT_MODEL = "gpt-5.4-mini"

def _chat(key: str, model: str, messages: list[dict], timeout: int = 20) -> dict:
    """One JSON chat completion: {"ok", "content", "tokens"} or {"ok": False, "error"}."""
    body = {"model": model or DEFAULT_MODEL, "messages": messages, "response_format": {"type": "json_object"}}
    try:
        with az._request(URL, "", json.dumps(body).encode("utf-8"),
                         {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        if e.code == 401:
            return {"ok": False, "error": "OpenAI rejected the API key. Check it in Settings › ChatGPT checks."}
        if e.code == 404 or "model" in msg.lower():
            return {"ok": False, "error": f"OpenAI doesn't recognize the model \"{model}\". Change it in Settings › ChatGPT checks."}
        if e.code == 429:
            return {"ok": False, "error": "OpenAI says you're out of credits or sending too fast."}
        return {"ok": False, "error": f"OpenAI returned an error ({e.code})."}
    except Exception:
        return {"ok": False, "error": "Couldn't reach OpenAI."}
    try:
        content = data["choices"][0]["message"]["content"]
    except Exception:
        return {"ok": False, "error": "ChatGPT's answer couldn't be read."}
    tokens = int((data.get("usage") or {}).get("total_tokens", 0) or 0)
    usage.add_ai(tokens)
    return {"ok": True, "content": content, "tokens": tokens}


# ---------- Conversation Lab: checking a reply the learner wrote ----------
CHECK_SYSTEM = (
    "You are a kind, honest Mexican Spanish teacher. Your student is an English-speaking adult, a beginner (A1-A2). "
    "They received a text message and wrote a reply in Spanish. Judge ONLY their reply. "
    "Criteria: understandable to a native speaker; grammatically appropriate (ignore missing accents, ¿ ¡ and capitals: "
    "they are normal in casual texting); relevant to the message; natural in Mexican Spanish; suitable for who sent it. "
    "{intent_rule}"
    "Verdict: \"natural\" (correct and sounds native), \"good\" (correct and clear, a little textbook or slightly off), "
    "\"fix\" (meaning comes through but there is a real grammar or word mistake), \"off\" (not understandable, "
    "not Spanish, or doesn't fit the message). Be encouraging but don't call a mistake correct. "
    "Write feedback in simple English, at most 2 short sentences, naming the single most useful fix. "
    "\"corrected\": their reply with only the mistakes fixed (same words otherwise; \"\" if nothing to fix). "
    "\"natural\": how a Mexican would most likely say the same thing, short. "
    "Reply with JSON only: {{\"verdict\": \"...\", \"means\": \"what their reply says, in English\", "
    "\"feedback\": \"...\", \"corrected\": \"...\", \"natural\": \"...\", \"natural_en\": \"...\"}}"
)

VERDICTS = ("natural", "good", "fix", "off")


def check_messages(incoming_es: str, incoming_en: str, sender: str, reply: str, intent: str = "") -> list[dict]:
    rule = (f"They were asked to: {intent} If their reply does something different but still fits the message, "
            "say so in feedback and judge it on its own merits. " if intent else
            "They chose freely what to say. ")
    user = (f"Message from {sender}: {incoming_es}\n(English: {incoming_en})\n\nTheir reply: {reply}")
    return [{"role": "system", "content": CHECK_SYSTEM.format(intent_rule=rule)}, {"role": "user", "content": user}]


def parse_check(content: str) -> dict:
    d = json.loads(content)
    v = str(d.get("verdict", "")).strip().lower()
    if v not in VERDICTS:
        raise ValueError("verdict")
    return {"verdict": v, "means": str(d.get("means", "")).strip(), "feedback": str(d.get("feedback", "")).strip(),
            "corrected": str(d.get("corrected", "")).strip(), "natural": str(d.get("natural", "")).strip(),
            "natural_en": str(d.get("natural_en", "")).strip()}


def check_reply(key: str, model: str, incoming_es: str, incoming_en: str, sender: str, reply: str,
                intent: str = "") -> dict:
    res = _chat(key, model, check_messages(incoming_es, incoming_en, sender, reply, intent))
    if not res.get("ok"):
        return res
    try:
        out = parse_check(res["content"])
    except Exception:
        return {"ok": False, "error": "ChatGPT's answer couldn't be read."}
    return {"ok": True, **out}
