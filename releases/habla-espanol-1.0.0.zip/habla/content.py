"""Curriculum content loading. Content lives in versioned JSON, never in code.

content/v1/curriculum.json      session map (30 sessions, concepts per session)
content/v1/sessions/sNN.json    full lesson content per session
"""
from __future__ import annotations

import copy
import json
import random
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Curriculum:
    version: str
    total_sessions: int
    sessions: dict[int, dict]
    concepts: dict[str, dict] = field(default_factory=dict)      # id -> {es, en, session}
    _index: dict[str, tuple[int, int, int]] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path | str) -> "Curriculum":
        path = Path(path)
        cmap = json.loads(path.read_text(encoding="utf-8"))
        sessions: dict[int, dict] = {}
        concepts: dict[str, dict] = {}
        index: dict[str, tuple[int, int, int]] = {}
        for entry in cmap["sessions"]:
            n = entry["no"]
            f = path.parent / "sessions" / f"s{n:02d}.json"
            if f.exists():
                s = json.loads(f.read_text(encoding="utf-8"))
                s.setdefault("minutes", 60)
                s["available"] = True
            else:
                s = {**entry, "modules": [], "objectives": [], "phrases": [], "available": False}
            for k in ("title", "title_es", "mission", "partner", "scope"):
                s.setdefault(k, entry.get(k, ""))
            for cid, c in entry.get("concepts", {}).items():
                concepts[cid] = {"es": c["es"], "en": c["en"], "session": n}
            for m in s.get("modules", []):
                for i, ex in enumerate(m["exercises"]):
                    if ex["id"] in index:
                        raise ValueError(f"Duplicate exercise id {ex['id']}")
                    index[ex["id"]] = (n, m["no"], i)
            sessions[n] = s
        return cls(cmap["version"], cmap["total_sessions"], sessions, concepts, index)

    def session(self, no: int) -> dict | None:
        return self.sessions.get(no)

    def locate(self, exercise_id: str) -> tuple[int, int, int] | None:
        """(session, module, index) for a stable exercise id."""
        return self._index.get(exercise_id)

    def exercise(self, exercise_id: str) -> dict | None:
        loc = self.locate(exercise_id)
        if not loc:
            return None
        s, m, i = loc
        mod = next(x for x in self.sessions[s]["modules"] if x["no"] == m)
        return mod["exercises"][i]


_NAME_RE = re.compile(r"\bSam\b")


def personalize(obj, name: str):
    """Replace the sample learner name 'Sam' with the learner's own name."""
    if not name:
        return obj
    if isinstance(obj, str):
        return _NAME_RE.sub(name, obj)
    if isinstance(obj, list):
        return [personalize(x, name) for x in obj]
    if isinstance(obj, dict):
        return {k: personalize(v, name) for k, v in obj.items()}
    return obj


def shuffled_tiles(tiles: list[str], answer: list[str], seed: str) -> list[str]:
    """Deterministic shuffle (stable across resume) that never shows the answer in order."""
    rnd = random.Random(seed)
    out = list(tiles)
    for _ in range(12):
        rnd.shuffle(out)
        if out[: len(answer)] != answer:
            break
    return out


def present(exercise: dict, name: str) -> dict:
    """Copy of an exercise prepared for the UI (name swap, shuffled tiles)."""
    ex = personalize(copy.deepcopy(exercise), name)
    if ex.get("type") == "build":
        ex["tiles"] = shuffled_tiles(ex["tiles"], ex["answer"], ex.get("id", ex["prompt"]))
    if ex.get("type") == "exit":
        for i, it in enumerate(ex["items"]):
            if it.get("type") == "build":
                it["tiles"] = shuffled_tiles(it["tiles"], it["answer"], f"{ex['id']}#{i}")
    return ex


# ---------- Basics (from-scratch practice units, always open) ----------
BASICS_TYPES = ("info", "listen_choose", "build", "type", "speak")


def load_basics(path: Path | str) -> list[dict]:
    """Units from content/v1/basics.json, or [] if the file isn't there yet.
    Exercises of unknown types are dropped so a content slip can't break the app."""
    path = Path(path)
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    units = []
    for u in data.get("units", []):
        exs = [e for e in u.get("exercises", []) if e.get("type") in BASICS_TYPES]
        if exs:
            units.append({**u, "exercises": exs})
    return units


# ---------- Vida Real (real-life scenarios, always open) ----------
SCENARIO_TYPES = ("info", "listen_choose", "dialogue", "build", "type", "speak", "conversation")


def load_scenarios(folder: Path | str) -> tuple[dict, dict[str, dict]]:
    """(manifest, {scenario id: scenario}) from content/v1/scenarios. Scenarios listed in the
    manifest without a file yet are shown as coming soon."""
    folder = Path(folder)
    mf = folder / "manifest.json"
    if not mf.exists():
        return {"categories": [], "scenarios": []}, {}
    manifest = json.loads(mf.read_text(encoding="utf-8"))
    full = {}
    for f in sorted(folder.glob("sc*.json")):
        s = json.loads(f.read_text(encoding="utf-8"))
        for st in s.get("stages", []):
            st["exercises"] = [e for e in st.get("exercises", []) if e.get("type") in SCENARIO_TYPES]
        full[s["id"]] = s
    return manifest, full
