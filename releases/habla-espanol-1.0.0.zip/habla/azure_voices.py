"""Realistic Mexican Spanish voices from Microsoft Azure Speech (free F0 tier).

The learner enters their own Azure key in Settings. Habla then downloads one WAV
per Spanish line into its data folder, day by day, in the background. Lessons
keep working the whole time: any line without a recording uses the Mac's voice.
After the download, everything works offline.

Each character gets a consistent es-MX voice (Ana, Diego, the server, ...), the
narrator has one voice, and the learner's own lines another.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
import wave
from datetime import datetime, timezone
from pathlib import Path
from xml.sax.saxutils import escape

from PySide6.QtCore import Property, QObject, QThread, Signal, Slot

from . import usage
from .content import Curriculum, personalize
from .voice import slug

FEMALE_PREF = ["es-MX-DaliaNeural", "es-MX-RenataNeural", "es-MX-BeatrizNeural", "es-MX-CandelaNeural",
               "es-MX-CarlotaNeural", "es-MX-LarissaNeural", "es-MX-MarinaNeural", "es-MX-NuriaNeural"]
MALE_PREF = ["es-MX-JorgeNeural", "es-MX-LibertoNeural", "es-MX-GerardoNeural", "es-MX-CecilioNeural",
             "es-MX-LucianoNeural", "es-MX-PelayoNeural", "es-MX-YagoNeural"]
# role -> (gender, index in that gender's pool)
ROLES = {
    "narrator": ("F", 0), "learner": ("M", 0),
    "Ana": ("F", 1), "Lupe": ("F", 2), "Guadalupe": ("F", 2), "Sofía": ("F", 3), "Mariana": ("F", 4),
    "Valeria": ("F", 5), "Turista": ("F", 6), "a stranger": ("F", 6),
    "Diego": ("M", 1), "Carlos": ("M", 2), "Alex": ("M", 3), "Mateo": ("M", 4),
    "Mesero": ("M", 5), "the server": ("M", 5), "Señor": ("M", 6),
    # Vida Real
    "Toño": ("M", 3), "Rodrigo": ("M", 4), "Daniel": ("M", 2), "Sr. Treviño": ("M", 6),
    "Paola": ("F", 3), "Sra. Ramírez": ("F", 5),
}
KEYCHAIN_SERVICE = "Habla Espanol Azure Speech"


def halves(text: str) -> list[str]:
    import re
    parts = [p.strip() for p in re.split(r"\s+/\s+", text or "") if p.strip()]
    return parts if len(parts) > 1 else []


def collect_lines(cur: Curriculum, name: str, basics: list[dict] | None = None,
                  scenarios: list[dict] | None = None, extra: list[str] | None = None) -> list[dict]:
    """Every Spanish line the learner can hear, in course order, with a speaker role."""
    out: dict[str, dict] = {}

    def rank(role):
        # A line the learner says in a conversation is always in the learner's voice,
        # and a character's line in that character's voice, even if the same
        # sentence also appears on a narrated phrase card.
        return 3 if role == "learner" else (1 if role == "narrator" else 2)

    def add(text, role, slow, session, gender=None):
        if not text or not text.strip():
            return
        text = personalize(text, name)
        if text in out:
            o = out[text]
            o["slow"] = o["slow"] or slow
            if role != o["role"]:
                o["mixed"] = True
                if rank(role) > rank(o["role"]):
                    o["role"] = role
                    o["gender"] = gender
            return
        out[text] = {"text": text, "role": role, "slow": slow, "session": session, "mixed": False, "gender": gender}

    def answers(ex, n):
        """Spanish played back after you answer: typed models and built sentences."""
        for e in [ex] + list(ex.get("items", [])):
            if e.get("type") == "type" and e.get("model"):
                add(e["model"], "narrator", True, n)
            elif e.get("type") == "build" and e.get("answer"):
                add(" ".join(e["answer"]), "narrator", True, n)

    for n in sorted(cur.sessions):
        s = cur.sessions[n]
        partner = s.get("partner", "Ana")
        for p in s.get("phrases", []):
            add(p["es"], "narrator", True, n)
        for c in s.get("concepts", {}).values():           # Vocabulary page, review, day tests
            add(c.get("es", ""), "narrator", True, n)
            for half in halves(c.get("es", "")):            # "A / B" words are asked one half at a time
                add(half, "narrator", True, n)
        for m in s.get("modules", []):
            for e in m["exercises"]:
                answers(e, n)
                t = e["type"]
                for ex in e.get("examples", []):
                    add(ex["es"], "narrator", True, n)
                if t == "listen_choose":
                    add(e["audio"], "narrator", True, n)
                elif t == "dialogue":
                    for ln in e["lines"]:
                        add(ln["es"], "learner" if ln["who"] == "Tú" else ln["who"], False, n)
                    hr = e.get("habla_real") or {}
                    for r in hr.get("como_responder", []):
                        add(r, "learner", False, n)
                elif t == "speak":
                    add(e["es"], "narrator", True, n)
                elif t == "conversation":
                    who = e.get("partner", partner)
                    for nd in e["nodes"].values():
                        add(nd["es"], who, False, n)
                        for o in nd.get("options", []):
                            add(o["es"], "learner", False, n)
                elif t == "exit":
                    for it in e["items"]:
                        if it.get("type") == "listen_choose":
                            add(it["audio"], "narrator", False, n)
    # Basics units come after the course (session number 31+ just orders the download)
    for k, u in enumerate(basics or []):
        n = cur.total_sessions + 1 + k
        for w in u.get("words", []):
            add(w["es"], "narrator", True, n)
        for e in u.get("exercises", []):
            answers(e, n)
            for ex in e.get("examples", []):
                add(ex["es"], "narrator", True, n)
            if e["type"] == "listen_choose":
                add(e["audio"], "narrator", True, n)
            elif e["type"] == "speak":
                add(e["es"], "narrator", True, n)
    # Vida Real scenarios come last
    for k, sc in enumerate(sorted(scenarios or [], key=lambda x: x["id"])):
        n = cur.total_sessions + 100 + k
        partner = sc.get("partner", "Ana")
        g = sc.get("cast", {})          # each scenario says who is a woman (F) or a man (M)
        for ph in sc.get("phrases", []):
            add(ph["es"], "narrator", True, n)
        for c in sc.get("concepts", {}).values():
            add(c.get("es", ""), "narrator", True, n)
            for half in halves(c.get("es", "")):
                add(half, "narrator", True, n)
        for st in sc.get("stages", []):
            for e in st["exercises"]:
                answers(e, n)
                for ex in e.get("examples", []):
                    add(ex["es"], "narrator", True, n)
                t = e["type"]
                if t == "listen_choose":
                    add(e["audio"], "narrator", True, n)
                elif t == "speak":
                    add(e["es"], "narrator", True, n)
                elif t == "dialogue":
                    for ln in e["lines"]:
                        add(ln["es"], "learner" if ln["who"] == "Tú" else ln["who"], False, n, g.get(ln["who"]))
                    for r in (e.get("habla_real") or {}).get("como_responder", []):
                        add(r, "learner", False, n)
                elif t == "conversation":
                    who = e.get("partner", partner)
                    for nd in e["nodes"].values():
                        add(nd["es"], nd.get("who", who), False, n, g.get(nd.get("who", who)))
                        for o in nd.get("options", []):
                            add(o["es"], "learner", False, n)
    # Date night: Spanish lines, read slowly and at normal speed
    for text in extra or []:
        add(text, "narrator", True, cur.total_sessions + 200)
    return list(out.values())


def character_count(lines: list[dict]) -> int:
    return sum(len(l["text"]) * (2 if l["slow"] else 1) for l in lines)


# ---------- Azure REST ----------
class AzureError(Exception):
    pass


def _ssl_context():
    """The bundled Python has no system certificate store; use certifi's."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


_CTX = None


def _request(url: str, key: str, data: bytes | None = None, headers: dict | None = None, timeout=30):
    global _CTX
    _CTX = _CTX or _ssl_context()
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET")
    if key:                                   # Azure key header (OpenAI calls pass their own auth)
        req.add_header("Ocp-Apim-Subscription-Key", key)
    req.add_header("User-Agent", "Habla")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout, context=_CTX)


def list_voices(key: str, region: str) -> list[dict]:
    url = f"https://{region}.tts.speech.microsoft.com/cognitiveservices/voices/list"
    try:
        with _request(url, key) as r:
            voices = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise AzureError("Azure rejected the key. Check the key and that the region matches your Speech resource.")
        raise AzureError(f"Azure returned an error ({e.code}).")
    except urllib.error.URLError:
        raise AzureError("Couldn't reach Azure. Check the region name and your internet connection.")
    return [v for v in voices if v.get("Locale") == "es-MX"]


def pick_voices(voices: list[dict]) -> dict[str, str]:
    names = {v["ShortName"]: v for v in voices}

    def pool(pref, gender):
        p = [n for n in pref if n in names]
        p += sorted(n for n, v in names.items() if v.get("Gender", "")[:1] == gender and n not in p
                    and "Multilingual" not in n)
        return p
    pools = {"F": pool(FEMALE_PREF, "F"), "M": pool(MALE_PREF, "M")}
    if not pools["F"] and not pools["M"]:
        raise AzureError("No Mexican Spanish voices were found for this region.")
    pools["F"] = pools["F"] or pools["M"]
    pools["M"] = pools["M"] or pools["F"]
    return {role: pools[g][i % len(pools[g])] for role, (g, i) in ROLES.items()}


def guess_gender(role: str) -> str:
    r = role.strip()
    if r.startswith(("Sra.", "Srta.", "Doña", "Dra.", "Lic. ") ) and not r.startswith("Lic. "):
        return "F"
    if r.startswith(("Sr.", "Don ", "Dr.")):
        return "M"
    return "F" if r.endswith("a") else "M"


def voice_for(role: str, cast: dict[str, str], gender: str | None = None) -> str:
    """A scenario's own cast list (gender) wins over the built-in roles, so a
    character never speaks in the wrong voice."""
    g = gender if gender in ("F", "M") else None
    if role in cast and (g is None or ROLES.get(role, (g, 0))[0] == g):
        return cast[role]
    g = g or guess_gender(role)
    # stable choice from the name, never the learner's or the narrator's own voice
    taken = {cast.get("learner"), cast.get("narrator")}
    same = [v for r, v in cast.items() if ROLES.get(r, ("", 0))[0] == g]
    choices = sorted(set(v for v in same if v not in taken)) or sorted(set(same)) or sorted(set(cast.values()))
    return choices[sum(map(ord, role)) % len(choices)]


def spoken(text: str) -> str:
    """What the voice should read: "Adiós / Hasta luego" -> "Adiós, hasta luego"."""
    import re
    t = re.sub(r"\s*/\s*", ", ", text)
    return t.replace("…", "...")


def synthesize(key: str, region: str, voice: str, text: str, slow: bool) -> bytes:
    rate = "-25%" if slow else "0%"
    ssml = ('<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="es-MX">'
            f'<voice name="{voice}"><prosody rate="{rate}">{escape(spoken(text))}</prosody></voice></speak>')
    url = f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1"
    with _request(url, key, ssml.encode("utf-8"), {
        "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm"}, timeout=60) as r:
        return r.read()


# ---------- macOS Keychain (optional "remember key") ----------
def keychain_get(service: str = KEYCHAIN_SERVICE) -> str:
    if sys.platform != "darwin":
        return ""
    try:
        return subprocess.run(["security", "find-generic-password", "-s", service, "-w"],
                              capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def keychain_set(key: str, service: str = KEYCHAIN_SERVICE) -> None:
    if sys.platform == "darwin":
        subprocess.run(["security", "add-generic-password", "-U", "-a", "habla", "-s", service, "-w", key],
                       capture_output=True, timeout=5)


def keychain_delete(service: str = KEYCHAIN_SERVICE) -> None:
    if sys.platform == "darwin":
        subprocess.run(["security", "delete-generic-password", "-s", service], capture_output=True, timeout=5)


# ---------- which voice made each downloaded file ----------
INDEX_FILE = "voices.json"


def load_index(out_dir: Path) -> dict:
    try:
        return json.loads((Path(out_dir) / INDEX_FILE).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_index(out_dir: Path, index: dict) -> None:
    p = Path(out_dir) / INDEX_FILE
    tmp = p.with_suffix(".part")
    tmp.write_text(json.dumps(index, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


# ---------- background download ----------
class _Worker(QThread):
    progress = Signal(int, int, int)          # done, total, current session
    failed = Signal(str)

    def __init__(self, key, region, lines, out_dir: Path, bundled: Path | None = None):
        super().__init__()
        self.key, self.region, self.lines, self.out = key, region, lines, Path(out_dir)
        self.bundled = bundled
        self.stop = False

    def run(self):
        try:
            cast = pick_voices(list_voices(self.key, self.region))
        except AzureError as e:
            self.failed.emit(str(e))
            return
        self.out.mkdir(parents=True, exist_ok=True)
        index = load_index(self.out)
        jobs = []
        for ln in self.lines:
            base = slug(ln["text"])
            jobs.append((ln, f"{base}.wav", False))
            if ln["slow"]:
                jobs.append((ln, f"{base}.slow.wav", True))
        total = len(jobs)
        gap = 0.4                       # seconds between requests; widens if Azure throttles
        for i, (ln, fname, slow) in enumerate(jobs):
            if self.stop:
                return
            dest = self.out / fname
            if self.bundled is not None and (self.bundled / fname.replace(".wav", ".m4a")).exists():
                self.progress.emit(i + 1, total, ln["session"])
                continue                       # already packed inside the app
            want = voice_for(ln["role"], cast, ln.get("gender"))
            have = index.get(fname)
            if dest.exists() and have is None and not ln.get("mixed"):
                index[fname] = want            # made before the index existed, voice is right
            if not dest.exists() or (have is not None and have != want) or (have is None and ln.get("mixed")):
                for attempt in range(6):
                    if self.stop:
                        return
                    try:
                        audio = synthesize(self.key, self.region, voice_for(ln["role"], cast, ln.get("gender")), ln["text"], slow)
                        tmp = dest.with_suffix(".part")
                        tmp.write_bytes(audio)
                        with wave.open(str(tmp)) as w:       # validate before keeping
                            w.getnframes()
                        tmp.replace(dest)
                        index[fname] = want
                        usage.add_tts(len(ln["text"]))     # Azure counts the spoken text
                        break
                    except urllib.error.HTTPError as e:
                        if e.code == 429:              # free tier rate limit: slow down and retry
                            gap = max(gap, 3.2)
                            time.sleep(float(e.headers.get("Retry-After", 10) or 10))
                            continue
                        if e.code in (401, 403):
                            self.failed.emit("Azure rejected the key while downloading.")
                            return
                        time.sleep(2 * (attempt + 1))
                    except Exception:
                        time.sleep(2 * (attempt + 1))
                time.sleep(gap)
            if (i + 1) % 25 == 0 or i + 1 == total:
                save_index(self.out, index)
            self.progress.emit(i + 1, total, ln["session"])


class AzureVoices(QObject):
    """Settings-facing controller for downloading Azure voices."""
    changed = Signal()
    voicesUpdated = Signal()

    def __init__(self, cur: Curriculum, out_dir: Path, settings, name_fn, parent=None, basics=None, scenarios=None, extra=None,
                 bundled_dir: Path | None = None):
        super().__init__(parent)
        self.bundled = Path(bundled_dir) if bundled_dir else None
        self.cur, self.out, self.settings, self.name_fn = cur, Path(out_dir), settings, name_fn
        self.basics = basics or []
        self.scenarios = scenarios or []
        self.extra = extra or []
        self._worker = None
        self._status = ""
        self._error = ""
        self._done = 0
        self._total = 0
        self._session = 0
        self._usage = {"tts": 0, "stt": 0.0, "estimated": False}
        self._refresh_counts()
        self._backfill_usage()
        self.refreshUsage()

    def _lines(self):
        return collect_lines(self.cur, self.name_fn(), self.basics, self.scenarios, self.extra)

    def _refresh_counts(self):
        lines = self._lines()
        index = load_index(self.out)
        have = 0
        total = 0

        def ok(fname, ln):
            if self.bundled is not None and (self.bundled / fname.replace(".wav", ".m4a")).exists():
                return True
            return (self.out / fname).exists() and (not ln.get("mixed") or fname in index)
        for ln in lines:
            base = slug(ln["text"])
            total += 1 + (1 if ln["slow"] else 0)
            have += ok(f"{base}.wav", ln) + (ln["slow"] and ok(f"{base}.slow.wav", ln))
        self._have, self._needed = have, total
        self._chars = character_count(lines)

    def _backfill_usage(self):
        """Downloads made before Habla counted usage: estimate from each file's date."""
        months: dict[str, int] = {}
        for ln in self._lines():
            base = slug(ln["text"])
            for f in (f"{base}.wav", f"{base}.slow.wav"):
                pth = self.out / f
                if pth.exists():
                    k = usage.month_key(datetime.fromtimestamp(pth.stat().st_mtime, timezone.utc))
                    months[k] = months.get(k, 0) + len(ln["text"])
        usage.backfill(months)

    @Slot()
    def refreshUsage(self):
        self._usage = usage.this_month()
        self.changed.emit()

    usedChars = Property(int, lambda self: self._usage["tts"], notify=changed)
    usedSttMinutes = Property(float, lambda self: round(self._usage["stt"] / 60, 1), notify=changed)
    usageEstimated = Property(bool, lambda self: self._usage["estimated"], notify=changed)
    freeChars = Property(int, lambda self: usage.FREE_TTS_CHARS, constant=True)
    freeSttMinutes = Property(int, lambda self: usage.FREE_STT_SECONDS // 60, constant=True)
    usedTrChars = Property(int, lambda self: self._usage.get("tr", 0), notify=changed)
    freeTrChars = Property(int, lambda self: usage.FREE_TR_CHARS, constant=True)
    aiCalls = Property(int, lambda self: self._usage.get("ai_calls", 0), notify=changed)
    aiTokens = Property(int, lambda self: self._usage.get("ai", 0), notify=changed)

    # ---- properties ----
    running = Property(bool, lambda self: self._worker is not None and self._worker.isRunning(), notify=changed)
    status = Property(str, lambda self: self._status, notify=changed)
    error = Property(str, lambda self: self._error, notify=changed)
    done = Property(int, lambda self: self._done, notify=changed)
    total = Property(int, lambda self: self._total, notify=changed)
    have = Property(int, lambda self: self._have, notify=changed)
    needed = Property(int, lambda self: self._needed, notify=changed)
    characters = Property(int, lambda self: self._chars, notify=changed)
    region = Property(str, lambda self: str(self.settings.value("azure_region", "westus2") or "westus2"), notify=changed)
    hasSavedKey = Property(bool, lambda self: bool(keychain_get()), notify=changed)

    @Slot(str, str, bool)
    def start(self, key: str, region: str, remember: bool):
        key = key.strip() or keychain_get()
        region = region.strip().lower().replace(" ", "")
        self._error = ""
        if not key or not region:
            self._error = "Enter your Azure Speech key and region."
            self.changed.emit()
            return
        self.settings.setValue("azure_region", region)
        if remember:
            keychain_set(key)
        if self._worker and self._worker.isRunning():
            return
        self._worker = _Worker(key, region, self._lines(), self.out, self.bundled)
        self._worker.progress.connect(self._on_progress)
        self._worker.failed.connect(self._on_failed)
        self._worker.finished.connect(self._on_finished)
        self._status = "Connecting to Azure…"
        self._worker.start()
        self.changed.emit()

    @Slot()
    def cancel(self):
        if self._worker:
            self._worker.stop = True
            self._status = "Stopping…"
            self.changed.emit()

    @Slot()
    def forgetKey(self):
        keychain_delete()
        self.changed.emit()

    def _on_progress(self, done, total, session):
        self._done, self._total, self._session = done, total, session
        where = (f"Day {session} of {self.cur.total_sessions}" if session <= self.cur.total_sessions
                 else ("Basics" if session < self.cur.total_sessions + 100
                       else ("Vida Real" if session < self.cur.total_sessions + 200 else "Date night")))
        self._status = f"Downloading {where} · {done:,} of {total:,} voice lines"
        if done % 25 == 0 or done == total:
            self._refresh_counts()      # keep "N of M recordings downloaded" in step with the bar
            self._usage = usage.this_month()
            self.voicesUpdated.emit()
        self.changed.emit()

    def _on_failed(self, msg):
        self._error = msg
        self._status = ""
        self.changed.emit()

    def _on_finished(self):
        self._refresh_counts()
        if not self._error:
            self._status = ("All lessons have realistic voices now." if self._have >= self._needed
                            else f"Stopped. {self._have:,} of {self._needed:,} recordings downloaded — press Download to continue.")
        self.voicesUpdated.emit()
        self.changed.emit()
