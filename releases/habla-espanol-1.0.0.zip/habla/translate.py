"""Type-and-translate, English <-> Mexican Spanish, with Azure Translator (its own key,
free tier 2 million characters a month). Habla detects which language you typed and
translates the other way. Spanish results can be read aloud in a realistic voice."""
from __future__ import annotations

import json
import urllib.error
from pathlib import Path

from PySide6.QtCore import Property, QObject, QThread, Signal, Slot

from . import azure_voices as az
from . import usage
from .voice import slug

KEYCHAIN_SERVICE = "Habla Azure Translator"
ENDPOINT = "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=es-MX&to=en"
SPEAK_VOICE = "es-MX-DaliaNeural"      # same narrator voice as the lessons
HISTORY_MAX = 30


def pick(data: list, text: str) -> dict:
    """From Translator's answer (both targets), keep the one in the *other* language."""
    item = data[0]
    det = (item.get("detectedLanguage") or {}).get("language", "en")
    outs = {t["to"].split("-")[0]: t["text"] for t in item.get("translations", [])}
    src = "es" if det.startswith("es") else "en"
    dst = "en" if src == "es" else "es"
    return {"source": text, "from": src, "to": dst, "text": outs.get(dst, ""),
            "confidence": round(float((item.get("detectedLanguage") or {}).get("score", 0) or 0), 2)}


def translate(key: str, region: str, text: str, force_to: str = "") -> dict:
    url = ENDPOINT if not force_to else (
        "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + ("es-MX" if force_to == "es" else "en"))
    headers = {"Content-Type": "application/json; charset=UTF-8"}
    if region:
        headers["Ocp-Apim-Subscription-Region"] = region
    try:
        with az._request(url, key, json.dumps([{"Text": text}]).encode("utf-8"), headers, timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"ok": False, "error": "Azure rejected the Translator key. Check the key and region in Settings › Translator."}
        if e.code == 429:
            return {"ok": False, "error": "Translator is busy (free-tier limit). Wait a moment and try again."}
        return {"ok": False, "error": f"Translator returned an error ({e.code})."}
    except Exception:
        return {"ok": False, "error": "Couldn't reach Azure Translator. Check your internet connection."}
    if force_to:
        item = data[0]
        det = (item.get("detectedLanguage") or {}).get("language", "")
        res = {"source": text, "from": "es" if det.startswith("es") else "en", "to": force_to,
               "text": item["translations"][0]["text"], "confidence": 1.0}
    else:
        res = pick(data, text)
    usage.add_translate(len(text) * (1 if force_to else 2))
    res["ok"] = True
    return res


class _Job(QThread):
    done = Signal("QVariantMap")

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn())
        except Exception as e:     # never crash the app
            self.done.emit({"ok": False, "error": str(e)})


class Translator(QObject):
    """Exposed to QML as `translator`."""
    changed = Signal()

    def __init__(self, settings, audio, voices_dir: Path, parent=None):
        super().__init__(parent)
        self.settings, self.audio, self.voices = settings, audio, Path(voices_dir)
        self._busy = False
        self._res: dict = {}
        self._jobs: list = []
        self._speaking = False
        try:
            self._history = json.loads(str(settings.value("translate_history", "[]") or "[]")) if settings is not None else []
        except Exception:
            self._history = []

    def _key(self):
        return az.keychain_get(KEYCHAIN_SERVICE)

    def _region(self):
        r = self.settings.value("translator_region", "") if self.settings is not None else ""
        return str(r or "")

    configured = Property(bool, lambda self: bool(self._key()), notify=changed)
    busy = Property(bool, lambda self: self._busy, notify=changed)
    result = Property("QVariantMap", lambda self: self._res, notify=changed)
    history = Property("QVariantList", lambda self: self._history, notify=changed)
    region = Property(str, lambda self: self._region(), notify=changed)
    speaking = Property(bool, lambda self: self._speaking, notify=changed)

    def _run(self, fn, on_done):
        job = _Job(fn)
        job.done.connect(on_done)
        job.finished.connect(lambda j=job: self._jobs.remove(j) if j in self._jobs else None)
        self._jobs.append(job)
        job.start()

    @Slot(str, str, bool)
    def setKey(self, key: str, region: str, remember: bool):
        key = key.strip()
        if key:
            az.keychain_set(key, KEYCHAIN_SERVICE)
        if self.settings is not None:
            self.settings.setValue("translator_region", region.strip())
        self.changed.emit()

    @Slot()
    def forgetKey(self):
        az.keychain_delete(KEYCHAIN_SERVICE)
        self.changed.emit()

    @Slot(str, str)
    def translate(self, text: str, force_to: str = ""):
        """force_to: "" = auto (opposite of what you typed), "es" or "en" to choose."""
        text = text.strip()
        if not text or self._busy:
            return
        key = self._key()
        if not key:
            self._res = {"ok": False, "error": "Add your Azure Translator key in Settings › Translator first."}
            self.changed.emit()
            return
        self._busy = True
        self.changed.emit()
        region = self._region()
        self._run(lambda: translate(key, region, text, force_to), self._on_result)

    def _on_result(self, res: dict):
        self._busy = False
        self._res = dict(res)
        if res.get("ok"):
            entry = {k: res[k] for k in ("source", "text", "from", "to")}
            self._history = [entry] + [h for h in self._history if h.get("source") != entry["source"]]
            self._history = self._history[:HISTORY_MAX]
            if self.settings is not None:
                self.settings.setValue("translate_history", json.dumps(self._history, ensure_ascii=False))
        self.changed.emit()

    @Slot()
    def clearHistory(self):
        self._history = []
        if self.settings is not None:
            self.settings.setValue("translate_history", "[]")
        self.changed.emit()

    @Slot(str, str, bool)
    def speak(self, text: str, lang: str, slow: bool):
        """English: the Mac's English voice. Spanish: the realistic Azure voice (made once,
        then kept like the lesson voices), or the Mac's Spanish voice without a key."""
        text = text.strip()
        if not text:
            return
        if lang != "es":
            self.audio.sayIn(text, "en-US", slow)
            return
        dest = self.voices / (slug(text) + (".slow.wav" if slow else ".wav"))
        key, region = az.keychain_get(), str(self.settings.value("azure_region", "") or "") if self.settings is not None else ""
        if dest.exists() or not key or not region:
            self.audio.say(text, slow)
            return
        self._speaking = True
        self.changed.emit()

        def make():
            audio = az.synthesize(key, region, SPEAK_VOICE, text, slow)
            self.voices.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(".part")
            tmp.write_bytes(audio)
            tmp.replace(dest)
            usage.add_tts(len(text))
            return {"ok": True}

        def done(res):
            self._speaking = False
            self.changed.emit()
            self.audio.say(text, slow)
        self._run(make, done)
