-- Habla local database, schema version 1.
-- Activity (what happened) is stored separately from inferences (what it means).
-- There is deliberately NO single "level" field anywhere: skill, independence,
-- transfer, retention, outcome and assessment source are independent columns.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS learner (
    id                 INTEGER PRIMARY KEY CHECK (id = 1),   -- single local learner
    display_name       TEXT NOT NULL DEFAULT '',
    personalization_on INTEGER NOT NULL DEFAULT 1,
    live_ai_consent    INTEGER NOT NULL DEFAULT 0,             -- explicit opt-in
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Which curriculum content version the learner's records refer to.
CREATE TABLE IF NOT EXISTS curriculum_version (
    version     TEXT PRIMARY KEY,
    installed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Completion only. Says nothing about ability.
CREATE TABLE IF NOT EXISTS session_progress (
    session_no   INTEGER PRIMARY KEY CHECK (session_no BETWEEN 1 AND 30),
    status       TEXT NOT NULL CHECK (status IN ('not_started','in_progress','completed')),
    started_at   TEXT,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS module_progress (
    session_no   INTEGER NOT NULL,
    module_no    INTEGER NOT NULL CHECK (module_no BETWEEN 1 AND 7),
    status       TEXT NOT NULL CHECK (status IN ('not_started','in_progress','completed','needs_review','evidence_unavailable')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (session_no, module_no)
);

-- Exact resume point: one row, replaced atomically on every step.
CREATE TABLE IF NOT EXISTS resume_checkpoint (
    id                 INTEGER PRIMARY KEY CHECK (id = 1),
    curriculum_version TEXT NOT NULL,
    session_no         INTEGER NOT NULL,
    module_no          INTEGER NOT NULL,
    exercise_id        TEXT NOT NULL,         -- stable content identifier
    step_state         TEXT NOT NULL DEFAULT '{}',  -- JSON: partial answer, revealed hints, etc.
    saved_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Raw activity: every attempt at an exercise.
CREATE TABLE IF NOT EXISTS attempt (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    curriculum_version TEXT NOT NULL,
    exercise_id        TEXT NOT NULL,
    session_no         INTEGER NOT NULL,
    module_no          INTEGER NOT NULL,
    input_type         TEXT NOT NULL,   -- audio_only | audio_text | text | image ...
    response_type      TEXT NOT NULL,   -- select | construct | typed | spoken | self_confirm | live_turn
    response           TEXT,            -- learner's answer (JSON or text)
    hints_used         INTEGER NOT NULL DEFAULT 0,
    replays_used       INTEGER NOT NULL DEFAULT 0,
    retry_no           INTEGER NOT NULL DEFAULT 0,
    started_at         TEXT NOT NULL,
    finished_at        TEXT,
    technical_status   TEXT NOT NULL DEFAULT 'ok'   -- ok | mic_unavailable | capture_failed | network_error
        CHECK (technical_status IN ('ok','mic_unavailable','capture_failed','network_error','permission_denied'))
);

-- Inference: what an attempt demonstrates. One attempt may produce several
-- evidence rows (e.g. listening + construction). Each dimension independent.
CREATE TABLE IF NOT EXISTS evidence (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    attempt_id         INTEGER NOT NULL REFERENCES attempt(id) ON DELETE CASCADE,
    learning_target    TEXT NOT NULL,   -- concept id, e.g. "c.me_llamo"
    skill              TEXT NOT NULL CHECK (skill IN ('listening','construction','speaking','interaction')),
    independence       TEXT NOT NULL CHECK (independence IN ('modeled','guided','independent')),
    transfer           TEXT NOT NULL CHECK (transfer IN ('practiced','novel')),
    retention          TEXT NOT NULL CHECK (retention IN ('immediate','delayed')),
    delay_seconds      INTEGER,          -- time since last exposure, for delayed evidence
    intervening_exposures INTEGER,       -- times seen between learning and this check
    context            TEXT,             -- scenario / exercise context
    outcome            TEXT NOT NULL CHECK (outcome IN ('successful','partial','unsuccessful','unassessed')),
    assessment_source  TEXT NOT NULL CHECK (assessment_source IN ('deterministic','self_review','human','validated_automated')),
    recorded_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS evidence_target ON evidence(learning_target);
CREATE INDEX IF NOT EXISTS evidence_skill ON evidence(skill);

CREATE TABLE IF NOT EXISTS recording (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    attempt_id   INTEGER REFERENCES attempt(id) ON DELETE SET NULL,
    file_name    TEXT NOT NULL,       -- relative to the app's recordings folder
    duration_ms  INTEGER NOT NULL,
    sample_rate  INTEGER NOT NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS conversation_turn (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    attempt_id   INTEGER REFERENCES attempt(id) ON DELETE CASCADE,
    mode         TEXT NOT NULL CHECK (mode IN ('offline_structured','live_ai')),
    scenario_id  TEXT NOT NULL,
    turn_no      INTEGER NOT NULL,
    speaker      TEXT NOT NULL CHECK (speaker IN ('learner','partner')),
    text         TEXT,
    branch_id    TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Spaced review. Rows are only created from stored evidence.
CREATE TABLE IF NOT EXISTS review_item (
    learning_target TEXT PRIMARY KEY,
    practice_type   TEXT NOT NULL,     -- e.g. "listen_respond", "production", "conversation"
    due_at          TEXT NOT NULL,
    interval_days   REAL NOT NULL,
    ease            REAL NOT NULL DEFAULT 2.5,
    last_outcome    TEXT
);

CREATE TABLE IF NOT EXISTS calibration_observation (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    stage       TEXT NOT NULL,
    key         TEXT NOT NULL,
    value       TEXT NOT NULL,
    recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS adaptation_decision (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    variable    TEXT NOT NULL,       -- e.g. "explanation_length"
    value       TEXT NOT NULL,
    reason      TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 1,   -- reversible
    decided_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
