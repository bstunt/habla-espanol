"""Application state exposed to QML. Every value shown comes from the curriculum
files and the local database; nothing about the learner is hardcoded."""
from __future__ import annotations

import json
import math
import random
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PySide6.QtCore import Property, QObject, QSettings, QUrl, Signal, Slot

from .checking import check_build, check_typed
from .content import Curriculum, present, personalize
from .db import Database, iso, utcnow

SKILL_META = [
    ("listening", "Listening", "headphones", "#1E6FD0"),
    ("construction", "Sentence building", "pencil", "#2E8F5E"),
    ("speaking", "Speaking", "mic", "#D9822B"),
    ("interaction", "Conversation", "message-circle", "#C9475F"),
]
SKILL_STATE_LABELS = {
    "unassessed": "Not assessed yet",
    "participation_only": "Practiced · not assessed",
    "attempted": "In practice",
    "guided": "Shown with support",
    "independent": "Shown independently",
    "transferred": "Used in a new situation",
    "retained": "Remembered after a delay",
}
OBJECTIVE_LABELS = {"pending": "not yet", "practiced": "practiced", "demonstrated": "demonstrated"}
PRACTICE = {
    "listen_respond": ("Listen and respond", "headphones", "#1A8FA0"),
    "production": ("Production practice", "square-pen", "#2E8F5E"),
    "comprehension": ("Comprehension review", "house", "#D9822B"),
    "conversation": ("Conversation", "message-circle", "#C9475F"),
}
SKILL_OF = {"listen_choose": "listening", "dialogue": "listening", "build": "construction",
            "type": "construction", "speak": "speaking", "conversation": "interaction"}
PRACTICE_OF = {"listening": "listen_respond", "construction": "production", "interaction": "conversation"}
EXIT_PASS = 0.7


def due_label(due_at: str) -> tuple[str, bool]:
    due = datetime.strptime(due_at, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    days = (due - utcnow()).total_seconds() / 86400
    if days <= 0.5:
        return "Today", True
    n = math.ceil(days)
    return ("Tomorrow", False) if n == 1 else (f"In {n} days", False)


class AppState(QObject):
    dashChanged = Signal()
    wsChanged = Signal()
    testChanged = Signal()
    screenChanged = Signal()
    libraryChanged = Signal()     # course / vocab / progress / review / conversations / settings data
    reviewChanged = Signal()
    basicsChanged = Signal()
    sectionRequested = Signal(str)   # ask the window to show a sidebar section

    def __init__(self, db: Database, curriculum: Curriculum, assets: Path, audio, voice=None,
                 demo: bool = False, placeholder_tags: bool = True, settings: QSettings | None = None,
                 daily_lock: bool = True, now=None):
        super().__init__()
        self._daily_lock = daily_lock
        self._basics_units: list[dict] = []
        self._bpos: tuple[int, int] | None = None          # Basics: (unit index, exercise index)
        self._basics: dict = {}
        self._scen: dict[str, dict] = {}                   # Vida Real: id -> scenario
        self._scen_manifest: dict = {"categories": [], "scenarios": []}
        self._spos: tuple[str, int, int] | None = None     # (scenario id, stage no, exercise index)
        self._smode = "guided"
        self._run: dict = {}
        self._discover: list = []
        self._now = now or (lambda: datetime.now().astimezone())    # local time; injectable for tests
        self.db, self.cur, self.assets, self.audio, self.voice = db, curriculum, Path(assets), audio, voice
        self._demo = demo
        self._tags = placeholder_tags
        self._settings = settings
        self._screen = "dashboard"
        self._dash: dict = {}
        self._ws: dict = {}
        self._lib: dict = {}
        self._review: dict = {}
        self._pos: tuple[int, int, int] | None = None     # session, module, exercise index
        self._state: dict = {}                             # per-exercise UI state (resume)
        self._hints = 0
        self._started = utcnow()
        self._single = False                               # practicing one exercise from a list
        self._replay = ""                                  # redoing a finished day: "one" lesson or "all" of it
        self._replay_from = ""                             # where to go back to afterwards
        self._summary: dict = {}
        audio.recordingSaved.connect(self._on_recording)
        self.rebuild()

    # ---------- properties ----------
    dash = Property("QVariantMap", lambda self: self._dash, notify=dashChanged)
    ws = Property("QVariantMap", lambda self: self._ws, notify=wsChanged)
    screen = Property(str, lambda self: self._screen, notify=screenChanged)
    lib = Property("QVariantMap", lambda self: self._lib, notify=libraryChanged)
    review = Property("QVariantMap", lambda self: self._review, notify=reviewChanged)
    summary = Property("QVariantMap", lambda self: self._summary, notify=screenChanged)
    basics = Property("QVariantMap", lambda self: self._basics, notify=basicsChanged)
    discoverChanged = Signal()
    discover = Property("QVariantList", lambda self: self._discover, notify=discoverChanged)

    def set_discover(self, data: dict):
        """Home carousel: random Spanish words and Mexican culture facts, interleaved."""
        rnd = random.Random()
        words = [{"kind": "word", "es": w["es"], "en": w["en"], "example": w.get("example", ""),
                  "exampleEn": w.get("example_en", "")} for w in (data or {}).get("words", [])]
        facts = [{"kind": "fact", "text": f} for f in (data or {}).get("facts", [])]
        rnd.shuffle(words); rnd.shuffle(facts)
        mixed = []
        while words or facts:
            if words: mixed.append(words.pop())
            if facts: mixed.append(facts.pop())
        if rnd.random() < 0.5 and len(mixed) > 1:
            mixed = mixed[1:] + mixed[:1]
        self._discover = mixed
        self.discoverChanged.emit()
    themeChanged = Signal()

    def _get_theme(self) -> str:
        return str(self._settings.value("theme", "talavera") or "talavera") if self._settings is not None else "talavera"

    themeName = Property(str, _get_theme, notify=themeChanged)

    @Slot(str)
    def setTheme(self, name: str):
        if self._settings is not None:
            self._settings.setValue("theme", name)
        self.themeChanged.emit()
    demoMode = Property(bool, lambda self: self._demo, constant=True)
    showPlaceholderTags = Property(bool, lambda self: self._tags, constant=True)

    @Slot(str, result=str)
    def assetUrl(self, rel: str) -> str:
        return QUrl.fromLocalFile(str(self.assets / rel)).toString()

    def _name(self) -> str:
        return self.db.learner()["display_name"]

    def _session(self, n: int) -> dict:
        return self.cur.session(n) or {"no": n, "title": "Coming soon", "title_es": "", "mission": "",
                                       "minutes": 60, "modules": [], "objectives": [], "phrases": [],
                                       "available": False}

    def _set_screen(self, name: str):
        self._screen = name
        self.screenChanged.emit()

    # ---------- speaking skipped without a microphone ----------
    def _ensure_skip_table(self):
        with self.db.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS skipped_speaking (exercise_id TEXT PRIMARY KEY, "
                      "skipped_at TEXT NOT NULL DEFAULT (datetime('now')))")

    def _current_exercise_id(self) -> str | None:
        if self._bpos is None and not self._pos and self._spos is None:
            return None
        return self._raw()["id"]

    @Slot()
    def skipSpeaking(self):
        """Learner had no microphone: move on now, come back to this one later."""
        eid = self._current_exercise_id()
        if not eid:
            return
        self._ensure_skip_table()
        with self.db.tx() as c:
            c.execute("INSERT OR REPLACE INTO skipped_speaking(exercise_id) VALUES(?)", (eid,))

    def _clear_skip(self, eid: str):
        self._ensure_skip_table()
        with self.db.tx() as c:
            c.execute("DELETE FROM skipped_speaking WHERE exercise_id=?", (eid,))

    def _skipped_list(self) -> list[dict]:
        self._ensure_skip_table()
        out = []
        for r in self.db.conn.execute("SELECT exercise_id FROM skipped_speaking ORDER BY skipped_at"):
            eid = r[0]
            if eid.startswith("sc"):
                sid = eid.split(".")[0]
                sc = self._scen.get(sid)
                ex = next((e for st in (sc or {}).get("stages", []) for e in st["exercises"] if e["id"] == eid), None)
                if ex:
                    out.append({"id": eid, "es": ex.get("es", ""), "en": ex.get("en", ""), "where": "Vida Real · " + sc["title"]})
                continue
            if eid.startswith("b"):
                unit = next((u for u in self._basics_units if eid.startswith(u["id"] + ".")), None)
                ex = next((e for e in (unit or {}).get("exercises", []) if e["id"] == eid), None)
                if ex:
                    out.append({"id": eid, "es": ex["es"], "en": ex.get("en", ""), "where": "Basics · " + unit["title"]})
            else:
                loc = self.cur.locate(eid)
                if loc:
                    ex = self._mod(self._session(loc[0]), loc[1])["exercises"][loc[2]]
                    out.append({"id": eid, "es": ex.get("es", ""), "en": ex.get("en", ""),
                                "where": f"Day {loc[0]} · {self._session(loc[0])['title']}"})
        return out

    @Slot(str)
    def practiceSkipped(self, eid: str):
        """Open a skipped speaking exercise on its own."""
        if eid.startswith("sc"):
            sid = eid.split(".")[0]
            sc = self._scen.get(sid)
            for st in (sc or {}).get("stages", []):
                for i, e in enumerate(st["exercises"]):
                    if e["id"] == eid:
                        self._single = True
                        self._run = {}
                        self._scen_enter(sid, st["no"], i, single=True)
                        self._set_screen("workspace")
                        return
            return
        if eid.startswith("b"):
            for k, u in enumerate(self._basics_units):
                for i, e in enumerate(u["exercises"]):
                    if e["id"] == eid:
                        self._single = True
                        self._basics_enter(k, i)
                        self._ws = {**self._ws, "single": True}
                        self.wsChanged.emit()
                        self._set_screen("workspace")
                        return
            return
        self.practiceExercise(eid)
        self._return_to = "revision"

    # ---------- Basics (always open, practice only) ----------
    def set_basics(self, units: list[dict]):
        self._basics_units = units or []
        with self.db.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS basics_progress (unit_id TEXT PRIMARY KEY, "
                      "furthest INTEGER NOT NULL DEFAULT 0, completed_at TEXT, times_completed INTEGER NOT NULL DEFAULT 0)")
        self._refresh_basics()

    def _basics_rows(self) -> dict:
        try:
            return {r["unit_id"]: r for r in self.db.conn.execute("SELECT * FROM basics_progress")}
        except Exception:
            return {}

    def _refresh_basics(self):
        rows = self._basics_rows()
        units = []
        for k, u in enumerate(self._basics_units):
            r = rows.get(u["id"])
            n = len(u["exercises"])
            done = bool(r and r["completed_at"])
            furthest = r["furthest"] if r else 0
            units.append({"index": k, "id": u["id"], "title": u["title"], "titleEs": u.get("title_es", ""),
                          "emoji": u.get("emoji", ""), "desc": u.get("desc", ""), "minutes": u.get("minutes", 10),
                          "count": n, "words": u.get("words", []),
                          "status": "completed" if done else ("in_progress" if furthest > 0 else "not_started"),
                          "progress": 1.0 if done else min(1.0, furthest / max(1, n)),
                          "timesCompleted": r["times_completed"] if r else 0})
        self._basics = {"available": bool(units), "units": units,
                        "completed": sum(1 for x in units if x["status"] == "completed")}
        self.basicsChanged.emit()

    def _basics_save(self, unit_id: str, furthest: int | None = None, completed: bool = False):
        with self.db.tx() as c:
            c.execute("INSERT INTO basics_progress(unit_id, furthest) VALUES(?, 0) ON CONFLICT(unit_id) DO NOTHING", (unit_id,))
            if furthest is not None:
                c.execute("UPDATE basics_progress SET furthest = MAX(furthest, ?) WHERE unit_id=?", (furthest, unit_id))
            if completed:
                c.execute("UPDATE basics_progress SET completed_at=datetime('now'), times_completed=times_completed+1, "
                          "furthest=0 WHERE unit_id=?", (unit_id,))

    @Slot(int)
    def openBasics(self, unit_index: int):
        if not 0 <= unit_index < len(self._basics_units):
            return
        u = self._basics_units[unit_index]
        r = self._basics_rows().get(u["id"])
        start = r["furthest"] if r and not r["completed_at"] and r["furthest"] < len(u["exercises"]) else 0
        self._single = False
        self._basics_enter(unit_index, start)
        self._set_screen("workspace")

    def _basics_enter(self, u: int, i: int):
        unit = self._basics_units[u]
        self._pos = None
        self._bpos = (u, i)
        self._state = {}
        self._hints = 0
        self._started = utcnow()
        self.audio.clearRecording()
        self.audio.stopAll()
        self._basics_save(unit["id"], furthest=i)
        n = len(unit["exercises"])
        rows = self._basics_rows()
        name = self._name()
        self._ws = {
            "basics": True,
            "sessionNo": 0, "sessionTitle": "Basics", "partner": "Ana",
            "moduleNo": u + 1, "moduleTitle": unit["title"],
            "exerciseIndex": i + 1, "exerciseCount": n,
            "overallIndex": i + 1, "overallCount": n,
            "minutesLeft": max(1, round(unit.get("minutes", 10) * (1 - i / max(1, n)))),
            "mission": unit.get("desc", ""),
            "exercise": present(unit["exercises"][i], name),
            "exerciseId": unit["exercises"][i]["id"],
            "state": {}, "learnerName": name or "Sam", "single": False,
            "phrases": unit.get("words", [])[:8],
            "modules": [{"no": k + 1, "title": x["title"],
                         "status": "completed" if (rows.get(x["id"]) and rows[x["id"]]["completed_at"]) else "not_started"}
                        for k, x in enumerate(self._basics_units)],
        }
        self.wsChanged.emit()

    def _basics_advance(self):
        u, i = self._bpos
        if self._single:
            self._single = False
            self._bpos = None
            self.audio.stopAll()
            self.rebuild(); self.refreshLibrary()
            self._set_screen("dashboard")
            self.sectionRequested.emit("revision")
            return
        unit = self._basics_units[u]
        if i + 1 < len(unit["exercises"]):
            self._basics_enter(u, i + 1)
            return
        self._basics_save(unit["id"], completed=True)
        self.audio.stopAll()
        self._bpos = None
        self._refresh_basics()
        self.rebuild()
        self._set_screen("dashboard")
        self.sectionRequested.emit("basicos")

    @Slot(str)
    def goTo(self, section: str):
        """Leave the current screen and show a sidebar section (e.g. from the summary)."""
        self._pos = None
        self.backToDashboard()
        self.sectionRequested.emit(section)

    # ---------- Vida Real (real-life scenarios, always open) ----------
    def set_scenarios(self, manifest: dict, scenarios: dict[str, dict]):
        self._scen_manifest, self._scen = manifest or {"categories": [], "scenarios": []}, scenarios or {}
        for sc in self._scen.values():                       # scenario phrases join review like course concepts
            for cid, c in sc.get("concepts", {}).items():
                self.cur.concepts.setdefault(cid, {**c, "session": 0})
        with self.db.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS scenario_progress (scenario_id TEXT PRIMARY KEY, "
                      "stage INTEGER NOT NULL DEFAULT 1, idx INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT '{}', "
                      "run TEXT NOT NULL DEFAULT '{}', mode TEXT NOT NULL DEFAULT 'guided', started_at TEXT, "
                      "completed_at TEXT, times_completed INTEGER NOT NULL DEFAULT 0, last_at TEXT)")

    def _stage(self, sid: str, no: int) -> dict:
        return next(st for st in self._scen[sid]["stages"] if st["no"] == no)

    def _scen_flat(self, sid: str) -> list[tuple[int, int]]:
        return [(st["no"], i) for st in self._scen[sid]["stages"] for i in range(len(st["exercises"]))]

    def _scen_row(self, sid: str):
        return self.db.conn.execute("SELECT * FROM scenario_progress WHERE scenario_id=?", (sid,)).fetchone()

    def _scen_save(self):
        if self._spos is None or self._single:
            return
        sid, st, i = self._spos
        with self.db.tx() as c:
            c.execute("INSERT INTO scenario_progress(scenario_id, stage, idx, state, run, mode, started_at, last_at) "
                      "VALUES(?,?,?,?,?,?,datetime('now'),datetime('now')) ON CONFLICT(scenario_id) DO UPDATE SET "
                      "stage=excluded.stage, idx=excluded.idx, state=excluded.state, run=excluded.run, mode=excluded.mode, "
                      "last_at=excluded.last_at",
                      (sid, st, i, json.dumps(self._state), json.dumps(self._run), self._smode))

    @Slot(str, str)
    def startScenario(self, sid: str, mode: str):
        """Start a scenario from the beginning in Guided, Assisted or Independent mode."""
        if sid not in self._scen:
            return
        self._smode = mode if mode in ("guided", "assisted", "independent") else "guided"
        self._single = False
        self._run = {"mode": self._smode}
        self._scen_enter(sid, 1, 0)
        self._set_screen("workspace")

    @Slot(str)
    def resumeScenario(self, sid: str):
        """Pick up exactly where you left off."""
        r = self._scen_row(sid)
        if sid not in self._scen or r is None or r["completed_at"] and r["idx"] == 0 and r["stage"] == 1:
            return self.startScenario(sid, r["mode"] if r else "guided")
        self._smode = r["mode"]
        self._single = False
        self._run = json.loads(r["run"] or "{}")
        flat = self._scen_flat(sid)
        st, i = (r["stage"], r["idx"]) if (r["stage"], r["idx"]) in flat else flat[0]
        self._scen_enter(sid, st, i, state=json.loads(r["state"] or "{}"))
        self._set_screen("workspace")

    def _scen_enter(self, sid: str, st: int, i: int, state: dict | None = None, single: bool = False):
        sc = self._scen[sid]
        self._pos, self._bpos = None, None
        self._spos = (sid, st, i)
        self._state = state or {}
        self._hints = 0
        self._started = utcnow()
        self.audio.clearRecording()
        self.audio.stopAll()
        stage = self._stage(sid, st)
        flat = self._scen_flat(sid)
        name = self._name()
        mode = self._smode
        statuses = []
        for x in sc["stages"]:
            statuses.append({"no": x["no"], "title": x["title"],
                             "status": "completed" if x["no"] < st else "not_started"})
        statuses.append({"no": 7, "title": "Debrief", "status": "not_started"})
        ex = present(stage["exercises"][i], name)
        self._ws = {
            "scenario": True, "scenarioId": sid, "mode": mode,
            "sessionNo": 0, "sessionTitle": sc["title_es"], "partner": sc.get("partner", "Ana"),
            "moduleNo": st, "moduleTitle": stage["title"],
            "exerciseIndex": i + 1, "exerciseCount": len(stage["exercises"]),
            "overallIndex": flat.index((st, i)) + 1, "overallCount": len(flat),
            "minutesLeft": max(1, round(sc.get("minutes", 10) * (1 - flat.index((st, i)) / max(1, len(flat))))),
            "mission": sc.get("goal", ""), "exercise": ex, "exerciseId": stage["exercises"][i]["id"],
            "state": self._state, "learnerName": name or "Sam", "single": single,
            "phrases": sc.get("phrases", []), "modules": statuses,
        }
        self._scen_save()
        self.wsChanged.emit()

    def _scen_record(self, part, item, skill, response, correct, retry, response_type, partial,
                     translation_shown, outcome, source):
        sid, st, _ = self._spos
        ex = self._raw()
        targets = item.get("targets") or ex.get("targets", [])
        outcome = outcome or ("successful" if correct else ("partial" if partial else "unsuccessful"))
        helped = self._smode == "guided" or self._hints > 0 or retry > 0 or translation_shown
        tally = self._run.setdefault("tally", {})
        t = tally.setdefault(skill, [0, 0, 0])               # successful, assessed, unassessed
        if outcome == "unassessed":
            t[2] += 1
        else:
            t[1] += 1
            t[0] += outcome == "successful"
            if outcome != "successful":
                missed = self._run.setdefault("missed", [])
                missed += [c for c in targets if c not in missed]
        evidence = []
        for c in targets:
            last = self.db.last_evidence_at(c)
            delayed = last is not None and (utcnow() - last).total_seconds() > 20 * 3600
            evidence.append({
                "learning_target": c, "skill": skill,
                "independence": "guided" if helped else "independent",
                "transfer": "novel" if st == 6 else "practiced",
                "retention": "delayed" if delayed else "immediate",
                "delay_seconds": int((utcnow() - last).total_seconds()) if last else None,
                "context": f"vr.{sid}", "outcome": outcome, "assessment_source": source,
                "practice_type": PRACTICE_OF.get(skill, "listen_respond")})
        self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=f"{ex['id']}#{part}" if part else ex["id"],
            session_no=0, module_no=st, input_type="audio_only" if skill == "listening" else "text",
            response_type=response_type, response=response, hints_used=self._hints, retry_no=retry,
            started_at=self._started, evidence=evidence)
        self._started = utcnow()

    def _scen_advance(self):
        sid, st, i = self._spos
        if self._single:
            self._single = False
            self._spos = None
            self.refreshLibrary(); self.rebuild()
            self._set_screen("dashboard")
            self.sectionRequested.emit("revision")
            return
        flat = self._scen_flat(sid)
        k = flat.index((st, i))
        if k + 1 < len(flat):
            self._scen_enter(sid, *flat[k + 1])
            return
        self._scen_debrief(sid)

    def _scen_debrief(self, sid: str):
        sc = self._scen[sid]
        run = self._run
        tally = run.get("tally", {})
        conv = run.get("conv", {"good": 0, "repair": 0, "off": 0})
        sp = run.get("speak", {"rated": 0, "best": 0})

        def pair(skill):
            t = tally.get(skill, [0, 0, 0])
            return {"correct": t[0], "assessed": t[1], "unassessed": t[2]}
        missed = [{"es": sc["concepts"][c]["es"], "en": sc["concepts"][c]["en"]}
                  for c in run.get("missed", []) if c in sc.get("concepts", {})]
        with self.db.tx() as c:
            c.execute("UPDATE scenario_progress SET completed_at=datetime('now'), times_completed=times_completed+1, "
                      "stage=1, idx=0, state='{}', run='{}', last_at=datetime('now') WHERE scenario_id=?", (sid,))
        self._summary = {
            "kind": "scenario", "scenarioId": sid, "title": sc["title"], "titleEs": sc["title_es"], "emoji": sc.get("emoji", ""),
            "goal": sc.get("goal", ""), "realLife": sc.get("real_life", ""),
            "mode": self._smode,
            "listening": pair("listening"), "construction": pair("construction"),
            "conversation": conv, "hints": run.get("hints", 0), "english": bool(run.get("english")),
            "speakingRated": sp["rated"], "speakingBest": sp["best"],
            "review": missed,
            "reviewsScheduled": self.db.conn.execute("SELECT COUNT(*) FROM review_item").fetchone()[0],
        }
        self._spos = None
        self._run = {}
        self.refreshLibrary(); self.rebuild()
        self._set_screen("summary")

    @Slot(str, result="QVariantMap")
    def conversationMatch(self, node: str, text: str) -> dict:
        """A typed or spoken reply in a conversation: which reply option does it match?
        Unmatched replies are not evaluated (never marked wrong)."""
        ex = self._raw()
        opts = ex["nodes"][node].get("options", [])
        for k, o in enumerate(opts):
            name = self._name() or "Sam"
            res = check_typed(text, personalize([o["es"]] + list(o.get("accept", [])), name))
            if res["correct"]:
                return {"index": k, "accentNote": res["accent_note"]}
        self._record(f"n:{node}", ex, "interaction", text, False, 0, "typed", outcome="unassessed")
        return {"index": -1}

    def _vida_real_library(self) -> dict:
        rows = {}
        try:
            rows = {r["scenario_id"]: r for r in self.db.conn.execute("SELECT * FROM scenario_progress")}
        except Exception:
            pass
        current = self.db.current_session(self.cur.total_sessions)
        cats = []
        for cat in self._scen_manifest.get("categories", []):
            items = []
            for m in self._scen_manifest.get("scenarios", []):
                if m["category"] != cat["id"]:
                    continue
                sc = self._scen.get(m["id"])
                r = rows.get(m["id"])
                started = bool(r) and (r["stage"] > 1 or r["idx"] > 0)
                status = "soon" if not sc else ("in_progress" if started else
                                                 ("completed" if r and r["completed_at"] else "new"))
                after = (sc or {}).get("recommended_after", 0)
                items.append({
                    "id": m["id"], "title": m["title"], "titleEs": m["title_es"], "emoji": (sc or {}).get("emoji", cat["emoji"]),
                    "level": (sc or m).get("level", "beginner"), "minutes": (sc or {}).get("minutes", 0),
                    "goal": (sc or {}).get("goal", ""), "setting": (sc or {}).get("setting", ""),
                    "yourRole": (sc or {}).get("your_role", ""), "theirRole": (sc or {}).get("their_role", ""),
                    "skills": (sc or {}).get("skills", []), "available": bool(sc), "status": status,
                    "timesCompleted": r["times_completed"] if r else 0, "mode": r["mode"] if r else "guided",
                    "recommendedAfter": after, "recommended": bool(sc) and status != "completed" and after <= current})
            items.sort(key=lambda x: not x["available"])          # ready ones first, then coming soon
            cats.append({**cat, "scenarios": items, "available": sum(1 for x in items if x["available"])})
        return {"categories": cats,
                "available": sum(c["available"] for c in cats),
                "total": sum(len(c["scenarios"]) for c in cats)}

    def _progress_charts(self, practiced: int, demonstrated: int, concepts_total: int) -> dict:
        """Data for the Progress page charts. Every number comes from the local database."""
        db = self.db
        now = self._now()
        tz = now.tzinfo
        def local(ts):
            return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone(tz)
        # practice per day (minutes, each attempt capped at 5) for the last 14 days
        from .practice_time import minutes_by_day
        per_day = minutes_by_day(db.conn, tz)
        days = [(now - timedelta(days=k)).date() for k in range(13, -1, -1)]
        daily = [{"label": d.strftime("%a")[:2] + " " + str(d.day), "value": round(per_day.get(d, 0), 1),
                  "today": d == now.date()} for d in days]
        streak, d = 0, now.date()
        if per_day.get(d, 0) == 0:
            d = d - timedelta(days=1)          # today not practiced yet doesn't break the streak
        while per_day.get(d, 0) > 0:
            streak += 1; d -= timedelta(days=1)
        # where practice goes, and accuracy, by skill
        mix, acc = [], []
        for key, label, icon, tint in SKILL_META:
            n = db.conn.execute("SELECT COUNT(*) FROM evidence WHERE skill=?", (key,)).fetchone()[0]
            ok = db.conn.execute("SELECT COUNT(*) FROM evidence WHERE skill=? AND outcome='successful'", (key,)).fetchone()[0]
            miss = db.conn.execute("SELECT COUNT(*) FROM evidence WHERE skill=? AND outcome IN ('unsuccessful','partial')", (key,)).fetchone()[0]
            mix.append({"label": label, "value": n, "color": tint})
            acc.append({"label": label, "correct": ok, "missed": miss, "color": tint})
        # course phrases
        phrases = [{"label": "Shown on your own", "value": demonstrated, "color": "#34A875"},
                   {"label": "Practiced with help", "value": max(0, practiced - demonstrated), "color": "#F0A04B"},
                   {"label": "Not yet", "value": max(0, concepts_total - practiced), "color": "#5B6B80"}]
        # pronunciation ratings over time
        speak = []
        for r in db.conn.execute("SELECT started_at, response FROM attempt WHERE response_type='spoken' AND response LIKE '%score%' ORDER BY id"):
            try:
                sc = json.loads(r[1]).get("score")
                if sc:                                  # 0 = Azure didn't hear the phrase: a failed take, not a score
                    speak.append({"label": local(r[0]).strftime("%b %d"), "value": int(sc)})
            except Exception:
                pass
        # reviews coming up (overdue counts as today)
        forecast = []
        due_rows = [local(r[0]).date() for r in db.conn.execute("SELECT due_at FROM review_item")]
        for k in range(7):
            d = (now + timedelta(days=k)).date()
            n = sum(1 for x in due_rows if (x <= d if k == 0 else x == d))
            forecast.append({"label": "Today" if k == 0 else d.strftime("%a"), "value": n})
        basics_done = self._basics.get("completed", 0)
        vr = self._vida_real_library()
        vr_done = sum(1 for c in vr["categories"] for x in c["scenarios"] if x["status"] == "completed")
        return {"daily": daily, "streak": streak, "mix": mix, "accuracy": acc, "phrases": phrases,
                "speaking": speak[-30:], "forecast": forecast,
                "basicsDone": basics_done, "basicsTotal": len(self._basics_units),
                "vrDone": vr_done, "vrTotal": vr["available"]}

    # lesson that trains each skill inside a course day
    SKILL_LESSON = {"listening": 2, "construction": 4, "speaking": 5, "interaction": 6}

    def _recommendations(self) -> list[dict]:
        """What to revisit next, from the learner's own answers. Each item says why,
        with the numbers behind it, and opens the exact lesson or page."""
        db, cur = self.db, self.cur
        current = db.current_session(cur.total_sessions)
        done_days = {r[0] for r in db.conn.execute("SELECT session_no FROM session_progress WHERE status='completed'")}
        out: list[tuple[float, dict]] = []

        def lesson_action(n: int, m: int) -> dict:
            return {"kind": "lesson", "session": n, "module": m}

        def mod_title(n: int, m: int) -> str:
            return next((x["title"] for x in self._session(n).get("modules", []) if x["no"] == m), f"Lesson {m}")

        def phrase(target: str) -> str:
            c = cur.concepts.get(target) or {}
            if not c:
                for sc in self._scen.values():
                    if target in sc.get("concepts", {}):
                        c = sc["concepts"][target]; break
            return c.get("es", "")

        rows = db.conn.execute(
            "SELECT a.session_no s, a.module_no m, a.exercise_id ex, e.learning_target t, e.skill k, e.outcome o "
            "FROM evidence e JOIN attempt a ON a.id=e.attempt_id "
            "WHERE e.outcome IN ('successful','partial','unsuccessful') ORDER BY e.id").fetchall()
        course = [r for r in rows if r["s"] >= 1]

        # 1. lessons with the most misses
        per_lesson: dict = {}
        for r in course:
            key = (r["s"], r["m"])
            ok, miss, ts = per_lesson.get(key, (0, 0, []))
            if r["o"] == "successful":
                ok += 1
            else:
                miss += 1
                if r["t"] not in ts:
                    ts = ts + [r["t"]]
            per_lesson[key] = (ok, miss, ts)
        weak = sorted(((miss / (ok + miss), miss, k, ts) for k, (ok, miss, ts) in per_lesson.items()
                       if miss >= 2 and miss / (ok + miss) >= 0.2 and k[1] != 7), reverse=True)[:2]
        for rate, miss, (n, m), ts in weak:
            ex = [p for p in (phrase(t) for t in ts[:2]) if p]
            out.append((50 + rate * 40, {
                "icon": "refresh-cw", "tint": "#E8746A",
                "title": f"Redo Day {n} · {mod_title(n, m)}",
                "why": f"You missed {miss} of {miss + per_lesson[(n, m)][0]} answers here"
                       + (", including " + " and ".join("“" + e + "”" for e in ex) if ex else "") + ".",
                "button": "Redo this lesson", "action": lesson_action(n, m)}))

        # 2. phrases whose latest answer was missed
        last: dict = {}
        for r in rows:
            last[r["t"]] = r["o"]
        missed = [t for t, o in last.items() if o != "successful"]
        if missed:
            shown = [p for p in (phrase(t) for t in missed) if p][:4]
            out.append((45 + min(len(missed), 10) * 2, {
                "icon": "target", "tint": "#F0A04B",
                "title": f"{len(missed)} phrase{'s' if len(missed) != 1 else ''} you missed last time",
                "why": ("Most recent answer wasn't right for " + ", ".join("“" + p + "”" for p in shown)
                        + (" and more" if len(missed) > len(shown) else "") + ". Review brings them back until they stick."),
                "button": "Review them", "action": {"kind": "section", "section": "revision"}}))

        # 3. weakest skill
        latest_day = max(done_days) if done_days else (current if db.module_status(current) else 0)
        stats = []
        for key, label, icon, tint in SKILL_META:
            ok = sum(1 for r in course if r["k"] == key and r["o"] == "successful")
            n = sum(1 for r in course if r["k"] == key)
            if n >= 6:
                stats.append((ok / n, key, label, ok, n, icon, tint))
        if len(stats) >= 2:
            rate, key, label, ok, n, icon, tint = min(stats)
            if rate < 0.85 and latest_day:
                m = self.SKILL_LESSON[key]
                out.append((40 + (0.85 - rate) * 60, {
                    "icon": icon, "tint": tint,
                    "title": f"Strengthen {label.lower()}",
                    "why": f"Your weakest skill right now: {ok} of {n} answers correct ({round(rate * 100)}%).",
                    "button": f"Day {latest_day} · {mod_title(latest_day, m)}", "action": lesson_action(latest_day, m)}))

        # 4. pronunciation
        takes = []
        for r in db.conn.execute("SELECT exercise_id, session_no, module_no, response FROM attempt "
                                 "WHERE response_type='spoken' AND response LIKE '%score%' ORDER BY id DESC LIMIT 12"):
            try:
                sc = json.loads(r["response"]).get("score")
            except Exception:
                sc = None
            if sc:                                      # 0 = failed take, not a score
                takes.append((int(sc), r["exercise_id"], r["session_no"], r["module_no"]))
        if len(takes) >= 3:
            avg = sum(t[0] for t in takes) / len(takes)
            low = min(takes)
            if avg < 75 or low[0] < 60:
                ex = cur.exercise(low[1]) or {}
                said = ex.get("es", "")
                act = lesson_action(low[2], low[3]) if low[2] >= 1 else {"kind": "section", "section": "revision"}
                out.append((35 + max(0, 75 - avg), {
                    "icon": "mic", "tint": "#E8746A",
                    "title": "Work on pronunciation",
                    "why": f"Your recent ratings average {round(avg)} of 100. Lowest: {low[0]}"
                           + (f" on “{said}”" if said else "") + ". Listen at slow speed, then say it again.",
                    "button": "Practice speaking", "action": act}))

        # 5. end-of-day checks below the pass mark
        for n, (c, t) in sorted(db.exit_scores().items()):
            if t and c / t < EXIT_PASS:
                out.append((70, {
                    "icon": "circle-check", "tint": "#F0A04B",
                    "title": f"Retake Day {n}'s end-of-day check",
                    "why": f"You got {c} of {t} on your own; {round(EXIT_PASS * 100)}% counts as passed.",
                    "button": "Retake the check", "action": lesson_action(n, 7)}))

        # 6. speaking you skipped
        skipped = db.conn.execute("SELECT COUNT(*) FROM skipped_speaking").fetchone()[0] \
            if db.conn.execute("SELECT 1 FROM sqlite_master WHERE name='skipped_speaking'").fetchone() else 0
        if skipped:
            out.append((30, {
                "icon": "mic-off", "tint": "#5B8DEF",
                "title": f"{skipped} speaking exercise{'s' if skipped != 1 else ''} you skipped",
                "why": "They're waiting for when you have a microphone.",
                "button": "Do them now", "action": {"kind": "section", "section": "revision"}}))

        # 7. reviews due
        due = db.review_count_due()
        if due:
            out.append((25 + min(due, 20), {
                "icon": "refresh-cw", "tint": "#2BB3A3",
                "title": f"{due} review{'s' if due != 1 else ''} due",
                "why": "Short spaced reviews are the quickest way to keep what you've learned.",
                "button": "Start reviews", "action": {"kind": "section", "section": "revision"}}))

        # 8. use it for real: a scenario that fits what you've covered
        vr = self._vida_real_library()
        fit = [x for c in vr["categories"] for x in c["scenarios"]
               if x.get("available") and x["status"] != "completed" and x.get("recommendedAfter", 99) <= max(latest_day, 1)]
        if fit:
            x = fit[0]
            out.append((20, {
                "icon": "message-circle", "tint": "#34A875",
                "title": f"Try it for real: {x['titleEs']}",
                "why": f"{x['title']}. It uses language you've already covered.",
                "button": "Open scenario", "action": {"kind": "scenario", "id": x["id"]}}))

        out.sort(key=lambda z: -z[0])
        seen, picked = set(), []
        for _, r in out:                       # one suggestion per destination
            k = json.dumps(r["action"], sort_keys=True)
            if k in seen and r["action"]["kind"] == "lesson":
                continue
            seen.add(k)
            picked.append(r)
        return picked[:5]

    @Slot(int, str, result="QVariantMap")
    def reportCard(self, offset: int, lang: str) -> dict:
        from .report import build
        return build(self, min(0, int(offset)), lang)

    @Slot(str, result=str)
    def localPath(self, url: str) -> str:
        path = QUrl(url).toLocalFile() or url
        if not path.lower().endswith((".jpg", ".jpeg")):
            path += ".jpg"
        return path

    @Slot("QVariantMap")
    def openRecommended(self, action: dict):
        kind = action.get("kind")
        if kind == "lesson":
            n, m = int(action["session"]), int(action["module"])
            if self._day_done(n):
                self.openLesson(n, m, False, "progreso")
            elif n == self.db.current_session(self.cur.total_sessions):
                self.openModule(m)
        elif kind == "section":
            self.goTo(action["section"])
        elif kind == "scenario":
            self.goTo("vidareal")

    def _test_stats(self) -> dict:
        """Day test stats for the Progress page."""
        try:
            rows = {r["session_no"]: r for r in self.db.conn.execute("SELECT * FROM day_test")}
        except Exception:
            rows = {}
        try:
            hist: dict = {}
            for r in self.db.conn.execute("SELECT session_no, score, total, passed FROM day_test_attempt ORDER BY id"):
                hist.setdefault(r["session_no"], []).append(r)
        except Exception:
            hist = {}
        finished = [n for n in range(1, self.cur.total_sessions + 1) if self._day_done(n)]
        days = []
        for n in finished:
            r = rows.get(n)
            h = hist.get(n, [])
            if r is None or not r["attempts"]:
                days.append({"day": n, "taken": False, "passed": False, "pct": 0, "best": 0, "total": 30, "attempts": 0,
                             "firstTry": False, "scores": []})
                continue
            first_try = (bool(h[0]["passed"]) if h else (bool(r["passed_at"]) and r["attempts"] == 1))
            days.append({"day": n, "taken": True, "passed": bool(r["passed_at"]), "best": r["best"], "total": r["total"],
                         "pct": round(r["best"] * 100 / max(1, r["total"])), "attempts": r["attempts"],
                         "firstTry": first_try, "scores": [round(x["score"] * 100 / max(1, x["total"])) for x in h]})
        taken = [d for d in days if d["taken"]]
        all_scores = [s for d in days for s in d["scores"]]
        by_skill = []
        for key, label in (("listening", "Listening"), ("construction", "Sentence building")):
            ok = self.db.conn.execute("SELECT COUNT(*) FROM evidence WHERE context LIKE 'test.%' AND skill=? AND outcome='successful'", (key,)).fetchone()[0]
            n = self.db.conn.execute("SELECT COUNT(*) FROM evidence WHERE context LIKE 'test.%' AND skill=? AND outcome IN ('successful','unsuccessful','partial')", (key,)).fetchone()[0]
            by_skill.append({"label": label, "correct": ok, "missed": n - ok, "pct": round(ok * 100 / n) if n else None})
        return {"days": days, "finished": len(finished), "taken": len(taken),
                "passed": sum(1 for d in days if d["passed"]), "firstTry": sum(1 for d in taken if d["firstTry"]),
                "attempts": sum(d["attempts"] for d in taken),
                "avgBest": round(sum(d["pct"] for d in taken) / len(taken)) if taken else None,
                "avgAll": round(sum(all_scores) / len(all_scores)) if all_scores else None,
                "bySkill": by_skill}

    # ---------- one day per day ----------
    def locked_until(self, n: int):
        """Session n opens the calendar day after the previous one was finished, counting
        from when its test was passed if that came later (passing never skips the wait).
        Returns the local datetime it unlocks, or None if it's open now."""
        if not self._daily_lock or n <= 1 or self.db.session_started(n):
            return None
        done = self.db.session_completed_at(n - 1)
        if done is None:
            return None
        row = self._test_row(n - 1)
        if row and row["passed_at"]:
            try:
                passed = datetime.fromisoformat(str(row["passed_at"]).replace("Z", "+00:00"))
                if passed.tzinfo is None:
                    passed = passed.replace(tzinfo=timezone.utc)
                done = max(done, passed)
            except ValueError:
                pass
        now = self._now()
        local_done = done.astimezone(now.tzinfo)
        if local_done.date() < now.date():
            return None
        nxt = (local_done + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        return nxt

    def _lock_label(self, n: int) -> str:
        until = self.locked_until(n)
        return f"Day {n} opens tomorrow" if until else ""

    # ---------- dashboard ----------
    def rebuild(self):
        db, total = self.db, self.cur.total_sessions
        n = db.current_session(total)
        s = self._session(n)
        completed = db.completed_sessions()
        cp = db.checkpoint()
        mstat = db.module_status(n)
        started = bool(mstat) or (cp is not None and cp["session_no"] == n)
        if cp is not None and cp["session_no"] == n:
            current_mod = cp["module_no"]
        else:
            current_mod = next((m["no"] for m in s["modules"] if mstat.get(m["no"]) not in ("completed", "needs_review")), 1)

        done_set = {r[0] for r in db.conn.execute("SELECT session_no FROM session_progress WHERE status='completed'")}
        window = [k for k in range(max(1, min(n - 2, total - 5)), total + 1)][:5]
        dots = [{"kind": "dot", "n": k, "state": "done" if k in done_set else ("current" if k == n else "todo")} for k in window]
        if window[-1] < total - 1:
            dots.append({"kind": "gap", "n": 0, "state": ""})
        if window[-1] < total:
            dots.append({"kind": "dot", "n": total, "state": "done" if total in done_set else ("current" if total == n else "todo")})

        reviews = []
        for r in db.review_queue(4):
            label, icon, tint = PRACTICE.get(r["practice_type"], (r["practice_type"], "refresh-cw", "#355"))
            due, today = due_label(r["due_at"])
            c = self.cur.concepts.get(r["learning_target"], {})
            reviews.append({"concept": c.get("es", r["learning_target"]), "practice": label, "icon": icon,
                            "tint": tint, "due": due, "dueToday": today})

        summary = db.skill_summary()
        skills = []
        for key, label, icon, tint in SKILL_META:
            info = summary[key]
            skills.append({"key": key, "label": label, "icon": icon, "tint": tint,
                           "stateLabel": SKILL_STATE_LABELS[info["state"]],
                           "assessed": info["state"] not in ("unassessed", "participation_only"),
                           "count": info["evidence"]})
        name = self._name()
        self._dash = {
            "learnerName": name, "initial": (name[:1] or "·").upper(),
            "sessionNo": n, "total": total,
            "sessionTitle": s["title"], "sessionTitleEs": s.get("title_es", ""), "mission": s.get("mission", ""),
            "sessionMinutes": s.get("minutes", 60), "available": s.get("available", False),
            "completed": completed, "allDone": completed >= total,
            "progressPct": round(completed * 100 / total),
            "resumeLabel": "Continue session" if started else "Start session",
            "locked": bool(self.locked_until(n)),
            "lockLabel": self._lock_label(n),
            "testDue": self.test_gate(n),
            "testBest": self._test_best(self.test_gate(n)) if self.test_gate(n) else None,
            # the day you just finished stays open: any of its lessons can be redone
            "doneDay": (dd := (n - 1 if self.locked_until(n) and n > 1 else (n if self._day_done(n) else 0))),
            "doneModules": ([{**{k: m[k] for k in ("no", "title", "desc", "minutes", "icon")},
                              "status": st2, "current": False}
                             for m in self._session(dd)["modules"]
                             for st2 in [db.module_status(dd).get(m["no"], "completed")]] if dd else []),
            "dots": dots,
            "modules": [{**{k: m[k] for k in ("no", "title", "desc", "minutes", "icon")},
                         "status": mstat.get(m["no"], "not_started"), "current": m["no"] == current_mod}
                        for m in s["modules"]],
            "objectives": [{"text": o["text"], "state": (st := db.target_states(o["targets"])),
                            "stateLabel": OBJECTIVE_LABELS[st]} for o in s["objectives"]],
            "phrases": s["phrases"],
            "reviews": reviews, "reviewsDue": db.review_count_due(),
            "skills": skills,
            "partner": s.get("partner", "Ana"),
        }
        self.dashChanged.emit()

    # ---------- workspace ----------
    def _flat(self, s: dict) -> list[tuple[int, int]]:
        return [(m["no"], i) for m in s["modules"] for i in range(len(m["exercises"]))]

    def _mod(self, s: dict, mn: int) -> dict:
        return next(m for m in s["modules"] if m["no"] == mn)

    def _raw(self) -> dict:
        if self._spos is not None:
            sid, st, i = self._spos
            return self._stage(sid, st)["exercises"][i]
        if self._bpos is not None:
            u, i = self._bpos
            return self._basics_units[u]["exercises"][i]
        sn, mn, idx = self._pos
        return self._mod(self._session(sn), mn)["exercises"][idx]

    def _enter(self, session_no: int, module_no: int, idx: int, state: dict | None = None):
        s = self._session(session_no)
        ex = self._mod(s, module_no)["exercises"][idx]
        self._bpos = None
        self._pos = (session_no, module_no, idx)
        self._state = state or {}
        self._hints = 0
        self._started = utcnow()
        self.audio.clearRecording()
        self.audio.stopAll()
        if not self._replay:                               # a redo never moves today's resume point
            self.db.save_step(curriculum_version=self.cur.version, session=s, module_no=module_no,
                              exercise_id=ex["id"], step_state=self._state)
        self._build_ws()

    def _build_ws(self):
        sn, mn, idx = self._pos
        s = self._session(sn)
        mod = self._mod(s, mn)
        flat = self._flat(s)
        overall = flat.index((mn, idx)) + 1
        mstat = self.db.module_status(sn)
        remaining = sum(m["minutes"] for m in s["modules"]
                        if mstat.get(m["no"]) not in ("completed", "needs_review") and m["no"] != mn)
        remaining += round(mod["minutes"] * (1 - idx / len(mod["exercises"])))
        name = self._name()
        self._ws = {
            "sessionNo": sn, "sessionTitle": s["title"], "partner": s.get("partner", "Ana"),
            "moduleNo": mn, "moduleTitle": mod["title"],
            "exerciseIndex": idx + 1, "exerciseCount": len(mod["exercises"]),
            "overallIndex": overall, "overallCount": len(flat),
            "minutesLeft": remaining, "mission": s.get("mission", ""),
            "exercise": present(mod["exercises"][idx], name),
            "exerciseId": mod["exercises"][idx]["id"],
            "state": self._state,
            "learnerName": name or "Sam",
            "single": self._single,
            "replay": bool(self._replay),
            "phrases": s["phrases"],
            "modules": [{"no": m["no"], "title": m["title"], "status": mstat.get(m["no"], "not_started")} for m in s["modules"]],
        }
        self.wsChanged.emit()

    def _resume_point(self, n: int) -> tuple[int, int, dict] | None:
        cp = self.db.checkpoint()
        if cp is not None and cp["session_no"] == n:
            loc = self.cur.locate(cp["exercise_id"])
            if loc:
                return loc[1], loc[2], json.loads(cp["step_state"] or "{}")
        return None

    @Slot()
    def continueSession(self):
        n = self.db.current_session(self.cur.total_sessions)
        gate = self.test_gate(n)
        if gate:                                       # the day before must be passed first
            self.startTest(gate)
            return
        self.openSession(n)

    @Slot(int)
    def openSession(self, n: int):
        current = self.db.current_session(self.cur.total_sessions)
        s = self._session(n)
        if not s["modules"]:
            return
        if self._day_done(n):
            self.openLesson(n, s["modules"][0]["no"], True, "curso")
            return
        if n > current or self.locked_until(n) or self.test_gate(n):
            return
        self._single = False
        rp = self._resume_point(n)
        if rp:
            self._enter(n, rp[0], rp[1], rp[2])
        else:
            mstat = self.db.module_status(n)
            first = next((m["no"] for m in s["modules"] if mstat.get(m["no"]) not in ("completed", "needs_review")), 1)
            self._enter(n, first, 0)
        self._set_screen("workspace")

    # ---------- end-of-day test ----------
    def _test_table(self):
        with self.db.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS day_test (session_no INTEGER PRIMARY KEY, best INTEGER NOT NULL DEFAULT 0, "
                      "total INTEGER NOT NULL DEFAULT 30, attempts INTEGER NOT NULL DEFAULT 0, passed_at TEXT)")
            c.execute("CREATE TABLE IF NOT EXISTS day_test_attempt (id INTEGER PRIMARY KEY AUTOINCREMENT, session_no INTEGER NOT NULL, "
                      "score INTEGER NOT NULL, total INTEGER NOT NULL, passed INTEGER NOT NULL, at TEXT NOT NULL)")

    def _test_row(self, n: int):
        try:
            return self.db.conn.execute("SELECT * FROM day_test WHERE session_no=?", (n,)).fetchone()
        except Exception:
            return None

    def test_passed(self, n: int) -> bool:
        r = self._test_row(n)
        return bool(r and r["passed_at"])

    def _test_best(self, n: int):
        r = self._test_row(n)
        return {"best": r["best"], "total": r["total"], "attempts": r["attempts"]} if r else None

    def test_gate(self, n: int) -> int:
        """The day whose test must be passed before day n can start (0 = none)."""
        k = n - 1
        if k >= 1 and self._day_done(k) and not self.test_passed(k) and not self.db.session_started(n):
            return k
        return 0

    @Slot(int)
    def startTest(self, n: int):
        from . import daytest
        import random
        if not self._day_done(n):
            return
        self._test_table()
        row = self._test_row(n)
        seed = (int(time.time() * 1000) ^ (n << 8) ^ ((row["attempts"] if row else 0) << 20))
        qs = daytest.build(self.cur, n, self._name(), random.Random(seed))   # new questions, order and choices each time
        self._test = {"n": n, "qs": qs, "i": 0, "answers": [None] * len(qs), "results": [None] * len(qs),
                      "times": [None] * len(qs), "review": None, "done": False}
        self._test_started = utcnow()
        self._build_test_view()
        self._set_screen("test")

    def _build_test_view(self):
        from . import daytest
        t = getattr(self, "_test", None)
        if not t:
            self._test_view = {}
            self.testChanged.emit()
            return
        s = self._session(t["n"])
        v = {"day": t["n"], "title": s["title"], "titleEs": s.get("title_es", ""), "count": len(t["qs"]),
             "index": t["i"], "answered": sum(1 for a in t["answers"] if a is not None), "done": t["done"],
             "need": int(round(daytest.PASS * len(t["qs"]))), "review": t["review"]}
        if not t["done"]:
            v["q"] = daytest.public(t["qs"][t["i"]])
            v["answer"] = t["answers"][t["i"]]
        else:
            ok = sum(1 for r in t["results"] if r)
            v.update({"correct": ok, "pct": round(ok * 100 / max(1, len(t["qs"]))), "passed": ok / max(1, len(t["qs"])) >= daytest.PASS,
                      "best": self._test_best(t["n"]),
                      "nextOpen": t["n"] < self.cur.total_sessions and not self.locked_until(t["n"] + 1),
                      "nextLock": self._lock_label(t["n"] + 1) if t["n"] < self.cur.total_sessions else "",
                      "misses": [self._test_miss(q, t["answers"][k]) for k, q in enumerate(t["qs"]) if not t["results"][k]]})
        self._test_view = v
        self.testChanged.emit()

    def _test_miss(self, q: dict, given) -> dict:
        if q["kind"] == "choice":
            yours = q["options"][given] if isinstance(given, int) and 0 <= given < len(q["options"]) else "—"
            return {"prompt": q["prompt"], "extra": q.get("extra") or (q.get("audio") if not q.get("show_text") else ""),
                    "yours": yours, "right": q["options"][q["answer"]]}
        if q["kind"] == "build":
            return {"prompt": q["prompt"], "extra": "", "yours": " ".join(given or []) or "—",
                    "right": " ".join(personalize(q["answer_tiles"], self._name() or "Sam"))}
        return {"prompt": q["prompt"], "extra": "", "yours": given or "—", "right": personalize(q.get("model", ""), self._name() or "Sam")}

    test = Property("QVariantMap", lambda self: getattr(self, "_test_view", {}), notify=testChanged)

    @Slot("QVariant")
    def testAnswer(self, value):
        """Save the answer to the current question (no right/wrong shown until the end)."""
        from . import daytest
        t = getattr(self, "_test", None)
        if not t or t["done"]:
            return
        q = t["qs"][t["i"]]
        if q["kind"] == "build":
            value = [str(x) for x in (value or [])]
        elif q["kind"] == "choice":
            value = int(value)
        else:
            value = str(value)
        g = daytest.grade(q, value, self._name())
        t["answers"][t["i"]] = value
        t["results"][t["i"]] = g["correct"]
        t["times"][t["i"]] = utcnow()                  # so practice time counts each answer once
        # a typed answer that isn't in the list: the learner compares it with the model answer
        t["review"] = {"yours": value, "model": personalize(q.get("model", ""), self._name() or "Sam")} if g["review"] else None
        self._build_test_view()

    @Slot(bool)
    def testSelfReview(self, same_meaning: bool):
        t = getattr(self, "_test", None)
        if not t or not t["review"]:
            return
        t["results"][t["i"]] = bool(same_meaning)
        t["review"] = None
        self._build_test_view()

    @Slot()
    def testNext(self):
        t = getattr(self, "_test", None)
        if not t or t["done"] or t["answers"][t["i"]] is None or t["review"]:
            return
        if t["i"] + 1 < len(t["qs"]):
            t["i"] += 1
            self._build_test_view()
            return
        self._finish_test()

    @Slot()
    def testBack(self):
        t = getattr(self, "_test", None)
        if t and not t["done"] and t["i"] > 0:
            t["i"] -= 1
            t["review"] = None
            self._build_test_view()

    def _finish_test(self):
        from . import daytest
        t = self._test
        t["done"] = True
        n = t["n"]
        ok = sum(1 for r in t["results"] if r)
        total = len(t["qs"])
        passed = ok / max(1, total) >= daytest.PASS
        self._test_table()
        with self.db.tx() as c:
            c.execute("INSERT INTO day_test(session_no, best, total, attempts, passed_at) VALUES(?,?,?,1,?) "
                      "ON CONFLICT(session_no) DO UPDATE SET best=MAX(best, excluded.best), total=excluded.total, "
                      "attempts=attempts+1, passed_at=COALESCE(passed_at, excluded.passed_at)",
                      (n, ok, total, iso(utcnow()) if passed else None))
            c.execute("INSERT INTO day_test_attempt(session_no, score, total, passed, at) VALUES(?,?,?,?,?)",
                      (n, ok, total, 1 if passed else 0, iso(utcnow())))
        # every answer counts as evidence: answered on its own, without hints
        times = sorted(x for x in t.get("times", []) if x)
        prev_of = {}
        last = self._test_started
        for x in times:
            prev_of[x] = last
            last = x
        for k, q in enumerate(t["qs"]):
            targets = [x for x in q.get("targets", []) if x]
            if not targets:
                continue
            done_at = t.get("times", [None] * len(t["qs"]))[k]
            outcome = "successful" if t["results"][k] else "unsuccessful"
            self.db.record_attempt(
                curriculum_version=self.cur.version, exercise_id=f"test.s{n:02d}.q{k + 1}", session_no=n, module_no=8,
                input_type="audio_only" if q.get("skill") == "listening" else "text",
                response_type={"choice": "select", "build": "construct"}.get(q["kind"], "typed"),
                response=t["answers"][k], started_at=prev_of.get(done_at, self._test_started) if done_at else self._test_started,
                finished_at=done_at,
                evidence=[{"learning_target": tg, "skill": q.get("skill", "listening"), "independence": "independent",
                           "transfer": "practiced", "retention": "immediate", "delay_seconds": None,
                           "context": f"test.s{n:02d}", "outcome": outcome, "assessment_source": "deterministic",
                           "practice_type": PRACTICE_OF.get(q.get("skill", "listening"), "listen_respond")} for tg in targets])
        self.rebuild()
        self.refreshLibrary()
        self._build_test_view()

    @Slot()
    def testQuit(self):
        self._test = None
        self._build_test_view()
        self.backToDashboard()

    def _day_done(self, n: int) -> bool:
        return self.db.conn.execute("SELECT 1 FROM session_progress WHERE session_no=? AND status='completed'",
                                    (n,)).fetchone() is not None

    @Slot(int, int, str)
    def redoLesson(self, n: int, module_no: int, back: str = ""):
        self.openLesson(n, module_no, False, back)

    @Slot(int, str)
    def redoDay(self, n: int, back: str = ""):
        s = self._session(n)
        if s["modules"]:
            self.openLesson(n, s["modules"][0]["no"], True, back)

    def openLesson(self, n: int, module_no: int, whole_day: bool = False, back: str = ""):
        """Redo any lesson of a finished day straight away, without the ones before it.
        Answers still count as practice; the day's completion and today's place are untouched."""
        s = self._session(n)
        if not self._day_done(n) or not any(m["no"] == module_no for m in s["modules"]):
            return
        self._single = False
        self._replay = "all" if whole_day else "one"
        self._replay_from = back
        self._enter(n, module_no, 0)
        self._set_screen("workspace")

    @Slot(int)
    def jumpToLesson(self, module_no: int):
        """While redoing a finished day, hop to another of its lessons."""
        if self._replay and self._pos:
            self._enter(self._pos[0], module_no, 0)

    def _end_replay(self):
        back = self._replay_from
        self._replay = ""
        self._replay_from = ""
        self.backToDashboard()
        if back:
            self.sectionRequested.emit(back)

    @Slot(int)
    def openModule(self, module_no: int):
        n = self.db.current_session(self.cur.total_sessions)
        if self._day_done(n):
            self.openLesson(n, module_no, False, "")
            return
        if self.locked_until(n) or self.test_gate(n):
            return
        rp = self._resume_point(n)
        self._single = False
        if rp and rp[0] == module_no:
            self._enter(n, rp[0], rp[1], rp[2])
        else:
            self._enter(n, module_no, 0)
        self._set_screen("workspace")

    @Slot(str)
    def practiceExercise(self, exercise_id: str):
        """Open one exercise (e.g. a conversation) on its own; returns to the list after."""
        loc = self.cur.locate(exercise_id)
        cur_n = self.db.current_session(self.cur.total_sessions)
        if not loc or loc[0] > cur_n or (loc[0] == cur_n and self.locked_until(cur_n)):
            return
        self._single = True
        self._enter(*loc)
        self._set_screen("workspace")

    @Slot()
    def advance(self):
        if self._spos is not None:
            self._scen_advance()
            return
        if self._bpos is not None:
            self._basics_advance()
            return
        if not self._pos:
            return
        sn, mn, idx = self._pos
        s = self._session(sn)
        mod = self._mod(s, mn)
        if self._single:
            self._single = False
            back = getattr(self, "_return_to", "")
            self._return_to = ""
            self.backToDashboard()
            if back:
                self.sectionRequested.emit(back)
            return
        if idx + 1 < len(mod["exercises"]):
            self._enter(sn, mn, idx + 1)
            return
        if self._replay:
            later = [m["no"] for m in s["modules"] if m["no"] > mn]
            if self._replay == "all" and later:
                self._enter(sn, later[0], 0)
            else:
                self._end_replay()
            return
        needs_review = mn == 7 and self._state.get("exitScore", 1.0) < EXIT_PASS
        session_done = self.db.complete_module(s, mn, needs_review=needs_review)
        if session_done:
            self._show_summary(sn)
            return
        mstat = self.db.module_status(sn)
        nxt = next((m["no"] for m in s["modules"] if m["no"] > mn and mstat.get(m["no"]) not in ("completed", "needs_review")), None)
        if nxt is None:
            nxt = next((m["no"] for m in s["modules"] if mstat.get(m["no"]) not in ("completed", "needs_review")), None)
        if nxt is None:
            self._show_summary(sn)
        else:
            self._enter(sn, nxt, 0)

    @Slot()
    def previous(self):
        if self._spos is not None:
            sid, st, i = self._spos
            flat = self._scen_flat(sid)
            k = flat.index((st, i))
            if k > 0 and not self._single:
                self._scen_enter(sid, *flat[k - 1])
            return
        if self._bpos is not None:
            u, i = self._bpos
            if i > 0:
                self._basics_enter(u, i - 1)
            return
        if not self._pos:
            return
        sn, mn, idx = self._pos
        s = self._session(sn)
        flat = self._flat(s)
        i = flat.index((mn, idx))
        if i > 0 and not (self._replay == "one" and idx == 0):
            pm, pi = flat[i - 1]
            self._enter(sn, pm, pi)

    @Slot("QVariantMap")
    def saveState(self, state: dict):
        """UI progress inside an exercise (typed draft, dialogue step, conversation path)."""
        if self._spos is not None:
            self._state = dict(state)
            self._scen_save()
            return
        if not self._pos:
            return
        self._state = dict(state)
        if self._replay:
            return
        sn, mn, idx = self._pos
        self.db.save_step(curriculum_version=self.cur.version, session=self._session(sn), module_no=mn,
                          exercise_id=self._raw()["id"], step_state=self._state)

    @Slot(str)
    def saveDraft(self, text: str):
        self.saveState({**self._state, "draft": text})

    @Slot()
    def backToDashboard(self):
        self.audio.stopAll()
        self._replay = ""
        was_basics = self._bpos is not None
        self._bpos = None
        if self._spos is not None:
            was_single = self._single
            self._spos = None
            self._single = False
            self.refreshLibrary()
            self.rebuild()
            self._set_screen("dashboard")
            self.sectionRequested.emit("revision" if was_single else "vidareal")
            return
        if was_basics:
            self._refresh_basics()
            self.sectionRequested.emit("basicos")
        self.rebuild()
        self.refreshLibrary()
        self._set_screen("dashboard")

    def _show_summary(self, sn: int):
        s = self._session(sn)
        scores = self.db.exit_scores()
        c, t = scores.get(sn, (0, 0))
        nxt = self._session(sn + 1) if sn < self.cur.total_sessions else None
        self._summary = {
            "sessionNo": sn, "title": s["title"], "titleEs": s.get("title_es", ""),
            "exitCorrect": c, "exitTotal": t,
            "objectives": [{"text": o["text"], "state": (st := self.db.target_states(o["targets"])),
                            "stateLabel": OBJECTIVE_LABELS[st]} for o in s["objectives"]],
            "reviewsScheduled": self.db.conn.execute("SELECT COUNT(*) FROM review_item").fetchone()[0],
            "nextTitle": nxt["title"] if nxt else "",
            "nextAvailable": bool(nxt and nxt.get("modules")) and not self.locked_until(sn + 1) and self.test_passed(sn),
            "nextLocked": bool(nxt and nxt.get("modules")) and bool(self.locked_until(sn + 1)),
            "testDay": sn, "testPassed": self.test_passed(sn), "testBest": self._test_best(sn),
            "nextNo": sn + 1,
            "courseDone": self.db.completed_sessions() >= self.cur.total_sessions,
        }
        self._pos = None
        self.rebuild()
        self.refreshLibrary()
        self._set_screen("summary")

    # ---------- answering ----------
    def _part(self, part: str) -> dict:
        ex = self._raw()
        if part.startswith("q"):
            return ex["questions"][int(part[1:])]
        if part.startswith("i"):
            return ex["items"][int(part[1:])]
        return ex

    def _evidence(self, targets: list[str], skill: str, outcome: str, retry: int,
                  translation_shown: bool = False) -> list[dict]:
        sn, mn, _ = self._pos
        session_concepts = set(self._session(sn).get("concepts", {}))
        out = []
        for t in targets:
            if mn == 7:
                independence = "guided" if (self._hints or retry) else "independent"
            elif mn == 6:
                independence = "guided" if (self._hints or translation_shown) else "independent"
            else:
                independence = "guided" if (self._hints or retry or mn <= 3) else "independent"
            transfer = "novel" if mn == 7 else "practiced"
            delayed = t not in session_concepts
            last = self.db.last_evidence_at(t) if delayed else None
            out.append({
                "learning_target": t, "skill": skill, "independence": independence, "transfer": transfer,
                "retention": "delayed" if delayed else "immediate",
                "delay_seconds": int((utcnow() - last).total_seconds()) if last else None,
                "context": f"s{sn:02d}.m{mn}", "outcome": outcome, "assessment_source": "deterministic",
                "practice_type": PRACTICE_OF.get(skill, "listen_respond"),
            })
        return out

    def _record(self, part: str, item: dict, skill: str, response, correct: bool, retry: int,
                response_type: str, partial: bool = False, translation_shown: bool = False,
                outcome: str | None = None, source: str = "deterministic"):
        if self._bpos is not None:          # Basics is practice: no evidence, no review scheduling
            return
        if self._spos is not None:
            self._scen_record(part, item, skill, response, correct, retry, response_type, partial,
                              translation_shown, outcome, source)
            return
        sn, mn, _ = self._pos
        ex = self._raw()
        targets = item.get("targets") or ex.get("targets", [])
        outcome = outcome or ("successful" if correct else ("partial" if partial else "unsuccessful"))
        self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=f"{ex['id']}#{part}" if part else ex["id"],
            session_no=sn, module_no=mn, input_type="audio_only" if skill == "listening" else "text",
            response_type=response_type, response=response, hints_used=self._hints, retry_no=retry,
            started_at=self._started,
            evidence=[{**e, "assessment_source": source} for e in self._evidence(targets, skill, outcome, retry, translation_shown)])
        self._started = utcnow()

    @Slot()
    def useHint(self):
        self._hints += 1
        if self._spos is not None:
            self._run["hints"] = self._run.get("hints", 0) + 1

    @Slot(str, int, int, result="QVariantMap")
    def answerChoice(self, part: str, index: int, retry: int) -> dict:
        item = self._part(part)
        ok = index == item["answer"]
        kind = item.get("type", self._raw()["type"])
        skill = "listening" if kind in ("listen_choose", "dialogue") or part.startswith("q") else SKILL_OF.get(kind, "listening")
        self._record(part, item, skill, index, ok, retry, "select")
        return {"correct": ok, "answer": item["answer"], "explain": item.get("explain", "")}

    @Slot(str, "QStringList", int, result="QVariantMap")
    def answerBuild(self, part: str, tiles: list, retry: int) -> dict:
        from .content import personalize
        item = self._part(part)
        name = self._name()
        # The tiles on screen carry the learner's own name (Sam -> the learner's name), so check
        # against the personalized answer too, not only the sample one.
        answer = personalize(item["answer"], name)
        alts = personalize(item.get("alt_answers") or [], name)
        ok = (check_build(list(tiles), answer, alts)
              or check_build(list(tiles), item["answer"], item.get("alt_answers")))
        self._record(part, item, "construction", list(tiles), ok, retry, "construct")
        return {"correct": ok, "answer": answer, "sentence": " ".join(answer),
                "gloss": personalize(item.get("gloss", []), name)}

    @Slot(str, str, int, result="QVariantMap")
    def answerTyped(self, part: str, text: str, retry: int) -> dict:
        item = self._part(part)
        accept = list(item["accept"])
        res = check_typed(text, accept)
        # Typed answers outside the reviewed accepted set are NOT EVALUATED, not wrong.
        self._record(part, item, "construction", text, res["correct"], retry, "typed",
                     outcome=None if res["correct"] else "unassessed")
        from .content import personalize
        return {"correct": res["correct"], "accentNote": res["accent_note"], "meaningNote": res.get("meaning_note", ""),
                "model": personalize(item.get("model", accept[0]), self._name() or "Sam")}

    @Slot(str, bool)
    def selfReviewTyped(self, part: str, same: bool):
        """Learner compares their own unmatched answer with the model."""
        item = self._part(part)
        self._record(part, item, "construction", "same" if same else "different", same, 1, "self_confirm",
                     source="self_review")

    @Slot(str, int, bool, result="QVariantMap")
    def conversationPick(self, node: str, option: int, translation_shown: bool) -> dict:
        ex = self._raw()
        opt = ex["nodes"][node]["options"][option]
        q = opt.get("quality", "good")
        # Repair is a successful interaction move; off-track is unsuccessful.
        self._record(f"n:{node}", ex, "interaction", opt["es"], q in ("good", "repair"), 0, "select",
                     translation_shown=translation_shown)
        if self._spos is not None:
            conv = self._run.setdefault("conv", {"good": 0, "repair": 0, "off": 0})
            conv[q] = conv.get(q, 0) + 1
            if translation_shown:
                self._run["english"] = True
        with self.db.tx() as c:
            c.execute("INSERT INTO conversation_turn(scenario_id,mode,turn_no,speaker,text,branch_id) VALUES(?,?,?,?,?,?)",
                      (ex["id"], "offline_structured", len(self._state.get("path", [])), "learner", opt["es"], opt["next"]))
        return {"next": opt["next"], "quality": q, "feedback": opt.get("feedback", "")}

    @Slot(int)
    def selfReview(self, rating: int):
        """Learner's own judgement after comparing with the reference. Recorded as
        self-review; never presented as a pronunciation score."""
        ex = self._raw()
        sn, mn, _ = self._pos
        self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=f"{ex['id']}#self", session_no=sn, module_no=mn,
            input_type="audio_text", response_type="self_confirm", response=rating, started_at=self._started,
            evidence=[{**e, "outcome": "unassessed", "assessment_source": "self_review"}
                      for e in self._evidence(ex.get("targets", []), "speaking", "unassessed", 0)])

    @Slot(int)
    def reflectPick(self, index: int):
        ex = self._raw()
        sn, _, _ = self._pos
        with self.db.tx() as c:
            c.execute("INSERT INTO calibration_observation(stage,key,value) VALUES(?,?,?)",
                      ("reflection", ex["id"], str(index)))

    @Slot(float)
    def setExitScore(self, score: float):
        self.saveState({**self._state, "exitScore": score})

    def _on_recording(self, file_name: str, duration_ms: int, rate: int, tech: str):
        if not self._pos:
            return
        ex = self._raw()
        sn, mn, _ = self._pos
        attempt = self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=ex["id"], session_no=sn, module_no=mn,
            input_type="audio_text", response_type="spoken", technical_status=tech, started_at=self._started,
            evidence=[{**e, "outcome": "unassessed", "assessment_source": "self_review"}
                      for e in self._evidence(ex.get("targets", []), "speaking", "unassessed", 0)])
        # The take itself isn't kept: it is transcribed and rated (see pronunciation.py), then deleted.

    def attach_speech(self, speech):
        speech.rated.connect(self._on_rated)

    def _on_rated(self, res: dict):
        """Azure's pronunciation rating for the current speaking exercise."""
        eid = self._current_exercise_id()
        if eid:
            self._clear_skip(eid)
        if self._spos is not None:
            ex = self._raw()
            if ex.get("type") == "speak":
                sp = self._run.setdefault("speak", {"rated": 0, "best": 0})
                sp["rated"] += 1
                sp["best"] = max(sp["best"], int(res.get("score") or 0))
                self._record("", ex, "speaking", {k: res.get(k) for k in ("heard", "score")}, True, 0, "spoken",
                             outcome=res.get("outcome", "unassessed"), source="validated_automated")
            return
        if not self._pos:
            return
        ex = self._raw()
        if ex.get("type") != "speak":
            return
        sn, mn, _ = self._pos
        outcome = res.get("outcome", "unassessed")
        self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=f"{ex['id']}#rated", session_no=sn, module_no=mn,
            input_type="audio_text", response_type="spoken",
            response={k: res.get(k) for k in ("heard", "score", "accuracy", "fluency", "completeness")},
            started_at=self._started,
            evidence=[{**e, "outcome": outcome, "assessment_source": "validated_automated"}
                      for e in self._evidence(ex.get("targets", []), "speaking", outcome, 0)])

    # ---------- audio helpers ----------
    @Slot(str, bool)
    def say(self, text: str, slow: bool):
        self.audio.say(text, slow)

    @Slot(str, bool)
    def playReference(self, text: str, slow: bool):
        self.audio.say(text, slow)

    # ---------- library screens ----------
    @Slot()
    def refreshLibrary(self):
        db, total = self.db, self.cur.total_sessions
        current = db.current_session(total)
        done = {r[0] for r in db.conn.execute("SELECT session_no FROM session_progress WHERE status='completed'")}
        course = []
        for n in range(1, total + 1):
            s = self._session(n)
            mstat = db.module_status(n)
            mdone = sum(1 for v in mstat.values() if v in ("completed", "needs_review"))
            status = "completed" if n in done else ("current" if n == current else "locked")
            if status == "current" and self.locked_until(n):
                status = "tomorrow"
            course.append({"no": n, "title": s["title"], "titleEs": s.get("title_es", ""), "mission": s.get("mission", ""),
                           "status": status, "modulesDone": mdone, "available": bool(s.get("modules")),
                           "testPassed": self.test_passed(n) if status == "completed" else False,
                           "testBest": self._test_best(n) if status == "completed" else None,
                           "testGate": self.test_gate(n) if status in ("current", "tomorrow") else 0,
                           "lessons": [{k: m[k] for k in ("no", "title", "desc", "minutes", "icon")} | {"status": mstat.get(m["no"], "completed")}
                                       for m in s.get("modules", [])] if status == "completed" else [],
                           "needsReview": any(v == "needs_review" for v in mstat.values())})
        vocab = []
        for n in range(1, total + 1):
            s = self._session(n)
            items = []
            for cid, c in s.get("concepts", {}).items():
                st = db.target_states([cid]) if n <= current else "locked"
                items.append({"id": cid, "es": c["es"], "en": c["en"], "state": st})
            vocab.append({"no": n, "title": s["title"], "unlocked": n <= current, "items": items})
        convos = []
        for n in range(1, current + 1):
            s = self._session(n)
            for m in s.get("modules", []):
                for ex in m["exercises"]:
                    if ex["type"] == "conversation":
                        tries = db.conn.execute("SELECT COUNT(DISTINCT substr(started_at,1,16)) FROM attempt WHERE exercise_id LIKE ?",
                                                (ex["id"] + "#n:%",)).fetchone()[0]
                        convos.append({"id": ex["id"], "session": n, "title": s["title"], "partner": s.get("partner", ""),
                                       "setting": ex.get("setting", ""), "goal": ex.get("goal", ""), "practiced": tries > 0})
        summary = db.skill_summary()
        skills = []
        for key, label, icon, tint in SKILL_META:
            info = summary[key]
            skills.append({"key": key, "label": label, "icon": icon, "tint": tint,
                           "stateLabel": SKILL_STATE_LABELS[info["state"]], "evidence": info["evidence"],
                           "assessed": info["assessed"], "successful": info["successful"]})
        scores = db.exit_scores()
        counts = db.evidence_counts()
        concepts_total = sum(len(self._session(n).get("concepts", {})) for n in range(1, total + 1))
        demonstrated = sum(1 for g in vocab for it in g["items"] if it["state"] == "demonstrated")
        practiced = sum(1 for g in vocab for it in g["items"] if it["state"] in ("practiced", "demonstrated"))
        name = self._name()
        self._lib = {
            "course": course, "vocab": vocab, "conversations": convos,
            "progress": {
                "completed": len(done), "total": total, "current": current,
                "minutes": db.active_minutes(), "skills": skills,
                "exitScores": [{"session": k, "correct": v[0], "total": v[1]} for k, v in sorted(scores.items())],
                "tests": self._test_stats(),
                "retained": counts["retained"], "independent": counts["independent"], "novel": counts["novel"],
                "conceptsTotal": concepts_total, "demonstrated": demonstrated, "practiced": practiced,
                "recordings": len(db.recordings()),
                "charts": self._progress_charts(practiced, demonstrated, concepts_total),
                "recommend": self._recommendations(),
            },
            "reviewsDue": db.review_count_due(),
            "reviewsScheduled": db.conn.execute("SELECT COUNT(*) FROM review_item").fetchone()[0],
            "nextReview": (due_label(r[0])[0] if (r := db.conn.execute("SELECT MIN(due_at) FROM review_item").fetchone()) and r[0] else ""),
            "settings": {"name": name, "recordings": len(db.recordings())},
            "skippedSpeaking": self._skipped_list(),
            "vidaReal": self._vida_real_library(),
        }
        self.libraryChanged.emit()

    # ---------- spaced review ----------
    @Slot()
    def startReview(self):
        due = self.db.due_reviews(10)
        current = self.db.current_session(self.cur.total_sessions)
        pool = [c for c in self.cur.concepts.values() if c["session"] <= current]
        items = []
        rnd = random.Random()
        for k, r in enumerate(due):
            c = self.cur.concepts.get(r["learning_target"])
            if not c:
                continue
            from .distractors import pick, simplify
            one = simplify(c, rnd)                     # "A / B" phrases: ask one half
            same = (lambda x, sn=c.get("session"): x.get("session") == sn)
            if k % 2 == 0:
                shown, wrong = pick(one, pool, "en", rnd, same_group=same, original=c)
                opts = [shown] + wrong
                kind, prompt = "listen", "What does this mean?"
            else:
                shown, wrong = pick(one, pool, "es", rnd, same_group=same, original=c)
                opts = [shown] + wrong
                kind, prompt = "recall", f"How do you say \"{one['en']}\"?"
            c = dict(c, es=one["es"], en=one["en"]) if one is not c else c
            order = list(range(len(opts)))
            rnd.shuffle(order)
            items.append({"target": r["learning_target"], "kind": kind, "prompt": prompt, "audio": c["es"],
                          "options": [opts[i] for i in order], "answer": order.index(0),
                          "en": c["en"], "es": c["es"]})
        self._review = {"items": items, "index": 0, "correct": 0}
        self.reviewChanged.emit()
        self._started = utcnow()
        if items:
            self._set_screen("review")

    @Slot(int, int, result="QVariantMap")
    def answerReview(self, item_index: int, choice: int) -> dict:
        it = self._review["items"][item_index]
        ok = choice == it["answer"]
        target = it["target"]
        last = self.db.last_evidence_at(target)
        sess = self.cur.concepts.get(target, {}).get("session", 0)
        self.db.record_attempt(
            curriculum_version=self.cur.version, exercise_id=f"review#{target}", session_no=sess or 1, module_no=1,
            input_type="audio_only" if it["kind"] == "listen" else "text", response_type="select", response=choice,
            started_at=self._started,
            evidence=[{"learning_target": target, "skill": "listening" if it["kind"] == "listen" else "construction",
                       "independence": "independent", "transfer": "practiced", "retention": "delayed",
                       "delay_seconds": int((utcnow() - last).total_seconds()) if last else None,
                       "context": "spaced_review", "outcome": "successful" if ok else "unsuccessful",
                       "assessment_source": "deterministic",
                       "practice_type": "listen_respond" if it["kind"] == "listen" else "production"}])
        self._started = utcnow()
        return {"correct": ok, "answer": it["answer"]}

    @Slot()
    def finishReview(self):
        self._review = {}
        self.reviewChanged.emit()
        self.backToDashboard()

    # ---------- settings ----------
    @Slot(str)
    def setName(self, name: str):
        self.db.set_display_name(name[:40])
        self.rebuild()
        self.refreshLibrary()

    @Slot(str)
    def setVoice(self, label: str):
        if self.voice:
            self.voice.select(label)
        if self._settings:
            self._settings.setValue("voice", label)

    @Slot(float)
    def setRate(self, r: float):
        if self.voice:
            self.voice.setRate(r)
        if self._settings:
            self._settings.setValue("rate", r)

    @Slot()
    def deleteRecordings(self):
        rec_dir = self.audio._rec_dir
        for r in self.db.recordings():
            p = Path(rec_dir) / r["file_name"]
            if p.exists():
                p.unlink()
        for p in Path(rec_dir).glob("rec-*.wav"):
            p.unlink()
        self.db.delete_recordings()
        self.audio.clearRecording()
        self.refreshLibrary()

    @Slot(str, result=str)
    def exportProgress(self, url: str) -> str:
        path = QUrl(url).toLocalFile() or url
        if not path.endswith(".habla"):
            path += ".habla"
        self.db.export(path)
        return path

    @Slot()
    def resetProgress(self):
        self.db.reset_progress()
        self._pos = None
        self.backToDashboard()


def seed_demo(db: Database, cur: Curriculum) -> None:
    """Populate a SEPARATE demo database so the populated layout can be checked.
    Never used on the learner's real data."""
    s = cur.session(1)
    db.set_display_name("Alex")
    db.complete_module(s, 1)
    db.save_step(curriculum_version=cur.version, session=s, module_no=2, exercise_id=s["modules"][1]["exercises"][1]["id"])

    def ev(target, skill, **kw):
        d = dict(learning_target=target, skill=skill, independence="guided", transfer="practiced",
                 retention="immediate", outcome="successful", assessment_source="deterministic")
        d.update(kw)
        return d

    def att(evs, rt="select"):
        db.record_attempt(curriculum_version=cur.version, exercise_id="s01.m1.e1", session_no=1, module_no=1,
                          input_type="audio_only", response_type=rt, evidence=evs)

    att([ev("c.hola", "listening", practice_type="comprehension", outcome="unsuccessful")])
    att([ev("c.me_llamo", "construction", practice_type="production", outcome="partial")], "construct")
    att([ev("c.como_te_llamas", "listening", practice_type="listen_respond")])
    att([ev("c.mucho_gusto", "interaction", practice_type="conversation")])
    att([ev("c.hola", "speaking", outcome="unassessed", assessment_source="self_review")], "spoken")
