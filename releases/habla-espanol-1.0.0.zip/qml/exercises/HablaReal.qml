import QtQuick
import QtQuick.Layouts
import "../components"

// "Habla Real": what was said, what it means, what was meant, how to reply,
// Mexican usage, your turn. Translation is marked as verified meaning;
// the speaker's intent is marked as a contextual interpretation.
Card {
    id: hr
    property var info: ({})
    elevated: true
    implicitHeight: col.implicitHeight + 40
    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
        spacing: 14
        RowLayout {
            spacing: 10
            Icon { name: "sparkles"; color: Theme.amber; size: 20 }
            Text { text: "Habla Real"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 22 }
            Text { text: "how this line really works"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; Layout.leftMargin: 4 }
        }
        GridLayout {
            Layout.fillWidth: true
            columns: 2; columnSpacing: 14; rowSpacing: 12
            // Lo que dijo
            Section { title: "Lo que dijo"; sub: "What was said"
                RowLayout { spacing: 10; Layout.fillWidth: true
                    SayButton { phrase: hr.info.lo_que_dijo || ""; size: 30 }
                    Text { text: hr.info.lo_que_dijo || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true } } }
            // Lo que significa
            Section { title: "Lo que significa"; sub: "What it means"; tag: "Translation"; tagColor: Theme.green
                Text { text: hr.info.lo_que_significa || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            // Lo que quiso decir
            Section { title: "Lo que quiso decir"; sub: "What they meant"; tag: "Interpretation"; tagColor: Theme.amber
                Text { text: hr.info.lo_que_quiso_decir || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Text { text: "A reading of the speaker's intent in this situation — not a fixed meaning."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            // Cómo responder
            Section { title: "Cómo responder"; sub: "How to reply"
                Repeater {
                    model: hr.info.como_responder || []
                    delegate: RowLayout { required property var modelData; spacing: 10; Layout.fillWidth: true
                        SayButton { phrase: modelData; size: 28; tint: Theme.cardElevated }
                        Text { text: modelData; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                } }
            // Así se habla en México
            Section { title: "Así se habla en México"; sub: "Mexican usage"; Layout.columnSpan: 2
                Text { text: hr.info.asi_se_habla || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            // Tu turno
            Section { title: "Tu turno"; sub: "Your turn"; Layout.columnSpan: 2; accent: true
                Text { text: (hr.info.tu_turno || "") + "  Say it out loud — the next exercises will ask for it."; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
        }
    }

    component Section: Rectangle {
        id: sec
        property string title
        property string sub
        property string tag: ""
        property color tagColor: Theme.green
        property bool accent: false
        default property alias inner: body.data
        Layout.fillWidth: true
        Layout.preferredWidth: 1
        implicitHeight: body.implicitHeight + head.implicitHeight + 30
        radius: 12
        color: accent ? Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.12) : Qt.rgba(1, 1, 1, 0.035)
        border.color: accent ? Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.4) : Theme.borderSoft
        RowLayout {
            id: head
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
            spacing: 8
            Text { text: sec.title; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 16 }
            Text { text: sec.sub; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; Layout.fillWidth: true; elide: Text.ElideRight }
            Rectangle { visible: sec.tag !== ""; radius: 8; color: Qt.rgba(1, 1, 1, 0.06); border.color: sec.tagColor
                implicitWidth: tagT.implicitWidth + 14; implicitHeight: 22
                Text { id: tagT; anchors.centerIn: parent; text: sec.tag; color: sec.tagColor; font.family: Theme.sans; font.pixelSize: 11 } }
        }
        ColumnLayout { id: body; anchors { left: parent.left; right: parent.right; top: head.bottom; margins: 12; topMargin: 8 } spacing: 6 }
    }
}
