import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Listen, say it, get a transcript and a pronunciation rating (Azure Speech).
// Takes aren't kept or played back.
ColumnLayout {
    id: s
    property var ex: ({})
    readonly property string pmode: (app.ws && app.ws.mode) || ""
    property bool showEnglish: pmode === "guided"
    property int selfRating: -1
    readonly property bool micBlocked: audio.state === "unavailable" || audio.state === "permission_required"
    property bool skipped: false
    readonly property bool complete: speech.state === "done" || speech.state === "error" || skipped
    spacing: 16

    Text { text: "LISTEN, SAY IT, GET RATED"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.6; font.weight: Font.Bold }

    Card {
        Layout.fillWidth: true; implicitHeight: refRow.implicitHeight + 44; elevated: true
        RowLayout {
            id: refRow
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 22 }
            spacing: 20
            SayButton { phrase: s.ex.es || ""; size: 68 }
            ColumnLayout {
                spacing: 6; Layout.fillWidth: true
                Text { text: s.ex.es || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 28; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Text {
                    text: s.showEnglish ? (s.ex.en || "") : "Show translation"
                    color: s.showEnglish ? Theme.text2 : Theme.blue; font.family: Theme.sans; font.pixelSize: 14
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: s.showEnglish = !s.showEnglish }
                }
                Text { visible: !!s.ex.tip; text: "Tip: " + (s.ex.tip || ""); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            }
            SayButton { phrase: s.ex.es || ""; slow: true; size: 44; tint: Theme.cardElevated }
        }
    }

    Card {
        Layout.fillWidth: true; implicitHeight: recCol.implicitHeight + 44
        ColumnLayout {
            id: recCol
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 22 }
            spacing: 14
            RowLayout {
                spacing: 8
                Text { text: "Rate it as:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                Repeater {
                    model: [["Say this phrase", false], ["My own words", true]]
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool on: speech.free === modelData[1]
                        implicitWidth: ml.implicitWidth + 24; implicitHeight: 30; radius: 15
                        color: on ? Theme.navActive : "transparent"; border.color: on ? Theme.blue : Theme.border
                        Text { id: ml; anchors.centerIn: parent; text: modelData[0]; color: on ? Theme.text : Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: speech.setFree(modelData[1]) }
                        Accessible.role: Accessible.RadioButton; Accessible.name: modelData[0]
                    }
                }
            }
            RowLayout {
                spacing: 22
                RoundButton {
                    id: rec
                    implicitWidth: 88; implicitHeight: 88
                    enabled: ["ready", "saved", "recording", "failed", "playback"].indexOf(audio.state) >= 0 && speech.state !== "checking"
                    focusPolicy: Qt.StrongFocus
                    Accessible.name: audio.state === "recording" ? "Stop listening" : "Speak"
                    onClicked: audio.state === "recording" ? audio.stopRecording() : audio.startRecording()
                    contentItem: Item {
                        Rectangle { anchors.centerIn: parent; visible: audio.state === "recording"; width: 26; height: 26; radius: 5; color: Theme.text }
                        Icon { anchors.centerIn: parent; visible: audio.state !== "recording"; name: rec.enabled ? "mic" : "mic-off"; color: rec.enabled ? Theme.onCoral : Theme.text; size: 34 }
                    }
                    background: Rectangle {
                        radius: 44
                        color: !rec.enabled ? Qt.rgba(1, 1, 1, 0.1) : (audio.state === "recording" ? Theme.coralDeep : Theme.coral)
                        border.color: "white"; border.width: rec.visualFocus ? 2 : 0
                        Rectangle { anchors.centerIn: parent; visible: audio.state === "recording"
                            width: parent.width + 10 + audio.level * 40; height: width; radius: width / 2
                            color: "transparent"; border.color: Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.55); border.width: 3 }
                    }
                }
                ColumnLayout {
                    spacing: 6; Layout.fillWidth: true
                    Text { text: speech.state === "checking" ? "Listening to your take…" : (audio.state === "recording" ? "Listening…" : (speech.state === "done" ? "Press the mic to try again" : audio.stateLabel)); color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; font.weight: Font.DemiBold; Layout.fillWidth: true }
                    Text { text: speech.state === "checking" ? "Transcribing and rating your pronunciation." : (speech.state === "done" ? "Your best take counts — try as many times as you like." : audio.detail); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { visible: audio.state === "recording"; text: (audio.durationMs / 1000).toFixed(1) + " s"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                }
                PillButton { visible: audio.state === "permission_required"; text: "Allow microphone"; onClicked: audio.requestPermission() }
            }
            // ---- result: what Habla heard + rating ----
            ColumnLayout {
                visible: speech.state === "done"
                spacing: 14
                Layout.fillWidth: true
                RowLayout {
                    spacing: 18
                    Layout.fillWidth: true
                    Rectangle {
                        implicitWidth: 92; implicitHeight: 92; radius: 46
                        color: "transparent"; border.width: 6
                        border.color: s.tone(speech.result.score || 0)
                        Column { anchors.centerIn: parent
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: speech.result.score || 0; color: Theme.text; font.family: Theme.sans; font.pixelSize: 30; font.weight: Font.Bold }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: "of 100"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 } }
                    }
                    ColumnLayout {
                        spacing: 6; Layout.fillWidth: true
                        Text { text: speech.result.label || ""; color: s.tone(speech.result.score || 0); font.family: Theme.sans; font.pixelSize: 20; font.weight: Font.DemiBold }
                        Text { text: "Habla heard:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                        Text { text: "\u201C" + (speech.result.heard || "") + "\u201D"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 22; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    }
                }
                // per-word accuracy on the target phrase
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: speech.result.words || []
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool missed: modelData.error === "Omission"
                            readonly property bool extra: modelData.error === "Insertion"
                            height: 34; width: wl.implicitWidth + 22; radius: 8
                            color: Qt.rgba(1, 1, 1, 0.04)
                            border.width: 1.5
                            border.color: missed || extra ? Theme.text3 : s.tone(modelData.accuracy)
                            Text { id: wl; anchors.centerIn: parent; text: modelData.word + (missed ? "  (missed)" : (extra ? "  (extra)" : "  " + modelData.accuracy))
                                   color: missed || extra ? Theme.text3 : Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.strikeout: missed }
                        }
                    }
                }
                RowLayout {
                    spacing: 22
                    Repeater {
                        model: speech.result.free
                               ? [["Accuracy", "accuracy", "How close each sound was"], ["Fluency", "fluency", "Smooth, natural pacing"]]
                               : [["Accuracy", "accuracy", "How close each sound was"], ["Fluency", "fluency", "Smooth, natural pacing"], ["Completeness", "completeness", "Said every word"]]
                        delegate: ColumnLayout {
                            required property var modelData
                            spacing: 4
                            Text { text: modelData[0] + "  " + (speech.result[modelData[1]] || 0); color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold }
                            Rectangle { implicitWidth: 160; implicitHeight: 6; radius: 3; color: Qt.rgba(1, 1, 1, 0.1)
                                Rectangle { width: parent.width * (speech.result[modelData[1]] || 0) / 100; height: 6; radius: 3; color: s.tone(speech.result[modelData[1]] || 0) } }
                            Text { text: modelData[2]; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                        }
                    }
                }
                // one-sentence tip: the most useful thing to fix next
                Rectangle {
                    visible: !!speech.result.tip
                    Layout.fillWidth: true; Layout.topMargin: 2
                    implicitHeight: tipRow.implicitHeight + 20; radius: 10
                    color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.10)
                    border.color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.35)
                    RowLayout {
                        id: tipRow
                        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 12; rightMargin: 12 }
                        spacing: 10
                        Icon { name: "lightbulb"; color: Theme.amber; size: 18; Layout.alignment: Qt.AlignTop }
                        Text { text: speech.result.tip || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14
                               wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    }
                    Accessible.role: Accessible.StaticText; Accessible.name: "Tip: " + (speech.result.tip || "")
                }
                Text { text: (speech.result.free ? "Rated by Microsoft Azure on how you pronounced what you said, in your own words." : "Rated by Microsoft Azure against the phrase above.")
                             + " Words under 60 are worth another listen."
                       color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            }
            Rectangle {
                visible: speech.state === "error"
                Layout.fillWidth: true; implicitHeight: errT.implicitHeight + 24; radius: 10
                color: Qt.rgba(0.95, 0.6, 0.2, 0.1); border.color: Qt.rgba(0.95, 0.6, 0.2, 0.4)
                Text { id: errT; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 14 }
                       text: (speech.result.error || "") + "  You can try again or continue."; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap }
            }
            // No microphone: skip now, finish it later from Review
            RowLayout {
                visible: !s.skipped && speech.state !== "done" && speech.state !== "checking" && audio.state !== "recording"
                spacing: 14
                Layout.fillWidth: true
                PillButton { text: "Skip for now"; primary: false; implicitWidth: 170
                             onClicked: { app.skipSpeaking(); s.skipped = true } }
                Text { text: s.micBlocked ? "Say it out loud along with the audio, then skip. It waits for you under Review › Speaking you skipped."
                                          : "Can't talk out loud right now? Skip it. It waits for you under Review › Speaking you skipped."
                       color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            }
            Text {
                visible: s.skipped
                text: "Skipped. You'll find it under Review › Speaking you skipped whenever you're ready."
                color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
            }
        }
    }
    function tone(v) { return v >= 80 ? Theme.green : (v >= 60 ? Theme.amber : Theme.coral) }
    // Exercises that ask for your own name, places or answer default to free speech.
    readonly property bool ownWords: /\b(own|your real|no script|own words)\b/i.test(ex.tip || "")
    // Auto-stop waits longer for a pause when you're speaking freely.
    readonly property bool freeMode: speech.free
    onFreeModeChanged: audio.setPauseMs(freeMode ? 2000 : 1200)
    Component.onCompleted: { speech.setReference(ex.es || "", ownWords); audio.setPauseMs(speech.free ? 2000 : 1200); autoplay.start() }
    Timer { id: autoplay; interval: 400; onTriggered: app.say(s.ex.es, false) }
}
