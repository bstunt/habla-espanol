import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Listen (or read) and choose. Used by listen_choose, dialogue questions,
// exit items and spaced review.
ColumnLayout {
    id: c
    property var item: ({})
    property string part: ""
    property bool exam: false
    property bool review: false          // spaced review: answers go to app.answerReview
    property int reviewIndex: 0
    property int picked: -1
    property int correctIndex: -1
    readonly property string pmode: (app.ws && app.ws.mode) || ""      // Vida Real practice mode
    property bool showText: pmode === "guided" || (pmode !== "independent" && !!item.show_text)
    readonly property bool complete: picked >= 0
    signal answered(bool correct)
    spacing: 16

    Component.onCompleted: if (item.audio) autoplay.start()
    Timer { id: autoplay; interval: 350; onTriggered: app.say(c.item.audio, false) }

    PromptBlock { prompt: c.item.prompt || ""; Layout.fillWidth: true }

    RowLayout {
        visible: !!c.item.audio
        spacing: 14
        SayButton { phrase: c.item.audio || ""; size: 56 }
        SayButton { phrase: c.item.audio || ""; slow: true; size: 40; tint: Theme.cardElevated }
        Text {
            visible: c.showText || c.complete
            text: c.item.audio || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 24
            wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        Text {
            visible: !c.showText && !c.complete && !c.exam && c.pmode !== "independent"
            text: "Show text"; color: Theme.blue; font.family: Theme.sans; font.pixelSize: 14
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: { c.showText = true; app.useHint() } }
        }
        Item { Layout.fillWidth: true; visible: !(c.showText || c.complete) }
    }

    ColumnLayout {
        spacing: 10
        Layout.fillWidth: true
        Repeater {
            model: c.item.options || []
            delegate: OptionButton {
                required property var modelData
                required property int index
                Layout.fillWidth: true
                text: modelData
                keyHint: String(index + 1)
                spanish: /[¿¡]/.test(modelData) || (/[áéíóúñ]/.test(modelData) && / /.test(modelData)) || (c.item.options_es === true)
                enabled: !c.complete
                result: !c.complete ? "" : (index === c.correctIndex ? "correct" : (index === c.picked ? "wrong" : "dim"))
                onClicked: c.pick(index)
            }
        }
    }

    Feedback {
        Layout.fillWidth: true
        visible: c.complete
        good: c.picked === c.correctIndex
        title: !c.complete ? "" : (c.picked === c.correctIndex ? "Correct." : "Not this time — the right answer is highlighted.")
        body: c.item.explain || ""
    }

    function pick(i) {
        if (complete) return
        var r = review ? app.answerReview(reviewIndex, i) : app.answerChoice(part, i, 0)
        correctIndex = r.answer
        picked = i
        answered(r.correct)
    }
    Keys.onPressed: (e) => {
        var n = e.key - Qt.Key_1
        if (!complete && n >= 0 && n < (item.options || []).length) { pick(n); e.accepted = true }
        else if (e.key === Qt.Key_R && item.audio) { app.say(item.audio, false); e.accepted = true }
    }
    focus: true
}
