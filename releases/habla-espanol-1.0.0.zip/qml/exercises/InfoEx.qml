import QtQuick
import QtQuick.Layouts
import "../components"
import "Md.js" as Md

ColumnLayout {
    id: i
    property var ex: ({})
    readonly property bool complete: true
    spacing: 18
    Text { text: "LEARN"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.6; font.weight: Font.Bold }
    Text { text: i.ex.title || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 30; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    Text { text: Md.md(i.ex.body); textFormat: Text.StyledText; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 17; lineHeight: 1.35; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    // Longer lists (e.g. letter names) go in two columns so they fit without scrolling.
    GridLayout {
      Layout.fillWidth: true
      columns: (i.ex.examples || []).length > 5 ? 2 : 1
      columnSpacing: 12; rowSpacing: 10
      Repeater {
        model: i.ex.examples || []
        delegate: Rectangle {
            required property var modelData
            Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 66; radius: 12; color: Qt.rgba(1, 1, 1, 0.04); border.color: Theme.borderSoft
            RowLayout {
                anchors.fill: parent; anchors.margins: 12; spacing: 14
                SayButton { phrase: modelData.es; size: 40 }
                ColumnLayout { spacing: 2; Layout.fillWidth: true
                    Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 21; Layout.fillWidth: true; elide: Text.ElideRight }
                    Text { text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; Layout.fillWidth: true; elide: Text.ElideRight } }
                SayButton { phrase: modelData.es; slow: true; size: 32; tint: Theme.cardElevated }
            }
        }
    }
    }
}
