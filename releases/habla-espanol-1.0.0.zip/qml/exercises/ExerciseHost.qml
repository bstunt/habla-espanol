import QtQuick
import QtQuick.Layouts
import "../components"

// Picks the right component for the current exercise.
Item {
    id: h
    property var ex: ({})
    property var st: ({})
    property string partner: "Ana"
    property string learner: "Sam"
    readonly property bool complete: ld.item ? ld.item.complete : false
    implicitHeight: ld.item ? ld.item.implicitHeight : 0
    // Recreate the component for every new exercise, even of the same type.
    onExChanged: { ld.active = false; ld.active = true }
    Loader {
        id: ld
        width: parent.width
        focus: true
        sourceComponent: ({ info: infoC, listen_choose: choiceC, dialogue: dialogueC, build: buildC, type: typeC,
                            speak: speakC, conversation: convoC, exit: exitC, reflect: reflectC })[h.ex.type] || infoC
        onLoaded: item.forceActiveFocus()
    }
    Component { id: infoC; InfoEx { ex: h.ex } }
    Component { id: choiceC; ChoiceItem { item: h.ex; part: "" } }
    Component { id: dialogueC; DialogueEx { ex: h.ex; st: h.st } }
    Component { id: buildC; BuildItem { item: h.ex; part: "" } }
    Component { id: typeC; TypeItem { item: h.ex; part: ""; draft: h.st.draft || ""; onDraftChanged2: (t) => draftSave.pending = t } }
    Component { id: speakC; SpeakEx { ex: h.ex } }
    Component { id: convoC; ConversationEx { ex: h.ex; st: h.st; partner: h.partner; learner: h.learner } }
    Component { id: exitC; ExitEx { ex: h.ex; st: h.st } }
    Component { id: reflectC; ReflectEx { ex: h.ex } }
    QtObject {
        id: draftSave
        property string pending: ""
        onPendingChanged: saveTimer.restart()
    }
    Timer { id: saveTimer; interval: 500; onTriggered: app.saveDraft(draftSave.pending) }
}
