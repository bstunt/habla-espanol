import QtQuick
import QtQuick.Layouts
import "../components"

ColumnLayout {
    id: r
    property var ex: ({})
    property int picked: -1
    readonly property bool complete: picked >= 0
    spacing: 16
    Text { text: "REFLECT"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.6; font.weight: Font.Bold }
    Text { text: r.ex.prompt || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 26; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    Repeater {
        model: r.ex.options || []
        delegate: OptionButton {
            required property var modelData
            required property int index
            Layout.fillWidth: true
            text: modelData
            result: r.picked === index ? "correct" : ""
            onClicked: { r.picked = index; app.reflectPick(index) }
        }
    }
    Text { visible: r.complete; text: "Thanks — this helps Habla decide what to bring back in your reviews."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
}
