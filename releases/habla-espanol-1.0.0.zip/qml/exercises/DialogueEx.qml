import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Listen to the conversation first (transcript hidden), then answer questions.
ColumnLayout {
    id: d
    property var ex: ({})
    property var st: ({})
    readonly property string pmode: (app.ws && app.ws.mode) || ""      // Vida Real practice mode
    property bool showText: false
    property bool showEnglish: pmode === "guided"
    property int playing: -1
    property bool heard: !!st.heard
    property int q: st.q || 0
    property int answeredCount: st.q || 0   // on resume, earlier questions were answered
    readonly property bool complete: answeredCount >= (ex.questions || []).length
    spacing: 14

    Text { text: d.ex.setting || ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    RowLayout {
        spacing: 10
        PillButton { text: d.playing >= 0 ? "Playing…" : (d.heard ? "Play again" : "Play conversation"); iconName: "play"; implicitWidth: 230; onClicked: d.playAll() }
        PillButton { text: d.showText ? "Hide transcript" : "Show transcript"; primary: false; implicitWidth: 190; onClicked: { d.showText = !d.showText; if (d.showText && !d.heard) app.useHint() } }
        PillButton { visible: d.showText; text: d.showEnglish ? "Hide English" : "English"; primary: false; implicitWidth: 140; onClicked: d.showEnglish = !d.showEnglish }
    }
    Card {
        Layout.fillWidth: true
        implicitHeight: lines.implicitHeight + 28
        Column {
            id: lines
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
            spacing: 8
            Repeater {
                model: d.ex.lines || []
                delegate: Item {
                    required property var modelData
                    required property int index
                    readonly property bool mine: modelData.who === "Tú" || (d.ex.lines.length > 0 && modelData.who !== d.ex.lines[0].who)
                    width: lines.width; height: bubble.height
                    Rectangle {
                        id: bubble
                        anchors.right: mine ? parent.right : undefined
                        width: Math.min(parent.width * 0.78, inner.implicitWidth + 28); height: inner.implicitHeight + 18
                        radius: 14
                        color: mine ? Theme.navActive : Theme.cardElevated
                        border.color: d.playing === index ? Theme.coral : "transparent"; border.width: 2
                        RowLayout {
                            id: inner
                            anchors { left: parent.left; top: parent.top; margins: 9; leftMargin: 12 }
                            spacing: 10
                            SayButton { phrase: modelData.es; size: 28; tint: mine ? Theme.blueDeep : Theme.blue }
                            ColumnLayout { spacing: 1
                                Text { text: modelData.who === "Tú" ? "You" : modelData.who; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
                                Text { text: d.showText ? modelData.es : "• • •"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.maximumWidth: lines.width * 0.6 }
                                Text { visible: d.showText && d.showEnglish; text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.maximumWidth: lines.width * 0.6 } }
                        }
                    }
                }
            }
        }
    }
    Text { visible: !d.heard; text: "Listen to the whole conversation first, then answer the questions."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }

    HablaReal {
        Layout.fillWidth: true
        visible: d.heard && !!d.ex.habla_real
        info: d.ex.habla_real || ({})
    }

    // A fresh ChoiceItem per question (the model changes with d.q), so one
    // question's answer never carries over to the next.
    Repeater {
        model: d.heard && d.q < (d.ex.questions || []).length ? [d.q] : []
        delegate: ChoiceItem {
            required property var modelData
            Layout.fillWidth: true
            item: d.ex.questions[modelData]
            part: "q" + modelData
            onAnswered: { d.answeredCount = Math.max(d.answeredCount, modelData + 1); nextQ.start() }
        }
    }
    Timer { id: nextQ; interval: 1600; onTriggered: if (d.q + 1 < (d.ex.questions || []).length) { d.q += 1; app.saveState({ heard: true, q: d.q }) } }
    Text { visible: d.complete; text: "All questions answered. Continue when you're ready."; color: Theme.green; font.family: Theme.sans; font.pixelSize: 15 }

    Connections {
        target: audio
        function onPlaybackFinished() {
            if (d.playing < 0) return
            if (d.playing + 1 < (d.ex.lines || []).length) { d.playing += 1; gap.start() }
            else { d.playing = -1; if (!d.heard) { d.heard = true; app.saveState({ heard: true, q: 0 }) } }
        }
    }
    Timer { id: gap; interval: 350; onTriggered: app.say(d.ex.lines[d.playing].es, false) }
    Timer { id: fallback; interval: 900; repeat: true; running: d.playing >= 0 && !voice.available
            onTriggered: { if (d.playing + 1 < (d.ex.lines || []).length) d.playing += 1; else { d.playing = -1; d.heard = true } } }
    function playAll() { if ((ex.lines || []).length === 0) return; playing = 0; app.say(ex.lines[0].es, false) }
    Component.onCompleted: if (!heard) playAll()
}
