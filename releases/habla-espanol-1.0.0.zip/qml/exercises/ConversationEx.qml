import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Branching conversation with the session's partner. Spanish only by default;
// English can be shown (recorded as support used).
ColumnLayout {
    id: c
    property var ex: ({})
    property var st: ({})
    property string partner: "Ana"
    property string learner: "Sam"
    property string node: st.node || ex.start || ""
    property var path: st.path || []           // [{who, es, en, feedback, quality}]
    // Vida Real practice mode: guided shows English, independent hides it
    readonly property string mode: (app.ws && app.ws.mode) || ""
    property bool showEnglish: mode === "guided"
    property bool englishUsed: mode === "guided"
    property string replyMode: "choose"          // choose | type | say
    property bool notEvaluated: false
    property bool awaitingSpeech: false
    property string heard: ""
    readonly property bool micReady: ["ready", "saved", "failed", "playback", "recording"].indexOf(audio.state) >= 0
    property string feedback: ""
    property string feedbackQuality: ""
    readonly property var cur: (ex.nodes || {})[node] || ({})
    readonly property bool ended: !!cur.end
    readonly property bool complete: ended
    spacing: 14

    RowLayout {
        Layout.fillWidth: true
        ColumnLayout { spacing: 4; Layout.fillWidth: true
            Text { text: c.ex.setting || ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Text { text: "Goal: " + (c.ex.goal || ""); color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.Medium; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
        PillButton { visible: c.mode !== "independent"; text: c.showEnglish ? "Hide English" : "Show English"; primary: false; implicitWidth: 170
                     onClicked: { c.showEnglish = !c.showEnglish; if (c.showEnglish) c.englishUsed = true } }
    }

    Card {
        Layout.fillWidth: true
        Layout.preferredHeight: 330
        ListView {
            id: chat
            anchors.fill: parent; anchors.margins: 14
            clip: true; spacing: 8
            model: c.path.concat([{ who: "partner", es: c.cur.es || "", en: c.cur.en || "", live: true }])
            onCountChanged: positionViewAtEnd()
            delegate: Item {
                required property var modelData
                readonly property bool mine: modelData.who === "learner"
                width: chat.width; height: bub.height
                Rectangle {
                    id: bub
                    anchors.right: mine ? parent.right : undefined
                    width: Math.min(chat.width * 0.8, row.implicitWidth + 26); height: row.implicitHeight + 18
                    radius: 14
                    color: mine ? (modelData.quality === "off" ? Qt.rgba(0.91, 0.36, 0.46, 0.25) : Theme.navActive) : Theme.cardElevated
                    RowLayout {
                        id: row
                        anchors { left: parent.left; top: parent.top; margins: 9; leftMargin: 12 }
                        spacing: 10
                        SayButton { visible: !mine; phrase: modelData.es; size: 28 }
                        ColumnLayout { spacing: 1
                            Text { text: mine ? c.learner : (c.ex.partner || c.partner); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
                            Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.maximumWidth: chat.width * 0.62 }
                            Text { visible: c.showEnglish && !mine && !!modelData.en; text: modelData.en || ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.maximumWidth: chat.width * 0.62 } }
                    }
                }
            }
        }
    }

    Feedback {
        Layout.fillWidth: true
        visible: c.feedback !== ""
        good: c.feedbackQuality === "repair"
        title: c.feedbackQuality === "repair" ? "Nice repair." : (c.feedbackQuality === "off" ? "Hmm — try another reply." : "")
        body: c.feedback
    }

    ColumnLayout {
        visible: !c.ended
        spacing: 10
        Layout.fillWidth: true
        RowLayout {
            spacing: 8
            Text { text: "Your reply:"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; Layout.rightMargin: 6 }
            Repeater {
                model: [["choose", "Choose"], ["type", "Type it"], ["say", "Say it"]]
                delegate: Rectangle {
                    required property var modelData
                    readonly property bool on: c.replyMode === modelData[0]
                    readonly property bool usable: modelData[0] !== "say" || c.micReady
                    implicitWidth: rl.implicitWidth + 24; implicitHeight: 30; radius: 15
                    opacity: usable ? 1 : 0.45
                    color: on ? Theme.navActive : "transparent"; border.color: on ? Theme.blue : Theme.border
                    Text { id: rl; anchors.centerIn: parent; text: modelData[1]; color: on ? Theme.text : Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                    MouseArea { anchors.fill: parent; enabled: parent.usable; cursorShape: Qt.PointingHandCursor; onClicked: c.setReplyMode(modelData[0]) }
                    Accessible.role: Accessible.RadioButton; Accessible.name: modelData[1]
                }
            }
            Text { visible: !c.micReady; text: "(no microphone)"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
        }
        // a typed or spoken reply Habla couldn't match: never marked wrong
        Feedback {
            Layout.fillWidth: true
            visible: c.notEvaluated
            good: false
            title: "Habla can't check that reply."
            body: (c.heard ? "It heard: \u201C" + c.heard + "\u201D. " : "") + "It may well be fine. Pick the reply closest to what you meant, or try again."
        }
        // choose
        Repeater {
            model: c.replyMode === "choose" || c.notEvaluated ? (c.cur.options || []) : []
            delegate: RowLayout {
                required property var modelData
                required property int index
                Layout.fillWidth: true; spacing: 10
                SayButton { phrase: modelData.es; size: 32; tint: Theme.cardElevated }
                ColumnLayout { spacing: 2; Layout.fillWidth: true
                    OptionButton { Layout.fillWidth: true; text: modelData.es; spanish: true; keyHint: String(index + 1); onClicked: c.choose(index, "") }
                    Text { visible: c.showEnglish && !!modelData.en; text: modelData.en || ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; Layout.leftMargin: 14 } }
            }
        }
        // type
        RowLayout {
            visible: c.replyMode === "type" && !c.notEvaluated
            spacing: 10
            Layout.fillWidth: true
            TextField {
                id: reply
                Layout.fillWidth: true; Layout.preferredHeight: 50
                placeholderText: "Type your reply in Spanish…"
                leftPadding: 16; rightPadding: 16; verticalAlignment: TextInput.AlignVCenter
                color: Theme.text; font.family: Theme.serif; font.pixelSize: 19; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 12; color: Qt.rgba(1, 1, 1, 0.05); border.color: reply.activeFocus ? Theme.blue : Theme.border; border.width: reply.activeFocus ? 2 : 1 }
                onAccepted: c.submitText(text)
                Accessible.name: "Your reply in Spanish"
            }
            PillButton { text: "Reply"; implicitWidth: 120; enabled: reply.text.trim() !== ""; onClicked: c.submitText(reply.text) }
        }
        // say
        RowLayout {
            visible: c.replyMode === "say" && !c.notEvaluated
            spacing: 16
            RoundButton {
                id: talk
                implicitWidth: 64; implicitHeight: 64
                enabled: c.micReady && speech.state !== "checking"
                onClicked: audio.state === "recording" ? audio.stopRecording() : c.startTalking()
                Accessible.name: audio.state === "recording" ? "Stop" : "Say your reply"
                contentItem: Item {
                    Rectangle { anchors.centerIn: parent; visible: audio.state === "recording"; width: 20; height: 20; radius: 4; color: Theme.onCoral }
                    Icon { anchors.centerIn: parent; visible: audio.state !== "recording"; name: "mic"; color: Theme.onCoral; size: 26 }
                }
                background: Rectangle { radius: 32; color: talk.enabled ? (audio.state === "recording" ? Theme.coralDeep : Theme.coral) : Qt.rgba(1, 1, 1, 0.1)
                    Rectangle { anchors.centerIn: parent; visible: audio.state === "recording"; width: parent.width + 8 + audio.level * 30; height: width; radius: width / 2
                                color: "transparent"; border.color: Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.5); border.width: 3 } }
            }
            Text {
                text: speech.state === "checking" && c.awaitingSpeech ? "Listening to your reply…"
                      : (audio.state === "recording" ? "Say your reply. Habla stops when you finish."
                      : (speech.state === "error" && c.awaitingSpeech ? (speech.result.error || "") : "Press the mic and answer out loud."))
                color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
            }
        }
    }
    RowLayout {
        visible: c.ended
        spacing: 12
        Icon { name: "circle-check"; color: Theme.green; size: 22 }
        Text { text: "Conversation complete" + (c.englishUsed ? " (with English support)." : " — all in Spanish!"); color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; Layout.fillWidth: true }
        PillButton { text: "Try a different path"; primary: false; implicitWidth: 220; onClicked: c.restart() }
    }

    function choose(i, said) {
        var opt = cur.options[i]
        var r = app.conversationPick(node, i, englishUsed)
        var p = path.slice()
        p.push({ who: "partner", es: cur.es, en: cur.en })
        p.push({ who: "learner", es: said || opt.es, quality: r.quality })
        notEvaluated = false; heard = ""; reply.text = ""
        feedback = r.feedback || ""
        feedbackQuality = r.quality
        if (r.quality === "off") {
            path = p            // partner line repeats as the live bubble
        } else {
            path = p
            node = r.next
        }
        app.saveState({ node: node, path: path })
        speakLater.start()
    }
    function setReplyMode(m) {
        replyMode = m; notEvaluated = false; heard = ""
        if (m === "type") reply.forceActiveFocus()
    }
    function submitText(text) {
        if (!text.trim()) return
        var r = app.conversationMatch(node, text)
        if (r.index >= 0) choose(r.index, text.trim())
        else { notEvaluated = true; heard = "" }
    }
    function startTalking() {
        heard = ""; notEvaluated = false
        speech.setReference("conversation", true)      // free speech: transcribe what was said
        awaitingSpeech = true
        audio.startRecording()
    }
    Connections {
        target: speech
        function onChanged() {
            if (!c.awaitingSpeech) return
            if (speech.state === "done") {
                c.awaitingSpeech = false
                var said = speech.result.heard || ""
                var r = app.conversationMatch(c.node, said)
                if (r.index >= 0) c.choose(r.index, said)
                else { c.heard = said; c.notEvaluated = true }
            } else if (speech.state === "error") {
                c.awaitingSpeech = false
            }
        }
    }
    function restart() {
        path = []; node = ex.start; feedback = ""; englishUsed = false
        app.saveState({ node: node, path: [] })
        speakLater.start()
    }
    Timer { id: speakLater; interval: 450; onTriggered: if (c.cur.es) app.say(c.cur.es, false) }
    Component.onCompleted: speakLater.start()
    Keys.onPressed: (e) => {
        var n = e.key - Qt.Key_1
        if (!ended && replyMode === "choose" && n >= 0 && n < (cur.options || []).length) { choose(n, ""); e.accepted = true }
    }
    focus: true
}
