import QtQuick
import QtQuick.Layouts
import "../components"

// Exit check: no hints, one try per item, new contexts.
ColumnLayout {
    id: xc
    property var ex: ({})
    property var st: ({})
    property int idx: st.idx || 0
    property int correct: st.correct || 0
    property bool itemDone: false
    readonly property int total: (ex.items || []).length
    readonly property bool finished: idx >= total
    readonly property bool complete: finished
    spacing: 16

    RowLayout {
        Layout.fillWidth: true
        Text { text: "CHECK · NO HINTS"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.6; font.weight: Font.Bold; Layout.fillWidth: true }
        Text { visible: !xc.finished; text: "Question " + (xc.idx + 1) + " of " + xc.total; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 }
    }
    Row {
        spacing: 6
        Repeater { model: xc.total; delegate: Rectangle { required property int index; width: 34; height: 6; radius: 3; color: index < xc.idx ? Theme.green : (index === xc.idx ? Theme.blue : Qt.rgba(1, 1, 1, 0.12)) } }
    }

    // Recreated for every question (model changes with idx) so no answer carries over.
    Repeater {
        model: xc.finished ? [] : [xc.idx]
        delegate: Loader {
            required property var modelData
            Layout.fillWidth: true
            onLoaded: item.forceActiveFocus()        // each new question is ready for the keyboard
            sourceComponent: {
                var t = xc.ex.items[modelData].type
                return t === "build" ? buildC : (t === "type" ? typeC : choiceC)
            }
        }
    }
    Component { id: choiceC; ChoiceItem { item: xc.ex.items[xc.idx]; part: "i" + xc.idx; exam: true; onAnswered: (ok) => xc.done(ok) } }
    Component { id: buildC; BuildItem { item: xc.ex.items[xc.idx]; part: "i" + xc.idx; exam: true; onAnswered: (ok) => xc.done(ok) } }
    Component { id: typeC; TypeItem { item: xc.ex.items[xc.idx]; part: "i" + xc.idx; exam: true; onAnswered: (ok) => xc.done(ok) } }

    PillButton {
        visible: xc.itemDone && !xc.finished
        text: xc.idx + 1 < xc.total ? "Next question" : "See results"
        implicitWidth: 200
        onClicked: xc.next()
    }

    Card {
        visible: xc.finished
        Layout.fillWidth: true; implicitHeight: res.implicitHeight + 40; elevated: true
        ColumnLayout {
            id: res
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 22 }
            spacing: 10
            Text { text: xc.correct + " of " + xc.total + " correct"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 34 }
            Text {
                text: xc.correct / Math.max(1, xc.total) >= 0.7
                      ? "You showed this session's language on your own, in new situations."
                      : "Some of this needs more practice. Those items go into your spaced review, and this check is marked for review — you can still move on."
                color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true
            }
        }
    }

    Shortcut { sequences: ["Return", "Enter"]; enabled: xc.itemDone && !xc.finished; onActivated: xc.next() }

    function done(ok) { if (ok) correct += 1; itemDone = true; app.saveState({ idx: idx, correct: correct, pending: true }) }
    function next() {
        itemDone = false
        idx += 1
        app.saveState({ idx: idx, correct: correct })
        if (idx >= total) app.setExitScore(correct / Math.max(1, total))
    }
}
