import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Typed answer. Accents are optional (noted, not penalized).
ColumnLayout {
    id: t
    property var item: ({})
    property string part: ""
    property bool exam: false
    property string draft: ""
    property int tries: 0
    property bool solved: false
    property bool revealed: false
    property bool hintShown: false
    property var result: ({})
    property int selfJudged: -1          // 1 = same meaning, 0 = different (self-review)
    readonly property bool complete: solved || (revealed && selfJudged >= 0)
    signal answered(bool correct)
    signal draftChanged2(string text)
    // the exercise gets focus when it opens: hand it to the answer box so you can type right away
    onActiveFocusChanged: if (activeFocus && !complete) field.forceActiveFocus()
    spacing: 16

    PromptBlock { prompt: t.item.prompt || ""; Layout.fillWidth: true }

    TextField {
        id: field
        Layout.fillWidth: true; Layout.preferredHeight: 56
        text: t.draft
        enabled: !t.complete
        placeholderText: "Type your answer with the keyboard…"
        leftPadding: 18; rightPadding: 18
        verticalAlignment: TextInput.AlignVCenter
        color: Theme.text; font.family: Theme.serif; font.pixelSize: 22
        placeholderTextColor: Theme.text3
        Accessible.name: "Your answer in Spanish"
        background: Rectangle { radius: 12; color: Qt.rgba(1, 1, 1, 0.05); border.color: t.solved ? Theme.green : (field.activeFocus ? Theme.blue : Theme.border); border.width: field.activeFocus || t.solved ? 2 : 1 }
        onTextEdited: t.draftChanged2(text)
        onAccepted: if (text.trim() !== "" && !t.complete) t.check()
        Component.onCompleted: forceActiveFocus()
    }

    // quick-insert for accented letters (the answer itself is typed on the keyboard)
    RowLayout {
        visible: !t.complete
        spacing: 6
        Text { text: "Add a special letter:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; Layout.rightMargin: 4 }
        Repeater {
            model: ["á", "é", "í", "ó", "ú", "ñ", "¿", "¡"]
            delegate: Button {
                required property var modelData
                text: modelData
                focusPolicy: Qt.NoFocus
                implicitWidth: 34; implicitHeight: 32
                onClicked: { field.insert(field.cursorPosition, modelData); field.forceActiveFocus(); t.draftChanged2(field.text) }
                contentItem: Text { text: parent.text; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                background: Rectangle { radius: 8; color: parent.hovered ? Theme.rowHover : Theme.cardElevated; border.color: Theme.border }
            }
        }
        Item { Layout.fillWidth: true }
        Text {
            visible: !t.exam && !!t.item.hint && ((app.ws && app.ws.mode) || "") !== "independent"
            text: t.hintShown ? "Hint: " + t.item.hint : "Show hint"
            color: t.hintShown ? Theme.text2 : Theme.blue; font.family: Theme.sans; font.pixelSize: 14
            MouseArea { anchors.fill: parent; enabled: !t.hintShown; cursorShape: Qt.PointingHandCursor; onClicked: { t.hintShown = true; app.useHint() } }
        }
        PillButton { text: t.tries > 0 ? "Check again" : "Check"; implicitWidth: 150; enabled: field.text.trim() !== ""; onClicked: t.check() }
    }

    Text { visible: t.tries > 0 && !t.revealed && !t.solved; text: "That isn't one of the answers Habla can check. Look again, then try once more."; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }

    Feedback {
        Layout.fillWidth: true
        visible: t.solved
        good: true
        title: t.result.accentNote ? "Correct — just add the accents when you write it:" : "Correct."
        spanish: t.solved ? (t.result.model || "") : ""
    }
    Text {
        visible: !t.solved && !!t.result.meaningNote
        text: t.result.meaningNote || ""
        color: Theme.amber; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold
        wrapMode: Text.WordWrap; Layout.fillWidth: true
    }
    // Not evaluated automatically: compare with the model and judge it yourself.
    Feedback {
        Layout.fillWidth: true
        visible: t.revealed
        good: false
        title: "Not evaluated automatically. Compare with a model answer:"
        spanish: t.revealed ? (t.result.model || "") : ""
        body: "Other correct answers exist. Does yours say the same thing?"
    }
    RowLayout {
        visible: t.revealed
        spacing: 10
        OptionButton { text: "Mine means the same"; implicitWidth: 220; result: t.selfJudged === 1 ? "correct" : ""; enabled: t.selfJudged < 0
                       onClicked: { t.selfJudged = 1; app.selfReviewTyped(t.part, true); t.answered(true) } }
        OptionButton { text: "Mine was different"; implicitWidth: 220; result: t.selfJudged === 0 ? "wrong" : ""; enabled: t.selfJudged < 0
                       onClicked: { t.selfJudged = 0; app.selfReviewTyped(t.part, false); t.answered(false) } }
    }

    function check() {
        var r = app.answerTyped(part, field.text, tries)
        result = r
        tries += 1
        if (r.correct) { solved = true; answered(true) }
        else if (exam || tries >= 2) { revealed = true }
    }
}
