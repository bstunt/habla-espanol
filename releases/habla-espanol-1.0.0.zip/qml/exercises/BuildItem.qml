import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Sentence builder. Click (or Enter/Space) a tile to add it; click a placed
// tile to remove it. Check, then retry; the answer is shown after two misses
// (one in exam mode).
ColumnLayout {
    id: b
    property var item: ({})
    property string part: ""
    property bool exam: false
    property var placed: []            // indexes into item.tiles
    property int tries: 0
    property bool solved: false
    property bool revealed: false
    property var result: ({})
    readonly property bool complete: solved || revealed
    signal answered(bool correct)
    spacing: 16

    PromptBlock { prompt: b.item.prompt || ""; Layout.fillWidth: true }

    // answer line
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: Math.max(72, placedFlow.implicitHeight + 24)
        radius: 12
        color: Qt.rgba(1, 1, 1, 0.03)
        border.color: b.solved ? Theme.green : (b.revealed ? Theme.amber : Theme.border)
        border.width: b.complete ? 2 : 1
        Flow {
            id: placedFlow
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 }
            spacing: 8
            Repeater {
                model: b.placed
                delegate: Button {
                    required property var modelData
                    text: b.item.tiles[modelData]
                    enabled: !b.complete
                    focusPolicy: Qt.StrongFocus
                    Accessible.name: "Remove " + text
                    onClicked: b.remove(modelData)
                    contentItem: Text { text: parent.text; color: Theme.text; font.family: Theme.serif; font.pixelSize: 20; horizontalAlignment: Text.AlignHCenter }
                    background: Rectangle { radius: 10; color: Theme.navActive; border.color: parent.visualFocus ? "white" : Qt.rgba(0.35, 0.65, 1, 0.5) }
                    padding: 12
                }
            }
            Text { visible: b.placed.length === 0; text: "Tap the words below in order"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14; height: 40; verticalAlignment: Text.AlignVCenter }
        }
    }

    // tile pool
    Flow {
        Layout.fillWidth: true
        spacing: 10
        Repeater {
            model: b.item.tiles || []
            delegate: Button {
                required property var modelData
                required property int index
                text: modelData
                visible: b.placed.indexOf(index) < 0
                enabled: !b.complete
                focusPolicy: Qt.StrongFocus
                Accessible.name: "Add " + modelData
                onClicked: b.add(index)
                padding: 12
                contentItem: Text { text: parent.text; color: Theme.text; font.family: Theme.serif; font.pixelSize: 20; horizontalAlignment: Text.AlignHCenter }
                background: Rectangle { radius: 10; color: parent.hovered ? Theme.rowHover : Theme.cardElevated; border.color: parent.visualFocus ? Theme.blue : Theme.border; border.width: parent.visualFocus ? 2 : 1 }
            }
        }
    }

    RowLayout {
        spacing: 10
        visible: !b.complete
        PillButton { text: "Clear"; primary: false; implicitWidth: 110; enabled: b.placed.length > 0; onClicked: b.placed = [] }
        PillButton { text: b.tries > 0 ? "Check again" : "Check"; implicitWidth: 150; enabled: b.placed.length > 0; onClicked: b.check() }
        Text { visible: b.tries > 0 && !b.complete; text: "Not quite. Look at the word order and try again."; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14; Layout.leftMargin: 6 }
    }

    Feedback {
        Layout.fillWidth: true
        visible: b.complete
        good: b.solved
        title: b.solved ? "That's right." : (b.complete ? "Here's the sentence:" : "")
        spanish: b.result.sentence || ""
        body: {
            var g = b.result.gloss || []
            var s = []
            for (var i = 0; i < g.length; i++) s.push("<b>" + g[i].es + "</b> — " + g[i].en)
            return s.join("<br>")
        }
    }

    function add(i) { var p = placed.slice(); p.push(i); placed = p }
    function remove(i) { var p = placed.slice(); p.splice(p.indexOf(i), 1); placed = p }
    // Enter checks the sentence once tiles are placed
    Shortcut { sequences: ["Return", "Enter"]; enabled: !b.complete && b.placed.length > 0; onActivated: b.check() }

    function check() {
        var words = placed.map(function (i) { return item.tiles[i] })
        var r = app.answerBuild(part, words, tries)
        result = r
        tries += 1
        if (r.correct) { solved = true; answered(true) }
        else if (exam || tries >= 2) { revealed = true; answered(false) }
    }
}
