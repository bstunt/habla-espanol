import QtQuick
import QtQuick.Window

// Line chart for 0–100 values over time. points: [{label, value}]
Item {
    id: lc
    property var points: []
    property color color: Theme.blue
    property string emptyText: "Nothing yet"
    readonly property real k: Math.max(1, Theme.uiScale * (Screen.devicePixelRatio || 1))
    readonly property real padL: 30
    readonly property real padB: 22
    implicitHeight: 190
    Text { anchors.centerIn: parent; visible: lc.points.length === 0; text: lc.emptyText; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14; width: parent.width * 0.8; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter }
    Repeater {     // y gridline labels
        model: [100, 50, 0]
        delegate: Text {
            required property int modelData
            visible: lc.points.length > 0
            x: 0; y: (lc.height - lc.padB) * (1 - modelData / 100) - height / 2
            text: modelData; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 10
        }
    }
    Canvas {
        id: cv
        visible: lc.points.length > 0
        width: lc.width * lc.k; height: lc.height * lc.k
        scale: 1 / lc.k; transformOrigin: Item.TopLeft
        onPaint: {
            var ctx = getContext("2d"); ctx.reset(); ctx.scale(lc.k, lc.k)
            var w = lc.width - lc.padL - 6, h = lc.height - lc.padB, n = lc.points.length
            ctx.strokeStyle = Qt.rgba(1, 1, 1, 0.08); ctx.lineWidth = 1
            for (var g = 0; g <= 2; g++) { var gy = h * g / 2 + 0.5; ctx.beginPath(); ctx.moveTo(lc.padL, gy); ctx.lineTo(lc.padL + w, gy); ctx.stroke() }
            if (!n) return
            function px(i) { return lc.padL + (n === 1 ? w / 2 : w * i / (n - 1)) }
            function py(v) { return h * (1 - v / 100) }
            // area
            var grad = ctx.createLinearGradient(0, 0, 0, h)
            grad.addColorStop(0, Qt.rgba(lc.color.r, lc.color.g, lc.color.b, 0.28)); grad.addColorStop(1, Qt.rgba(lc.color.r, lc.color.g, lc.color.b, 0))
            ctx.beginPath(); ctx.moveTo(px(0), h)
            for (var i = 0; i < n; i++) ctx.lineTo(px(i), py(lc.points[i].value))
            ctx.lineTo(px(n - 1), h); ctx.closePath(); ctx.fillStyle = grad; ctx.fill()
            // line + dots
            ctx.strokeStyle = lc.color; ctx.lineWidth = 2.2; ctx.beginPath()
            for (i = 0; i < n; i++) { if (i === 0) ctx.moveTo(px(i), py(lc.points[i].value)); else ctx.lineTo(px(i), py(lc.points[i].value)) }
            ctx.stroke()
            ctx.fillStyle = lc.color
            for (i = 0; i < n; i++) { ctx.beginPath(); ctx.ellipse(px(i) - 3, py(lc.points[i].value) - 3, 6, 6); ctx.fill() }
        }
    }
    Text { visible: lc.points.length > 0; x: lc.padL; y: lc.height - 16; text: lc.points.length ? lc.points[0].label : ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
    Text { visible: lc.points.length > 1; anchors.right: parent.right; y: lc.height - 16; text: lc.points.length ? lc.points[lc.points.length - 1].label : ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
    onPointsChanged: cv.requestPaint()
    onWidthChanged: cv.requestPaint()
    onHeightChanged: cv.requestPaint()
    onKChanged: cv.requestPaint()
}
