.pragma library
// Splits a combined exercise prompt like
//   "At a museum in Tijuana, a guide says: Hola, me llamo Rosa. Reply: say nice to meet you and give your name."
// into { scene, who, line, spanish, task } so it can be laid out on separate lines.
// Returns null when the prompt isn't a "someone says/asks: …" prompt.

var SPANISH_START = ["me", "te", "fui", "podemos", "no", "lo", "mucho", "hola", "oye", "sí", "si", "soy", "estoy", "vivo",
    "tengo", "quiero", "nos", "es", "mi", "ya", "bueno", "claro", "buenas", "buenos", "perdón", "gracias", "adiós", "hasta",
    "qué", "cómo", "dónde", "cuándo", "cuánto", "vamos", "voy", "trabajo", "está", "hace", "hay", "eso", "entonces", "pues"]
var TASK_START = ["say", "tell", "answer", "choose", "ask", "reply", "react", "suggest", "you", "agree", "summarize",
    "then", "and", "respond", "give", "turn", "offer", "thank", "decline", "explain", "use", "write"]

function looksSpanish(sentence) {
    if (/[¿¡áéíóúñ]/i.test(sentence)) return true
    var w = sentence.trim().split(/[\s,]+/)[0].toLowerCase().replace(/[^a-záéíóúñ]/g, "")
    return SPANISH_START.indexOf(w) >= 0
}
function cap(s) { s = (s || "").trim(); return s ? s.charAt(0).toUpperCase() + s.slice(1) : s }

function split(prompt) {
    if (!prompt) return null
    var m = /^(.*?)\b(says|asks|texts|writes)( you)?:\s*(.+)$/i.exec(prompt)
    if (!m) return null
    var before = m[1].trim(), rest = m[4]
    // scene + who: "At a museum in Tijuana, a guide" / "At the mixer someone" / "Diego"
    var scene = "", who = before
    var sm = /^((?:at|in|on|during)\s[^,]+?)(?:,\s*|\s+)(the\s\w+|a\s\w+|an\s\w+|someone|your\s\w+|\w+)\s*$/i.exec(before)
    if (sm) { scene = sm[1]; who = sm[2] }
    // sentences after the colon: Spanish ones form the line, the rest is the task
    var parts = rest.match(/[^.?!]+[.?!]+|[^.?!]+$/g) || [rest]
    var line = [], task = [], inTask = false, spanish = false
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i].trim()
        if (!p) continue
        var first = p.split(/[\s,:]+/)[0].toLowerCase()
        if (!inTask && i > 0 && (TASK_START.indexOf(first) >= 0 || /^(reply|answer|respond)\s*:/i.test(p))) inTask = true
        if (!inTask && i > 0 && !looksSpanish(p) && looksSpanish(line.join(" "))) inTask = true
        if (inTask) task.push(p)
        else line.push(p)
    }
    var lineText = line.join(" ")
    spanish = looksSpanish(lineText)
    var t = task.join(" ")
    return { scene: cap(scene), who: cap(who), line: lineText, spanish: spanish, task: cap(t) }
}
