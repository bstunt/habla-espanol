import QtQuick

// Lucide stroke icon recolored at load time by the Python image provider.
Item {
    property string name: "house"
    property color color: Theme.text
    property int size: 20
    implicitWidth: size; implicitHeight: size
    width: size; height: size
    Accessible.ignored: true
    Image {
        anchors.fill: parent
        sourceSize.width: Math.ceil(parent.size * 2 * Math.max(1, Theme.uiScale)); sourceSize.height: Math.ceil(parent.size * 2 * Math.max(1, Theme.uiScale))
        source: "image://icon/" + parent.name + "/" + parent.color.toString().replace("#", "")
        smooth: true
        fillMode: Image.PreserveAspectFit
    }
}
