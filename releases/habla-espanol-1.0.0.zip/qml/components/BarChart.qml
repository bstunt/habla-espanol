import QtQuick
import QtQuick.Layouts

// Vertical bars with labels underneath. model: [{label, value, today?}]
Item {
    id: bc
    property var model: []
    property color color: Theme.blue
    property string unit: ""
    property string emptyText: "Nothing yet"
    readonly property real maxV: { var m = 0; for (var i = 0; i < model.length; i++) m = Math.max(m, model[i].value); return m }
    implicitHeight: 190
    Text { anchors.centerIn: parent; visible: bc.maxV === 0; text: bc.emptyText; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }
    Row {
        id: bars
        anchors { left: parent.left; right: parent.right; top: parent.top; bottom: parent.bottom; bottomMargin: 22 }
        spacing: Math.max(3, width / Math.max(1, bc.model.length) * 0.25)
        Repeater {
            model: bc.model
            delegate: Item {
                required property var modelData
                width: (bars.width - bars.spacing * (bc.model.length - 1)) / Math.max(1, bc.model.length)
                height: bars.height
                Rectangle {
                    anchors.bottom: parent.bottom; width: parent.width
                    height: bc.maxV > 0 ? Math.max(modelData.value > 0 ? 3 : 0, (parent.height - 18) * modelData.value / bc.maxV) : 0
                    radius: Math.min(6, width / 3)
                    color: modelData.today ? Qt.lighter(bc.color, 1.25) : bc.color
                    opacity: modelData.value > 0 ? 1 : 0.25
                    Behavior on height { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                }
                Text {
                    visible: modelData.value > 0 && bc.maxV > 0
                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: (parent.height - 18) * modelData.value / Math.max(1, bc.maxV) + 3 }
                    text: Math.round(modelData.value) + bc.unit; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 11
                }
                Text {
                    anchors { horizontalCenter: parent.horizontalCenter; top: parent.bottom; topMargin: 5 }
                    text: modelData.label; color: modelData.today ? Theme.text : Theme.text3; font.family: Theme.sans; font.pixelSize: 11
                    font.weight: modelData.today ? Font.DemiBold : Font.Normal
                }
                Accessible.role: Accessible.StaticText; Accessible.name: modelData.label + ": " + modelData.value + bc.unit
            }
        }
    }
}
