import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts

// Answer option. state: "" | "correct" | "wrong" | "dim"
Button {
    id: o
    property string result: ""
    property string keyHint: ""
    property bool spanish: false
    implicitHeight: Math.max(52, lbl.implicitHeight + 26)
    focusPolicy: Qt.StrongFocus
    Accessible.name: text
    contentItem: RowLayout {
        spacing: 12
        Rectangle {
            visible: o.keyHint !== ""
            width: 24; height: 24; radius: 6; color: Qt.rgba(1, 1, 1, 0.08); border.color: Theme.border
            Text { anchors.centerIn: parent; text: o.keyHint; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12 }
        }
        Text {
            id: lbl
            text: o.text; color: o.result === "dim" ? Theme.text3 : Theme.text
            font.family: o.spanish ? Theme.serif : Theme.sans; font.pixelSize: o.spanish ? 18 : 16
            wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        Icon { visible: o.result === "correct" || o.result === "wrong"; name: o.result === "correct" ? "circle-check" : "circle-alert"
               color: o.result === "correct" ? Theme.green : Theme.coral; size: 20 }
    }
    background: Rectangle {
        radius: 12
        color: o.result === "correct" ? Qt.rgba(0.2, 0.66, 0.46, 0.18)
             : o.result === "wrong" ? Qt.rgba(0.91, 0.36, 0.46, 0.16)
             : (o.hovered && o.enabled ? Theme.rowHover : Qt.rgba(1, 1, 1, 0.035))
        border.color: o.visualFocus ? Theme.blue
             : o.result === "correct" ? Theme.green : o.result === "wrong" ? Theme.coral : Theme.border
        border.width: o.visualFocus || o.result === "correct" || o.result === "wrong" ? 2 : 1
    }
}
