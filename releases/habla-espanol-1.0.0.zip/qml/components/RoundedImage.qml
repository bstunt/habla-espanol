import QtQuick

// Image cropped + rounded by the Python "rounded" image provider.
// (Qt's clip ignores radius; shader masks need GPU backends.)
Item {
    id: r
    property string source            // path relative to assets/
    property real radius: Theme.radius
    readonly property real dpr: (Screen.devicePixelRatio > 0 ? Screen.devicePixelRatio : 1) * Math.max(1, Theme.uiScale)
    Image {
        anchors.fill: parent
        visible: r.width > 0 && r.height > 0
        sourceSize.width: Math.round(r.width * r.dpr)
        sourceSize.height: Math.round(r.height * r.dpr)
        source: r.width > 0 ? "image://rounded/" + r.source + "?r=" + (r.radius * r.dpr) : ""
        cache: false
        asynchronous: true
        Accessible.ignored: true
    }
}
