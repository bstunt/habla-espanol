import QtQuick
import QtQuick.Window

// Pie (hole: 0) or donut chart. segments: [{label, value, color}]
Item {
    id: dn
    property var segments: []
    property real hole: 0.58            // 0 = pie
    property string centerText: ""
    property string centerSub: ""
    readonly property real total: { var t = 0; for (var i = 0; i < segments.length; i++) t += segments[i].value; return t }
    readonly property real k: Math.max(1, Theme.uiScale * (Screen.devicePixelRatio || 1))
    implicitWidth: 170; implicitHeight: 170
    Accessible.role: Accessible.Chart
    Accessible.name: { var s = []; for (var i = 0; i < segments.length; i++) s.push(segments[i].label + " " + segments[i].value); return s.join(", ") }
    Canvas {
        id: cv
        width: dn.width * dn.k; height: dn.height * dn.k
        scale: 1 / dn.k; transformOrigin: Item.TopLeft
        onPaint: {
            var ctx = getContext("2d"); ctx.reset(); ctx.scale(dn.k, dn.k)
            var w = dn.width, h = dn.height, cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 2
            if (dn.total <= 0) {
                ctx.strokeStyle = Qt.rgba(1, 1, 1, 0.12); ctx.lineWidth = r * (1 - dn.hole) || 10
                ctx.beginPath(); ctx.arc(cx, cy, dn.hole > 0 ? r * (1 + dn.hole) / 2 : r / 2, 0, Math.PI * 2); ctx.stroke(); return
            }
            var a = -Math.PI / 2
            for (var i = 0; i < dn.segments.length; i++) {
                var v = dn.segments[i].value; if (v <= 0) continue
                var b = a + Math.PI * 2 * v / dn.total
                ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, a, b); ctx.closePath()
                ctx.fillStyle = dn.segments[i].color; ctx.fill()
                // thin gap between slices
                ctx.strokeStyle = Theme.card; ctx.lineWidth = 2; ctx.stroke()
                a = b
            }
            if (dn.hole > 0) {
                ctx.globalCompositeOperation = "destination-out"
                ctx.beginPath(); ctx.arc(cx, cy, r * dn.hole, 0, Math.PI * 2); ctx.fill()
                ctx.globalCompositeOperation = "source-over"
            }
        }
    }
    Column {
        anchors.centerIn: parent; visible: dn.hole > 0
        Text { anchors.horizontalCenter: parent.horizontalCenter; text: dn.centerText; color: Theme.text; font.family: Theme.serif; font.pixelSize: 26 }
        Text { anchors.horizontalCenter: parent.horizontalCenter; text: dn.centerSub; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
    }
    onSegmentsChanged: cv.requestPaint()
    onWidthChanged: cv.requestPaint()
    onKChanged: cv.requestPaint()
    Connections { target: Theme; function onThemeNameChanged() { cv.requestPaint() } }
}
