import QtQuick
import QtQuick.Controls.Basic

ToolButton {
    id: b
    property string iconName
    property color iconColor: Theme.text2
    property int iconSize: 20
    property string label
    implicitWidth: 38; implicitHeight: 38
    focusPolicy: Qt.StrongFocus
    Accessible.name: label
    ToolTip.visible: hovered && label !== ""
    ToolTip.text: label
    ToolTip.delay: 600
    contentItem: Item { Icon { anchors.centerIn: parent; name: b.iconName; color: b.iconColor; size: b.iconSize } }
    background: Rectangle {
        radius: width / 2
        color: b.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
        border.color: Theme.blue; border.width: b.visualFocus ? 2 : 0
    }
}
