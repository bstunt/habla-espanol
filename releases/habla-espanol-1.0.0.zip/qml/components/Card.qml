import QtQuick

// Rounded card with a soft top-light gradient and hairline border.
Rectangle {
    id: root
    property bool elevated: false
    radius: Theme.radius
    border.color: Theme.borderSoft
    border.width: 1
    gradient: Gradient {
        GradientStop { position: 0.0; color: root.elevated ? Theme.cardElevated : Qt.lighter(Theme.card, 1.08) }
        GradientStop { position: 1.0; color: Theme.card }
    }
}
