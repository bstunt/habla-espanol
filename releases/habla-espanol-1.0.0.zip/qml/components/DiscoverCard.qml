import QtQuick
import QtQuick.Layouts

// Home carousel: a random Spanish word (with meaning and example) or a fact about
// Mexican culture. Changes every 15 seconds; arrows to browse; pauses on hover.
Item {
    id: dc
    readonly property var items: app.discover || []
    property int idx: 0
    readonly property var cur: items.length ? items[idx % items.length] : ({ kind: "fact", text: "" })
    Accessible.role: Accessible.Grouping
    Accessible.name: cur.kind === "word" ? "Word: " + cur.es + ", " + cur.en : "Did you know: " + (cur.text || "")

    TalaveraCorner { anchors.fill: parent }

    function go(step) {
        if (!items.length) return
        fade.stop(); body.opacity = 0
        idx = (idx + step + items.length) % items.length
        fade.start()
    }
    NumberAnimation { id: fade; target: body; property: "opacity"; from: 0; to: 1; duration: 350; easing.type: Easing.OutCubic }
    Timer { interval: 15000; running: dc.items.length > 1 && !hover.hovered; repeat: true; onTriggered: dc.go(1) }
    HoverHandler { id: hover }

    ColumnLayout {
        anchors { left: parent.left; top: parent.top; bottom: parent.bottom; leftMargin: 22; topMargin: 20; bottomMargin: 14 }
        width: parent.width * 0.62
        spacing: 8
        Text {
            text: dc.cur.kind === "word" ? "Palabra" : "¿Sabías que…?"
            color: Theme.tile; font.family: Theme.serif; font.italic: true; font.pixelSize: 15; font.weight: Font.DemiBold
        }
        ColumnLayout {
            id: body
            spacing: 4
            Layout.fillWidth: true; Layout.fillHeight: true
            // word
            RowLayout {
                visible: dc.cur.kind === "word"
                spacing: 8
                Text { text: dc.cur.es || ""; color: Theme.ink; font.family: Theme.serif; font.pixelSize: 25; font.weight: Font.DemiBold; wrapMode: Text.WordWrap; Layout.maximumWidth: body.width - 40 }
                SayButton { phrase: dc.cur.kind === "word" ? dc.cur.es : ""; size: 28 }
            }
            Text { visible: dc.cur.kind === "word"; text: dc.cur.en || ""; color: Theme.ink2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Text { visible: dc.cur.kind === "word" && !!dc.cur.example; text: dc.cur.example || ""; color: Theme.ink; font.family: Theme.serif; font.italic: true; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true; Layout.topMargin: 6 }
            Text { visible: dc.cur.kind === "word" && !!dc.cur.exampleEn; text: dc.cur.exampleEn || ""; color: Theme.ink2; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            // fact
            Text { visible: dc.cur.kind === "fact"; text: dc.cur.text || ""; color: Theme.ink; font.family: Theme.serif; font.pixelSize: 15; lineHeight: 1.2; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Item { Layout.fillHeight: true }
        }
        RowLayout {
            spacing: 6
            Repeater {
                model: [["‹", -1, "Previous"], ["›", 1, "Next"]]
                delegate: Rectangle {
                    required property var modelData
                    width: 26; height: 26; radius: 13
                    color: ma.containsMouse ? Qt.rgba(0, 0, 0, 0.08) : "transparent"; border.color: Qt.rgba(0, 0, 0, 0.18)
                    Text { anchors.centerIn: parent; anchors.verticalCenterOffset: -1; text: modelData[0]; color: Theme.ink2; font.pixelSize: 18 }
                    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: dc.go(modelData[1]) }
                    Accessible.role: Accessible.Button; Accessible.name: modelData[2]
                }
            }
        }
    }
}
