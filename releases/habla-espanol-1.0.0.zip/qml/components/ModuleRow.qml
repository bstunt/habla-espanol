import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts

// One of the seven session modules. status: not_started | in_progress |
// completed | needs_review | evidence_unavailable
ItemDelegate {
    id: r
    property int number
    property string title
    property string desc
    property int minutes
    property string iconName
    property string status: "not_started"
    property bool current: false
    implicitHeight: 58
    focusPolicy: Qt.StrongFocus
    Accessible.name: number + ". " + title + ", " + minutes + " minutes, " + statusLabel
    readonly property string statusLabel: ({
        "not_started": "not started", "in_progress": "in progress", "completed": "completed",
        "needs_review": "needs review", "evidence_unavailable": "no evidence available" })[status] || status
    background: Rectangle {
        radius: 12
        color: r.current ? Theme.navActive : (r.hovered ? Theme.rowHover : Qt.rgba(1, 1, 1, 0.025))
        border.color: r.visualFocus ? Theme.blue : (r.current ? Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.5) : Theme.borderSoft)
        border.width: r.visualFocus ? 2 : 1
        Rectangle { visible: r.current; width: 4; radius: 2; color: Theme.blue; anchors { left: parent.left; top: parent.top; bottom: parent.bottom; topMargin: 8; bottomMargin: 8 } }
    }
    contentItem: RowLayout {
        spacing: 14
        // number badge reflects status
        Rectangle {
            width: 26; height: 26; radius: 13
            color: r.status === "completed" ? Theme.green : (r.current ? Theme.blue : Qt.rgba(1, 1, 1, 0.1))
            border.color: r.status === "needs_review" ? Theme.amber : "transparent"; border.width: 2
            Text { anchors.centerIn: parent; text: r.status === "completed" ? "✓" : r.number; color: r.current && r.status !== "completed" ? Theme.onBlue : Theme.text; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.Bold }
        }
        Icon { name: r.iconName; color: Theme.text2; size: 22 }
        ColumnLayout {
            spacing: 2; Layout.fillWidth: true
            Text { text: r.title; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.Medium; elide: Text.ElideRight; Layout.fillWidth: true }
            Text {
                text: r.status === "in_progress" && !r.current ? "In progress · " + r.desc : (r.status === "needs_review" ? "Needs review · " + r.desc : r.desc)
                color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true
            }
        }
        Text { text: r.minutes + " min"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
        Icon { name: "chevron-right"; color: Theme.text2; size: 18 }
    }
}
