pragma Singleton
import QtQuick

// Design tokens. Every color/size in the UI comes from here.
QtObject {
    // ---------- color themes (Settings › Theme) ----------
    // Each theme is named for a color of Mexico. "coral" is the primary accent
    // (buttons), "blue" the secondary (progress, links, focus); names kept so
    // every screen follows the chosen theme.
    property string themeName: "talavera"
    readonly property var themes: ({
        talavera: { label: "Talavera", es: "azul talavera",
            bg: "#0B1728", bgTop: "#0E1C30", sidebar: "#091523", card: "#102238", cardElevated: "#172A40",
            rowHover: "#1B3048", border: "#294058", borderSoft: "#1D3249", navActive: "#1F4573",
            primary: "#E85D75", primaryDeep: "#C9475F", onPrimary: "#FFFFFF",
            secondary: "#3498F5", secondaryDeep: "#1E5FA8", onSecondary: "#FFFFFF",
            spanish: "#FFB199", heroA: "#0D2140", heroB: "#1B4F8C", pattern: "#9CC8FF",
            paper: "#F6EBDD", tile: "#1E5FA8", tile2: "#E8A33B",
            flags: ["#E85D75", "#F0A04B", "#3498F5", "#34A875", "#F6D365"] },
        jacaranda: { label: "Jacaranda", es: "jacaranda",
            bg: "#120E22", bgTop: "#17112B", sidebar: "#0E0A1B", card: "#1A1431", cardElevated: "#231B40",
            rowHover: "#2A214C", border: "#3C3163", borderSoft: "#282045", navActive: "#3A2A6E",
            primary: "#D9558C", primaryDeep: "#B83E72", onPrimary: "#FFFFFF",
            secondary: "#9B7BF0", secondaryDeep: "#6B4CC4", onSecondary: "#FFFFFF",
            spanish: "#F5B3D3", heroA: "#1E1540", heroB: "#5A3AA6", pattern: "#D7C6FF",
            paper: "#F3E9F4", tile: "#6B4CC4", tile2: "#D9558C",
            flags: ["#D9558C", "#9B7BF0", "#F5B3D3", "#7FD1C7", "#F6D365"] },
        nopal: { label: "Nopal", es: "verde nopal",
            bg: "#0B1915", bgTop: "#0E1F1A", sidebar: "#081410", card: "#11241E", cardElevated: "#182F27",
            rowHover: "#1E382F", border: "#2B4A3F", borderSoft: "#1D342B", navActive: "#1D4A3A",
            primary: "#E9A93B", primaryDeep: "#C98B22", onPrimary: "#1F1606",
            secondary: "#3FBF86", secondaryDeep: "#2A8C61", onSecondary: "#06231A",
            spanish: "#F6D58E", heroA: "#0E2A21", heroB: "#24714F", pattern: "#BDEBD2",
            paper: "#F2ECD6", tile: "#2A8C61", tile2: "#E9A93B",
            flags: ["#E9A93B", "#3FBF86", "#E8604C", "#F6D365", "#7FC8E8"] },
        cempasuchil: { label: "Cempasúchil", es: "flor de cempasúchil",
            bg: "#17110D", bgTop: "#1D1510", sidebar: "#120D09", card: "#211812", cardElevated: "#2A1F17",
            rowHover: "#33261B", border: "#4A3828", borderSoft: "#33271C", navActive: "#4D2C1A",
            primary: "#F28C28", primaryDeep: "#D47216", onPrimary: "#1E1206",
            secondary: "#E0457B", secondaryDeep: "#B02F60", onSecondary: "#FFFFFF",
            spanish: "#FFC58A", heroA: "#2A160C", heroB: "#8C3F12", pattern: "#FFD9A8",
            paper: "#FBEBD2", tile: "#B02F60", tile2: "#F28C28",
            flags: ["#F28C28", "#E0457B", "#F6D365", "#8E5BD9", "#3FBF86"] },
        rosa: { label: "Rosa mexicano", es: "rosa mexicano",
            bg: "#0D191C", bgTop: "#102024", sidebar: "#091417", card: "#122428", cardElevated: "#192E33",
            rowHover: "#1F383E", border: "#2D4B52", borderSoft: "#1E353A", navActive: "#174548",
            primary: "#E4007C", primaryDeep: "#B80064", onPrimary: "#FFFFFF",
            secondary: "#22B8B0", secondaryDeep: "#168A84", onSecondary: "#04211F",
            spanish: "#FF9CCB", heroA: "#0D2C30", heroB: "#127A76", pattern: "#9FEBE5",
            paper: "#FCE9F1", tile: "#E4007C", tile2: "#22B8B0",
            flags: ["#E4007C", "#22B8B0", "#F6D365", "#F28C28", "#8E5BD9"] }
    })
    readonly property var themeOrder: ["talavera", "jacaranda", "nopal", "cempasuchil", "rosa"]
    readonly property var t: themes[themeName] || themes.talavera

    // surfaces
    readonly property color bg: t.bg
    readonly property color bgTop: t.bgTop
    readonly property color sidebar: t.sidebar
    readonly property color card: t.card
    readonly property color cardElevated: t.cardElevated
    readonly property color rowHover: t.rowHover
    readonly property color border: t.border
    readonly property color borderSoft: t.borderSoft

    // accents
    readonly property color blue: t.secondary
    readonly property color blueDeep: t.secondaryDeep
    readonly property color onBlue: t.onSecondary
    readonly property color navActive: t.navActive
    readonly property color coral: t.primary
    readonly property color coralDeep: t.primaryDeep
    readonly property color onCoral: t.onPrimary
    readonly property color danger: "#EF6B7F"         // errors stay red-pink in every theme
    readonly property color green: "#34A875"
    readonly property color amber: "#F0A04B"
    readonly property color teal: "#1FA3B5"
    readonly property color spanishAccent: t.spanish   // Spanish words in the UI chrome

    // decorative art
    readonly property color heroA: t.heroA
    readonly property color heroB: t.heroB
    readonly property color pattern: t.pattern
    readonly property color paper: t.paper
    readonly property color tile: t.tile
    readonly property color tile2: t.tile2
    readonly property var flags: t.flags

    // text
    readonly property color text: "#F8FAFC"
    readonly property color text2: "#A9B8CA"
    readonly property color text3: "#7D8FA6"
    readonly property color ink: "#3A2A26"      // dark text on the cream card
    readonly property color ink2: "#6B5A52"

    // radii + spacing
    // set by Main.qml: window size / design size; used to rasterize images sharply
    property real uiScale: 1.0

    readonly property int radius: 16
    readonly property int radiusSm: 10
    readonly property int gap: 14
    readonly property int pad: 20

    // type
    readonly property string sans: "Inter"
    readonly property string serif: "Lora"
    readonly property string script: "Kaushan Script"

    readonly property int fsXs: 12
    readonly property int fsSm: 13
    readonly property int fsMd: 15
    readonly property int fsLg: 18
    readonly property int fsXl: 22
}
