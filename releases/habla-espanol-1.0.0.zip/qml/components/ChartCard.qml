import QtQuick
import QtQuick.Layouts

// A titled card that holds one chart.
Card {
    id: cc
    property string title
    property string note: ""
    default property alias content: inner.data
    Layout.fillWidth: true
    Layout.fillHeight: true              // cards in a row share top and bottom edges
    Layout.alignment: Qt.AlignTop
    implicitHeight: col.implicitHeight + 40
    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
        spacing: 12
        ColumnLayout { spacing: 2; Layout.fillWidth: true
            Text { text: cc.title; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold }
            Text { visible: cc.note !== ""; text: cc.note; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
        ColumnLayout { id: inner; Layout.fillWidth: true; spacing: 10 }
    }
}
