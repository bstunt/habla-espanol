import QtQuick
import QtQuick.Controls.Basic

// Speaker button: plays a Spanish line (recorded reference or the Mac's voice).
ToolButton {
    id: b
    property string phrase: ""
    property bool slow: false
    property int size: 34
    property color tint: Theme.blue
    implicitWidth: size; implicitHeight: size
    focusPolicy: Qt.StrongFocus
    Accessible.name: (slow ? "Play slowly: " : "Play: ") + phrase
    onClicked: app.say(phrase, slow)
    contentItem: Item { Icon { anchors.centerIn: parent; name: b.slow ? "snail" : "volume-2"; color: b.tint === Theme.blue ? Theme.onBlue : Theme.text; size: Math.round(b.size * 0.5) } }
    background: Rectangle {
        radius: width / 2
        color: b.down ? Qt.darker(b.tint, 1.2) : (b.hovered ? Qt.lighter(b.tint, 1.1) : b.tint)
        border.color: "white"; border.width: b.visualFocus ? 2 : 0
    }
}
