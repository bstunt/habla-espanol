import QtQuick
import QtQuick.Controls.Basic

// Themed checkbox: box and label vertically centered, consistent spacing.
CheckBox {
    id: cb
    spacing: 10
    padding: 0
    implicitHeight: 28
    indicator: Rectangle {
        implicitWidth: 20; implicitHeight: 20
        x: cb.leftPadding; y: (cb.height - height) / 2
        radius: 5
        color: cb.checked ? Theme.blue : Qt.rgba(1, 1, 1, 0.05)
        border.color: cb.visualFocus ? Theme.text : (cb.checked ? Theme.blue : Theme.border)
        border.width: cb.visualFocus ? 2 : 1
        Text { anchors.centerIn: parent; visible: cb.checked; text: "✓"; color: Theme.text; font.pixelSize: 13; font.weight: Font.Bold }
    }
    contentItem: Text {
        text: cb.text
        leftPadding: cb.indicator.width + cb.spacing
        verticalAlignment: Text.AlignVCenter
        color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14
        wrapMode: Text.WordWrap
    }
}
