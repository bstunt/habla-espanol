import QtQuick

// Sidebar footer: serape-style stripes in the theme's colors, fading up into the sidebar.
Item {
    id: root
    Accessible.ignored: true
    clip: true
    // a serape repeat: wide color bands separated by thin pinstripes
    readonly property var stripes: [
        [22, Theme.flags[0]], [3, Theme.paper], [3, Theme.flags[4]], [3, Theme.paper],
        [16, Theme.heroB], [5, Theme.flags[1]], [16, Theme.heroB],
        [3, Theme.paper], [3, Theme.flags[3]], [3, Theme.paper],
        [22, Theme.flags[2]], [6, Theme.heroA], [12, Theme.flags[4]], [6, Theme.heroA]]
    Column {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        Repeater {
            model: 4
            delegate: Column {
                width: parent.width
                Repeater {
                    model: root.stripes
                    delegate: Rectangle { required property var modelData; width: parent.width; height: modelData[0]; color: modelData[1] }
                }
            }
        }
    }
    // fade into the sidebar and keep it quiet
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: Theme.sidebar }
            GradientStop { position: 0.45; color: Qt.rgba(Theme.sidebar.r, Theme.sidebar.g, Theme.sidebar.b, 0.78) }
            GradientStop { position: 1.0; color: Qt.rgba(Theme.sidebar.r, Theme.sidebar.g, Theme.sidebar.b, 0.38) }
        }
    }
}
