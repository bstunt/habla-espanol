import QtQuick
import QtQuick.Window

// Hero background: a deep color field, a papel picado (cut-paper) pattern that
// fades in from the right, and a string of banderitas across the top right.
// Drawn in code so it follows the theme and stays sharp at any size.
Item {
    id: root
    property real radius: Theme.radius
    readonly property real k: Math.max(1, Theme.uiScale * (Screen.devicePixelRatio || 1))
    Accessible.ignored: true

    Canvas {
        id: cv
        width: root.width * root.k; height: root.height * root.k
        scale: 1 / root.k; transformOrigin: Item.TopLeft
        renderStrategy: Canvas.Cooperative
        onPaint: {
            var ctx = getContext("2d"); ctx.reset(); ctx.scale(root.k, root.k)
            var w = root.width, h = root.height, r = root.radius
            ctx.beginPath(); ctx.roundedRect(0, 0, w, h, r, r); ctx.clip()

            // field
            var g = ctx.createLinearGradient(0, 0, w, h)
            g.addColorStop(0, Qt.darker(Theme.heroA, 1.15)); g.addColorStop(0.55, Theme.heroA); g.addColorStop(1, Theme.heroB)
            ctx.fillStyle = g; ctx.fillRect(0, 0, w, h)

            // papel picado: repeating cut-out motifs, fading in toward the right
            var c = 54
            ctx.fillStyle = Theme.pattern
            for (var y = 0; y < h + c; y += c) {
                for (var x = 0; x < w + c; x += c) {
                    var f = (x / w - 0.38) / 0.5
                    if (f <= 0) continue
                    ctx.globalAlpha = Math.min(1, f) * 0.16
                    var cx = x + c / 2, cy = y + c / 2
                    // six-petal flower
                    for (var p = 0; p < 6; p++) {
                        var a = p * Math.PI / 3
                        ctx.beginPath(); ctx.ellipse(cx + Math.cos(a) * c * 0.17 - c * 0.08, cy + Math.sin(a) * c * 0.17 - c * 0.08, c * 0.16, c * 0.16); ctx.fill()
                    }
                    // diamond on the grid corner
                    ctx.beginPath(); ctx.moveTo(x, y - c * 0.1); ctx.lineTo(x + c * 0.1, y); ctx.lineTo(x, y + c * 0.1); ctx.lineTo(x - c * 0.1, y); ctx.closePath(); ctx.fill()
                    // small cut dots on the edges
                    ctx.beginPath(); ctx.ellipse(cx - 2, y - 2, 4, 4); ctx.fill()
                    ctx.beginPath(); ctx.ellipse(x - 2, cy - 2, 4, 4); ctx.fill()
                }
            }
            ctx.globalAlpha = 1

            // banderitas on a sagging string, right part only (the text lives on the left)
            var x0 = w * 0.44, x1 = w - 18, top = 10, sag = 20
            ctx.strokeStyle = Qt.rgba(1, 1, 1, 0.35); ctx.lineWidth = 1.2
            ctx.beginPath(); ctx.moveTo(x0, top); ctx.quadraticCurveTo((x0 + x1) / 2, top + sag * 2, x1, top); ctx.stroke()
            var n = Math.max(5, Math.floor((x1 - x0) / 40)), fw = 24, fh = 30
            for (var i = 0; i <= n; i++) {
                var t = i / n
                var px = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * ((x0 + x1) / 2) + t * t * x1
                var py = (1 - t) * (1 - t) * top + 2 * (1 - t) * t * (top + sag * 2) + t * t * top
                var ang = Math.atan2(2 * (1 - t) * (top + sag * 2 - top) + 2 * t * (top - (top + sag * 2)),
                                     2 * (1 - t) * ((x0 + x1) / 2 - x0) + 2 * t * (x1 - (x0 + x1) / 2))
                ctx.save(); ctx.translate(px, py); ctx.rotate(ang)
                ctx.globalAlpha = 0.9
                ctx.fillStyle = Theme.flags[i % Theme.flags.length]
                ctx.beginPath(); ctx.moveTo(-fw / 2, 0); ctx.lineTo(fw / 2, 0); ctx.lineTo(fw / 2, fh)
                ctx.lineTo(fw / 4, fh - 5); ctx.lineTo(0, fh); ctx.lineTo(-fw / 4, fh - 5); ctx.lineTo(-fw / 2, fh)
                ctx.closePath(); ctx.fill()
                // a tiny cut in each flag
                ctx.globalAlpha = 0.55; ctx.fillStyle = Theme.heroA
                ctx.beginPath(); ctx.ellipse(-4, fh * 0.38 - 4, 8, 8); ctx.fill()
                ctx.fillRect(-fw / 2 + 4, 5, fw - 8, 2)
                ctx.restore()
            }
            ctx.globalAlpha = 1
        }
    }
    onWidthChanged: cv.requestPaint()
    onHeightChanged: cv.requestPaint()
    onKChanged: cv.requestPaint()
    Connections { target: Theme; function onThemeNameChanged() { cv.requestPaint() } }
}
