import QtQuick
import QtQuick.Controls.Basic

// Primary (coral) or secondary (outlined navy) pill button.
Button {
    id: b
    property bool primary: true
    property string iconName: ""
    implicitHeight: 46
    implicitWidth: row.implicitWidth + 56
    focusPolicy: Qt.StrongFocus
    Accessible.name: text
    contentItem: Item {
      implicitWidth: row.implicitWidth
      Row {
        id: row
        spacing: 12
        anchors.centerIn: parent
        Icon { visible: b.iconName !== ""; name: b.iconName; color: b.primary ? Theme.onCoral : Theme.text; size: 18; anchors.verticalCenter: parent.verticalCenter }
        Text {
            text: b.text; color: b.primary ? Theme.onCoral : Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold
            anchors.verticalCenter: parent.verticalCenter
        }
      }
    }
    background: Rectangle {
        radius: height / 2
        color: b.primary ? (b.down ? Theme.coralDeep : (b.hovered ? Qt.lighter(Theme.coral, 1.08) : Theme.coral))
                         : (b.hovered ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(Theme.bg.r, Theme.bg.g, Theme.bg.b, 0.72))
        border.color: b.primary ? "transparent" : Qt.rgba(1, 1, 1, 0.32)
        border.width: 1
        Rectangle {   // keyboard focus ring
            anchors.fill: parent; anchors.margins: -4; radius: height / 2
            color: "transparent"; border.color: Theme.blue; border.width: 2; visible: b.visualFocus
        }
    }
}
