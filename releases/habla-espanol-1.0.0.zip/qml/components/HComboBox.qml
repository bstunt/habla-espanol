import QtQuick
import QtQuick.Controls.Basic

// Themed dropdown matching the dark UI (the default Basic style is light gray).
ComboBox {
    id: cbx
    implicitHeight: 42
    font.family: Theme.sans; font.pixelSize: 14
    background: Rectangle {
        radius: 10
        color: cbx.hovered ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(1, 1, 1, 0.05)
        border.color: cbx.visualFocus || cbx.popup.visible ? Theme.blue : Theme.border
    }
    contentItem: Text {
        leftPadding: 14; rightPadding: cbx.indicator.width + 10
        text: cbx.displayText
        color: Theme.text; font: cbx.font
        verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight
    }
    indicator: Text {
        x: cbx.width - width - 14; y: (cbx.height - height) / 2
        text: "▾"; color: Theme.text2; font.pixelSize: 14
    }
    delegate: ItemDelegate {
        id: dl
        required property var modelData
        required property int index
        width: cbx.width
        height: 38
        highlighted: cbx.highlightedIndex === index
        contentItem: Text {
            text: dl.modelData; color: Theme.text; font: cbx.font
            verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight; leftPadding: 4
        }
        background: Rectangle {
            radius: 6
            color: dl.highlighted ? Theme.navActive : (cbx.currentIndex === dl.index ? Qt.rgba(1, 1, 1, 0.06) : "transparent")
        }
    }
    popup: Popup {
        y: cbx.height + 4
        width: cbx.width
        implicitHeight: Math.min(contentItem.implicitHeight + 12, 320)
        padding: 6
        contentItem: ListView {
            clip: true
            implicitHeight: contentHeight
            model: cbx.popup.visible ? cbx.delegateModel : null
            currentIndex: cbx.highlightedIndex
            ScrollIndicator.vertical: ScrollIndicator {}
        }
        background: Rectangle { radius: 10; color: Theme.cardElevated; border.color: Theme.border }
    }
}
