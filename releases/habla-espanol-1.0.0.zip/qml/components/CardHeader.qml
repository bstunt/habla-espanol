import QtQuick
import QtQuick.Layouts

RowLayout {
    property string title
    property string icon: ""
    property color iconColor: Theme.coral
    property string trailing: ""
    property color trailingColor: Theme.blue
    signal trailingClicked()
    spacing: 10
    Icon { visible: icon !== ""; name: icon; color: iconColor; size: 20 }
    Text {
        text: title; color: Theme.text; font.family: Theme.sans; font.pixelSize: Theme.fsLg; font.weight: Font.DemiBold
        Layout.fillWidth: true; elide: Text.ElideRight
        Accessible.role: Accessible.Heading
    }
    Text {
        visible: trailing !== ""; text: trailing; color: trailingColor; font.family: Theme.sans; font.pixelSize: Theme.fsSm
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: trailingClicked() }
    }
}
