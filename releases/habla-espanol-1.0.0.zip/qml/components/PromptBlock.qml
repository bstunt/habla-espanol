import QtQuick
import QtQuick.Layouts
import "PromptParts.js" as PP

// Exercise prompt. "Someone says: <Spanish>. <task>" prompts are laid out as
// scene / speech bubble / your turn, so they're easy to read; others stay one line.
ColumnLayout {
    id: pb
    property string prompt: ""
    readonly property var parts: PP.split(prompt)
    spacing: 18

    Text {
        visible: !pb.parts
        text: pb.prompt; color: Theme.text; font.family: Theme.sans; font.pixelSize: 20; font.weight: Font.DemiBold
        wrapMode: Text.WordWrap; Layout.fillWidth: true
    }
    // the scene
    RowLayout {
        visible: !!pb.parts && pb.parts.scene !== ""
        spacing: 10
        Icon { name: "flag"; color: Theme.coral; size: 16 }
        Text { text: pb.parts ? pb.parts.scene : ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 16; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    }
    // what they say
    Rectangle {
        visible: !!pb.parts
        Layout.fillWidth: true
        implicitHeight: bubble.implicitHeight + 26
        radius: 14; color: Theme.cardElevated; border.color: Theme.borderSoft
        RowLayout {
            id: bubble
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 14 }
            spacing: 14
            SayButton { visible: !!pb.parts && pb.parts.spanish; phrase: pb.parts ? pb.parts.line : ""; size: 40 }
            ColumnLayout { spacing: 3; Layout.fillWidth: true
                Text { text: pb.parts ? pb.parts.who : ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                Text { text: pb.parts ? pb.parts.line : ""; color: Theme.text; font.family: pb.parts && pb.parts.spanish ? Theme.serif : Theme.sans
                       font.pixelSize: 22; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
        }
    }
    // your turn
    RowLayout {
        visible: !!pb.parts && pb.parts.task !== ""
        spacing: 10
        Layout.topMargin: 2
        Layout.bottomMargin: 6
        Text { text: "Your turn"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; Layout.alignment: Qt.AlignBaseline }
        Text { text: pb.parts ? pb.parts.task : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold; wrapMode: Text.WordWrap; Layout.fillWidth: true; Layout.alignment: Qt.AlignBaseline }
    }
}
