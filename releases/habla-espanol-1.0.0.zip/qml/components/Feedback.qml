import QtQuick
import QtQuick.Layouts

// Explains what happened: never just red/green.
Rectangle {
    id: f
    property bool good: true
    property string title: ""
    property string body: ""
    property string spanish: ""
    visible: title !== ""
    implicitHeight: col.implicitHeight + 28
    radius: 12
    color: good ? Qt.rgba(0.2, 0.66, 0.46, 0.12) : Qt.rgba(0.94, 0.63, 0.29, 0.12)
    border.color: good ? Qt.rgba(0.2, 0.66, 0.46, 0.45) : Qt.rgba(0.94, 0.63, 0.29, 0.5)
    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
        spacing: 6
        RowLayout {
            spacing: 10
            Icon { name: f.good ? "circle-check" : "circle-alert"; color: f.good ? Theme.green : Theme.amber; size: 20 }
            Text { text: f.title; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; Layout.fillWidth: true; wrapMode: Text.WordWrap }
        }
        RowLayout {
            visible: f.spanish !== ""
            spacing: 10
            SayButton { phrase: f.spanish; size: 30 }
            Text { text: f.spanish; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19; Layout.fillWidth: true; wrapMode: Text.WordWrap }
        }
        Text { visible: f.body !== ""; text: f.body; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true; textFormat: Text.StyledText }
    }
}
