import QtQuick
import QtQuick.Controls.Basic

// Sidebar item. Shows the English label; on hover (or keyboard focus) it
// crossfades to the Spanish word, a small vocabulary moment on every visit.
ItemDelegate {
    id: d
    property string iconName
    property string spanish: ""
    property bool active: false
    readonly property bool showSpanish: spanish !== "" && (hovered || visualFocus)
    height: 48
    focusPolicy: Qt.StrongFocus
    hoverEnabled: true
    Accessible.name: spanish !== "" ? text + " (in Spanish: " + spanish + ")" : text
    Accessible.role: Accessible.PageTab
    Accessible.selected: active
    contentItem: Row {
        spacing: 18
        leftPadding: 8
        Icon { name: d.iconName; color: d.active || d.showSpanish ? Theme.text : Theme.text2; size: 22; anchors.verticalCenter: parent.verticalCenter }
        Item {
            width: Math.max(en.implicitWidth, es.implicitWidth); height: en.implicitHeight
            anchors.verticalCenter: parent.verticalCenter
            Text {
                id: en
                text: d.text; color: d.active ? Theme.text : Theme.text2
                font.family: Theme.sans; font.pixelSize: 16; font.weight: d.active ? Font.DemiBold : Font.Normal
                opacity: d.showSpanish ? 0 : 1
                y: d.showSpanish ? -6 : 0
                Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            }
            Text {
                id: es
                text: d.spanish; color: Theme.spanishAccent
                font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold
                opacity: d.showSpanish ? 1 : 0
                y: d.showSpanish ? 0 : 6
                Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            }
        }
    }
    background: Rectangle {
        radius: 12
        color: d.active ? Theme.navActive : (d.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent")
        border.color: d.visualFocus ? Theme.blue : (d.active ? Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.35) : "transparent")
        border.width: d.visualFocus ? 2 : 1
    }
}
