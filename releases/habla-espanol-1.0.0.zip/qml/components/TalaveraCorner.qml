import QtQuick
import QtQuick.Window

// Paper card with a small cluster of Talavera tiles bleeding off the right edge.
Item {
    id: root
    property real radius: Theme.radius
    readonly property real k: Math.max(1, Theme.uiScale * (Screen.devicePixelRatio || 1))
    Accessible.ignored: true

    Canvas {
        id: cv
        width: root.width * root.k; height: root.height * root.k
        scale: 1 / root.k; transformOrigin: Item.TopLeft
        renderStrategy: Canvas.Cooperative
        onPaint: {
            var ctx = getContext("2d"); ctx.reset(); ctx.scale(root.k, root.k)
            var w = root.width, h = root.height, r = root.radius
            ctx.beginPath(); ctx.roundedRect(0, 0, w, h, r, r); ctx.clip()
            ctx.fillStyle = Theme.paper; ctx.fillRect(0, 0, w, h)

            var s = Math.min(64, h * 0.34)              // tile size
            var cols = 2, rows = Math.ceil(h / s) + 1
            for (var row = 0; row < rows; row++) {
                for (var col = 0; col < cols; col++) {
                    var x = w - s * (cols - col) + s * 0.35, y = row * s - s * 0.3
                    // fade tiles toward the text side and the top
                    ctx.globalAlpha = (col === 0 ? 0.38 : 0.75) * Math.min(1, 0.3 + row * 0.25)
                    tile(ctx, x, y, s)
                }
            }
            ctx.globalAlpha = 1
        }
        function tile(ctx, x, y, s) {
            var c = Theme.tile, c2 = Theme.tile2, cx = x + s / 2, cy = y + s / 2
            ctx.strokeStyle = c; ctx.lineWidth = 1.2
            ctx.strokeRect(x + 0.5, y + 0.5, s - 1, s - 1)
            // corner quarter circles (they form circles where four tiles meet)
            ctx.fillStyle = c
            var q = s * 0.2
            ctx.beginPath(); ctx.moveTo(x, y); ctx.arc(x, y, q, 0, Math.PI / 2); ctx.fill()
            ctx.beginPath(); ctx.moveTo(x + s, y); ctx.arc(x + s, y, q, Math.PI / 2, Math.PI); ctx.fill()
            ctx.beginPath(); ctx.moveTo(x, y + s); ctx.arc(x, y + s, q, -Math.PI / 2, 0); ctx.fill()
            ctx.beginPath(); ctx.moveTo(x + s, y + s); ctx.arc(x + s, y + s, q, Math.PI, Math.PI * 1.5); ctx.fill()
            // quatrefoil
            var p = s * 0.15
            ctx.beginPath()
            ctx.ellipse(cx - p - p * 0.5, cy - p, p * 2, p * 2)
            ctx.ellipse(cx + p * 0.5 - p, cy - p, p * 2, p * 2)
            ctx.ellipse(cx - p, cy - p - p * 0.5, p * 2, p * 2)
            ctx.ellipse(cx - p, cy + p * 0.5 - p, p * 2, p * 2)
            ctx.fill()
            // center
            ctx.fillStyle = c2
            ctx.beginPath(); ctx.ellipse(cx - s * 0.07, cy - s * 0.07, s * 0.14, s * 0.14); ctx.fill()
            ctx.fillStyle = Theme.paper
            ctx.beginPath(); ctx.ellipse(cx - s * 0.025, cy - s * 0.025, s * 0.05, s * 0.05); ctx.fill()
        }
    }
    onWidthChanged: cv.requestPaint()
    onHeightChanged: cv.requestPaint()
    onKChanged: cv.requestPaint()
    Connections { target: Theme; function onThemeNameChanged() { cv.requestPaint() } }
}
