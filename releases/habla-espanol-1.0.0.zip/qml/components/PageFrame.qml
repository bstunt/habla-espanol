import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts

// Standard section page: heading, Spanish subtitle, scrolling content.
Flickable {
    id: pf
    property string title
    property string titleEs
    property string subtitle
    default property alias content: body.data
    contentWidth: width
    contentHeight: col.implicitHeight + 60
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    ScrollBar.vertical: ScrollBar { policy: pf.contentHeight > pf.height ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }
    ColumnLayout {
        id: col
        x: 32; y: 30
        width: pf.width - 64
        spacing: 20
        ColumnLayout {
            spacing: 4
            RowLayout {
                spacing: 14
                Text { text: pf.title; color: Theme.text; font.family: Theme.serif; font.pixelSize: 36; Accessible.role: Accessible.Heading }
                Text { visible: pf.titleEs !== ""; text: pf.titleEs; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 22; Layout.alignment: Qt.AlignBaseline }
            }
            Text { visible: pf.subtitle !== ""; text: pf.subtitle; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        }
        ColumnLayout { id: body; spacing: 16; Layout.fillWidth: true }
    }
}
