import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Window
import QtQuick.Layouts
import "components"
import "screens"

ApplicationWindow {
    id: win
    // Opens at 1280 wide (1536x1024 design at 5/6). The whole interface scales
    // with the window, so maximized/full screen fills the display.
    width: 1280; height: 853
    minimumWidth: 960; minimumHeight: 640
    visible: true
    title: "Habla Español"
    color: Theme.bg

    property string section: "inicio"
    Connections { target: app; function onSectionRequested(k) { win.section = k } }

    // Design canvas. Fits the limiting dimension exactly; the other dimension
    // gets extra room (layouts stretch/center), so there are never letterbox bars.
    readonly property real designW: 1536
    readonly property real designH: 1024
    readonly property real uiScale: Math.min(width / designW, height / designH)
    Binding { target: Theme; property: "uiScale"; value: win.uiScale }
    Binding { target: Theme; property: "themeName"; value: app.themeName }

    Rectangle {   // full-window background behind the scaled stage
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: Theme.bgTop }
            GradientStop { position: 1; color: Theme.bg }
        }
    }

    Item {
      id: stage
      width: win.width / win.uiScale
      height: win.height / win.uiScale
      scale: win.uiScale
      transformOrigin: Item.TopLeft

    // dashboard shell: sidebar + content
    Item {
        id: shell
        anchors.fill: parent
        opacity: app.screen === "dashboard" ? 1 : 0
        onVisibleChanged: if (visible) app.refreshLibrary()
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }

        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0; color: Theme.bgTop }
                GradientStop { position: 1; color: Theme.bg }
            }
        }
        Sidebar {
            id: sidebar
            width: 258
            anchors { top: parent.top; bottom: parent.bottom; left: parent.left }
            current: win.section === "boleta" ? "progreso" : win.section
            onNavigate: (key) => win.section = key
        }
        Item {
            anchors { left: sidebar.right; right: parent.right; top: parent.top; bottom: parent.bottom }
            // top-right utilities
            Row {
                z: 2
                anchors { right: parent.right; top: parent.top; rightMargin: 24; topMargin: 14 }
                spacing: 8
                IconButton { iconName: "search"; label: "Search"; iconColor: Theme.text }
                IconButton { iconName: "bell"; label: "Review alerts"; iconColor: Theme.text }
                Rectangle {
                    width: 38; height: 38; radius: 19; color: Theme.cardElevated; border.color: Theme.border
                    Text { anchors.centerIn: parent; text: app.dash.initial; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold }
                    Accessible.name: "Profile"
                }
            }
            Dashboard { anchors.fill: parent; anchors.topMargin: 0; visible: win.section === "inicio"; onOpenSection: (k) => win.section = k }
            Loader {
                anchors.fill: parent; anchors.topMargin: 30
                active: win.section !== "inicio"
                visible: active
                source: ({ curso: "screens/CoursePage.qml", basicos: "screens/BasicsPage.qml", vidareal: "screens/VidaRealPage.qml", lab: "screens/LabPage.qml", conversaciones: "screens/ConversationsPage.qml",
                           vocabulario: "screens/VocabularyPage.qml", progreso: "screens/ProgressPage.qml", boleta: "screens/ReportCardPage.qml",
                           revision: "screens/ReviewPage.qml", configuracion: "screens/SettingsPage.qml" })[win.section] || ""
            }
        }
        // demo-data banner so seeded screenshots are never mistaken for real progress
        Rectangle {
            visible: app.demoMode
            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 8 }
            width: demoT.implicitWidth + 24; height: 26; radius: 13; color: Theme.amber
            Text { id: demoT; anchors.centerIn: parent; text: "DEMO DATA — not real progress"; color: "#1A1A1A"; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Bold }
        }
    }

    Loader {
        anchors.fill: parent
        active: app.screen === "workspace"
        sourceComponent: Workspace {}
        onLoaded: item.forceActiveFocus()
    }
    Loader {
        anchors.fill: parent
        active: app.screen === "summary"
        sourceComponent: app.summary.kind === "scenario" ? debriefC : summaryC
    }
    Loader {
        anchors.fill: parent
        active: app.screen === "test"
        sourceComponent: DayTest {}
        onLoaded: item.forceActiveFocus()
    }
    Loader {
        anchors.fill: parent
        active: app.screen === "review"
        sourceComponent: ReviewRunner {}
        onLoaded: item.forceActiveFocus()
    }
    }
    // ---------- update available ----------
    Rectangle {
        id: upd
        property string dismissed: ""
        visible: (updater.available && dismissed !== updater.latest) || updater.state === "downloading" || updater.state === "restarting"
        z: 50
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 14 }
        width: Math.min(parent.width - 40, updRow.implicitWidth + 36); height: updRow.implicitHeight + 22
        radius: 16; color: Theme.cardElevated; border.color: Theme.blue; border.width: 2
        RowLayout {
            id: updRow
            anchors.centerIn: parent; spacing: 14
            Icon { name: "download"; size: 22; color: Theme.blue }
            ColumnLayout { spacing: 2; Layout.maximumWidth: 520
                Text { text: updater.state === "restarting" ? "Updated! Restarting…"
                           : updater.state === "downloading" ? "Downloading version " + updater.latest + "… " + Math.round(updater.progress * 100) + "%"
                           : "Update available: version " + updater.latest
                       color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold }
                Text { visible: text !== "" && updater.state === "available"; text: updater.notes; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.maximumWidth: 520 }
                Text { visible: updater.state === "error"; text: updater.error; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.maximumWidth: 520 }
            }
            PillButton { visible: updater.state === "available" || updater.state === "error"; text: "Update now"; implicitHeight: 38; onClicked: updater.update() }
            PillButton { visible: updater.state === "available" || updater.state === "error"; text: "Later"; primary: false; implicitHeight: 38; onClicked: upd.dismissed = updater.latest }
        }
    }
    Component { id: summaryC; Summary {} }
    Component { id: debriefC; Debrief {} }
}
