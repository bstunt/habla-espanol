import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Basics: from-scratch practice units, always open. Nothing here is graded or locked.
PageFrame {
    id: bp
    title: "Basics"; titleEs: "Lo básico"
    subtitle: "Start from scratch, any time: sounds, numbers, colors, family, food and more. Practice only. Nothing here is graded or locked, and you can repeat any unit."
    readonly property var b: app.basics

    Card {
        visible: !bp.b.available
        Layout.fillWidth: true; implicitHeight: emptyCol.implicitHeight + 48
        ColumnLayout {
            id: emptyCol
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 24 }
            spacing: 8
            Text { text: "Basics lessons are on their way"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 24 }
            Text { text: "They'll appear here as soon as they're added. Meanwhile, Review keeps what you've learned fresh."
                   color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        }
    }

    Text {
        visible: bp.b.available
        text: (bp.b.completed || 0) + " of " + (bp.b.units || []).length + " units done"
        color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14
    }

    GridLayout {
        visible: bp.b.available
        Layout.fillWidth: true
        columns: width > 880 ? 3 : 2
        columnSpacing: 14; rowSpacing: 14
        Repeater {
            model: bp.b.units || []
            delegate: ItemDelegate {
                id: card
                required property var modelData
                Layout.fillWidth: true
                Layout.preferredHeight: 176
                focusPolicy: Qt.StrongFocus
                Accessible.name: modelData.title + ", " + modelData.status
                onClicked: app.openBasics(modelData.index)
                background: Rectangle {
                    radius: Theme.radius
                    color: card.hovered ? Theme.rowHover : Theme.card
                    border.color: card.visualFocus ? Theme.blue : Theme.borderSoft
                    border.width: card.visualFocus ? 2 : 1
                }
                contentItem: ColumnLayout {
                    spacing: 6
                    RowLayout {
                        spacing: 10
                        Text { text: modelData.emoji; font.pixelSize: 26 }
                        Item { Layout.fillWidth: true }
                        Icon { visible: modelData.status === "completed"; name: "circle-check"; color: Theme.green; size: 18 }
                        Text { visible: modelData.timesCompleted > 1; text: "×" + modelData.timesCompleted; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                    }
                    Text { text: modelData.title; color: Theme.text; font.family: Theme.serif; font.pixelSize: 21; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: modelData.titleEs; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 14; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: modelData.desc; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; Layout.fillWidth: true }
                    Item { Layout.fillHeight: true }
                    RowLayout {
                        spacing: 10
                        Rectangle {
                            Layout.fillWidth: true; height: 5; radius: 3; color: Qt.rgba(1, 1, 1, 0.1)
                            Rectangle { width: parent.width * modelData.progress; height: 5; radius: 3; color: modelData.status === "completed" ? Theme.green : Theme.blue }
                        }
                        Text {
                            text: modelData.status === "completed" ? "Practice again" : (modelData.status === "in_progress" ? "Continue" : "~" + modelData.minutes + " min")
                            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12
                        }
                    }
                }
            }
        }
    }
}
