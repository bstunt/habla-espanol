import QtQuick
import QtQuick.Layouts
import "../components"

// End of a Vida Real scenario: what you did, help used, what to practice next.
// Counts come straight from this run; nothing is turned into a single score.
Rectangle {
    id: db
    readonly property var s: app.summary
    readonly property var modeName: ({ guided: "Guided", assisted: "Assisted", independent: "Independent" })
    color: Theme.bg
    Flickable {
        anchors.fill: parent
        contentHeight: col.implicitHeight + 80
        clip: true
        ColumnLayout {
            id: col
            x: (parent.width - width) / 2; y: 44
            width: Math.min(db.width - 80, 780)
            spacing: 16
            Text { text: db.s.emoji || "🎉"; font.pixelSize: 46; Layout.alignment: Qt.AlignHCenter }
            Text { text: "¡Lo lograste!"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 38; Layout.alignment: Qt.AlignHCenter }
            Text { text: (db.s.titleEs || "") + " · " + (db.s.title || "") + " · " + (db.modeName[db.s.mode] || ""); color: Theme.text2; font.family: Theme.serif; font.italic: true; font.pixelSize: 18; Layout.alignment: Qt.AlignHCenter }

            Card {
                Layout.fillWidth: true; implicitHeight: did.implicitHeight + 40
                ColumnLayout {
                    id: did
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 22 }
                    spacing: 10
                    Text { text: "What you did"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; font.weight: Font.DemiBold }
                    Repeater {
                        model: [
                            { icon: "headphones", t: "Listening", v: (db.s.listening || {}).assessed ? db.s.listening.correct + " of " + db.s.listening.assessed + " answered correctly" : "No listening questions answered" },
                            { icon: "pencil", t: "Building and typing", v: ((db.s.construction || {}).assessed ? db.s.construction.correct + " of " + db.s.construction.assessed + " correct" : "None checked")
                                                                       + ((db.s.construction || {}).unassessed ? " · " + db.s.construction.unassessed + " in your own words (not checked)" : "") },
                            { icon: "message-circle", t: "Conversation", v: ((db.s.conversation || {}).good || 0) + " replies that moved it forward"
                                                                      + ((db.s.conversation || {}).repair ? " · asked to repeat or slow down " + db.s.conversation.repair + "×" : "")
                                                                      + ((db.s.conversation || {}).off ? " · " + db.s.conversation.off + " that didn't fit, then fixed" : "") },
                            { icon: "sparkles", t: "Something changed", v: "You adapted and finished the conversation" },
                            { icon: "mic", t: "Speaking", v: db.s.speakingRated ? db.s.speakingRated + " takes rated · best " + db.s.speakingBest + " of 100" : "No takes rated this time (skipped, or no microphone)" },
                            { icon: "lightbulb", t: "Help used", v: (db.modeName[db.s.mode] || "") + " mode" + (db.s.hints ? " · " + db.s.hints + " hints" : " · no hints") + (db.s.english ? " · English shown" : "") }
                        ]
                        delegate: RowLayout {
                            required property var modelData
                            spacing: 12; Layout.fillWidth: true
                            Rectangle { width: 30; height: 30; radius: 8; color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.16)
                                Icon { anchors.centerIn: parent; name: modelData.icon; color: Theme.blue; size: 16 } }
                            Text { text: modelData.t; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; Layout.preferredWidth: 180 }
                            Text { text: modelData.v; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        }
                    }
                }
            }

            Card {
                Layout.fillWidth: true; implicitHeight: nxt.implicitHeight + 40
                ColumnLayout {
                    id: nxt
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 22 }
                    spacing: 10
                    Text { text: "Practice next"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; font.weight: Font.DemiBold }
                    Text { visible: (db.s.review || []).length === 0; text: "Nothing you missed this time. These phrases still come back in spaced review so they stick."
                           color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Repeater {
                        model: db.s.review || []
                        delegate: RowLayout {
                            required property var modelData
                            spacing: 12
                            SayButton { phrase: modelData.es; size: 30 }
                            Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17 }
                            Text { text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                        }
                    }
                }
            }

            Text { text: db.s.realLife || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17; lineHeight: 1.3; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Text { text: "Finishing a scenario isn't the same as mastering it. What you found hard comes back in review."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            RowLayout {
                Layout.alignment: Qt.AlignHCenter; spacing: 12; Layout.topMargin: 6
                PillButton { text: "Back to Vida Real"; primary: false; onClicked: app.goTo("vidareal") }
                PillButton {
                    readonly property string nextMode: db.s.mode === "guided" ? "assisted" : (db.s.mode === "assisted" ? "independent" : "independent")
                    text: db.s.mode === "independent" ? "Practice again" : "Try it " + (db.modeName[nextMode] || "").toLowerCase()
                    iconName: "play"
                    onClicked: app.startScenario(db.s.scenarioId, nextMode)
                }
            }
        }
    }
}
