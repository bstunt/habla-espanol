import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"
import "../exercises"

// Distraction-free lesson workspace. Opens from "Start/Continue session".
Rectangle {
    id: ws
    readonly property var w: app.ws
    color: Theme.bg
    focus: true
    Keys.onEscapePressed: app.backToDashboard()

    Shortcut { sequences: ["Return", "Enter", "Ctrl+Return", "Meta+Return"]; enabled: host.complete; onActivated: app.advance() }

    // top bar
    RowLayout {
        id: top
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 20; rightMargin: 28; topMargin: 30 }
        spacing: 16
        IconButton { iconName: "arrow-left"; label: "Back to Home (Esc)"; iconColor: Theme.text; onClicked: app.backToDashboard() }
        ColumnLayout {
            spacing: 2
            Text { text: w.scenario ? "Vida Real · " + w.sessionTitle + " · " + ({ guided: "Guided", assisted: "Assisted", independent: "Independent" })[w.mode]
                         : (w.basics ? "Basics · Lo básico" : "Session " + w.sessionNo + " · " + w.sessionTitle); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
            Text { text: w.moduleNo + ". " + w.moduleTitle; color: Theme.text; font.family: Theme.serif; font.pixelSize: 24; font.weight: Font.Medium; Accessible.role: Accessible.Heading }
        }
        Item { Layout.fillWidth: true }
        ColumnLayout {
            spacing: 6
            Text { Layout.alignment: Qt.AlignRight; text: "Exercise " + w.exerciseIndex + " of " + w.exerciseCount + "  ·  ~" + w.minutesLeft + " min left"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
            Rectangle {
                Layout.preferredWidth: 320; height: 6; radius: 3; color: Qt.rgba(1, 1, 1, 0.1)
                Rectangle { width: parent.width * w.overallIndex / Math.max(1, w.overallCount); height: 6; radius: 3; color: Theme.blue
                            Behavior on width { NumberAnimation { duration: 250 } } }
            }
        }
    }

    RowLayout {
        anchors { left: parent.left; right: parent.right; top: top.bottom; bottom: actions.top; leftMargin: 28; rightMargin: 28; topMargin: 22; bottomMargin: 16 }
        spacing: 24

        // left: module progress
        ColumnLayout {
            Layout.preferredWidth: 230; Layout.maximumWidth: 230; Layout.alignment: Qt.AlignTop
            spacing: 6
            Repeater {
                model: w.modules
                delegate: Rectangle {
                    required property var modelData
                    Layout.fillWidth: true; height: 40; radius: 10
                    color: modelData.no === w.moduleNo ? Theme.navActive : (jm.containsMouse && !!w.replay ? Theme.rowHover : "transparent")
                    MouseArea { id: jm; anchors.fill: parent; enabled: !!w.replay; hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor; onClicked: app.jumpToLesson(modelData.no) }
                    Accessible.role: w.replay ? Accessible.Button : Accessible.StaticText
                    Accessible.name: modelData.title
                    RowLayout {
                        anchors.fill: parent; anchors.leftMargin: 10; spacing: 10
                        Rectangle { width: 20; height: 20; radius: 10
                            color: modelData.status === "completed" ? Theme.green : (modelData.status === "needs_review" ? Theme.amber : "transparent")
                            border.color: modelData.status === "completed" ? Theme.green : (modelData.no === w.moduleNo ? Theme.blue : Qt.rgba(1, 1, 1, 0.3)); border.width: 1.5
                            Text { anchors.centerIn: parent; text: modelData.status === "completed" ? "✓" : modelData.no; color: Theme.text; font.pixelSize: 10 } }
                        Text { text: modelData.title; color: modelData.no === w.moduleNo ? Theme.text : Theme.text2; font.family: Theme.sans; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true }
                    }
                }
            }
        }

        // center: the exercise
        Flickable {
            id: center
            Layout.fillWidth: true; Layout.fillHeight: true
            contentWidth: width
            contentHeight: host.implicitHeight + 40
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar { policy: center.contentHeight > center.height ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }
            ExerciseHost {
                id: host
                width: Math.min(center.width - 12, 860)
                x: Math.max(0, (center.width - width) / 2 - 6)
                ex: w.exercise || ({})
                st: w.state || ({})
                partner: w.partner || "Ana"
                learner: w.learnerName || "Sam"
            }
        }

        // right: contextual help
        Card {
            Layout.preferredWidth: 300; Layout.maximumWidth: 300; Layout.fillHeight: true
            ColumnLayout {
                anchors.fill: parent; anchors.margins: 20; spacing: 12
                Text { text: "Help"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold }
                Text { text: "Mission: " + w.mission; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Rectangle { Layout.fillWidth: true; height: 1; color: Theme.borderSoft }
                Text { text: "Key phrases"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; font.capitalization: Font.AllUppercase; font.letterSpacing: 1 }
                Repeater {
                    model: w.phrases || []
                    delegate: RowLayout {
                        required property var modelData
                        Layout.fillWidth: true
                        ColumnLayout { spacing: 0; Layout.fillWidth: true
                            Text { text: modelData.es; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; Layout.fillWidth: true; wrapMode: Text.WordWrap }
                            Text { text: modelData.en; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; Layout.fillWidth: true; wrapMode: Text.WordWrap } }
                        IconButton { iconName: "volume-2"; iconSize: 15; label: "Play"; onClicked: app.say(modelData.es, false) }
                    }
                }
                Item { Layout.fillHeight: true }
                Rectangle { Layout.fillWidth: true; height: 1; color: Theme.borderSoft }
                Text { text: "Rescue phrases"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; font.capitalization: Font.AllUppercase; font.letterSpacing: 1 }
                Repeater {
                    model: [{ es: "¿Puedes repetir, por favor?", en: "Can you repeat, please?" }, { es: "Más despacio, por favor.", en: "More slowly, please." }, { es: "No entiendo.", en: "I don't understand." }]
                    delegate: RowLayout {
                        required property var modelData
                        Layout.fillWidth: true
                        ColumnLayout { spacing: 0; Layout.fillWidth: true
                            Text { text: modelData.es; color: Theme.text; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true; wrapMode: Text.WordWrap }
                            Text { text: modelData.en; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11; Layout.fillWidth: true } }
                        IconButton { iconName: "volume-2"; iconSize: 14; label: "Play"; onClicked: app.say(modelData.es, false) }
                    }
                }
            }
        }
    }

    // bottom action bar
    RowLayout {
        id: actions
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 28; rightMargin: 28; bottomMargin: 24 }
        spacing: 12
        PillButton { text: "Previous"; primary: false; visible: !w.single; enabled: w.overallIndex > 1; opacity: enabled ? 1 : 0.4; onClicked: app.previous() }
        Item { Layout.fillWidth: true }
        Text { visible: !host.complete; text: ws.hintText(); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
        PillButton {
            text: w.single ? "Done" : (w.overallIndex === w.overallCount ? (w.scenario ? "See debrief" : (w.basics ? "Finish unit" : "Finish session")) : "Continue")
            implicitWidth: 190
            enabled: host.complete
            opacity: enabled ? 1 : 0.45
            onClicked: app.advance()
        }
    }
    function hintText() {
        var t = (w.exercise || {}).type
        return ({ listen_choose: "Choose an answer to continue", dialogue: "Listen, then answer the questions",
                  build: "Build the sentence to continue", type: "Type your answer to continue",
                  speak: "Say it (or skip) to continue", conversation: "Finish the conversation to continue",
                  exit: "Answer every question to continue", reflect: "Pick one to continue" })[t] || ""
    }
}
