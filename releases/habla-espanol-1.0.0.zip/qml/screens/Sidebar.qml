import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

Rectangle {
    id: side
    property string current: "inicio"
    signal navigate(string key)
    color: Theme.sidebar
    clip: true

    // decorative footer: serape stripes fading up into the sidebar color
    SerapeBand {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: Math.max(0, Math.min(parent.height * 0.36, parent.height - 640))
    }
    Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.borderSoft }

    ColumnLayout {
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 18; rightMargin: 14; topMargin: 44 }
        spacing: 4

        // wordmark: live text, not an image, so it stays accessible
        Item {
            Layout.fillWidth: true; Layout.preferredHeight: 100
            Text {
                id: word
                anchors.horizontalCenter: parent.horizontalCenter
                text: "Habla"; color: Theme.text; font.family: Theme.script; font.pixelSize: 74
                Accessible.name: "Habla"
            }
            Rectangle {   // chat-bubble accent
                x: word.x + word.width - 8; y: 12; width: 32; height: 26; radius: 13; color: Theme.coral
                Text { anchors.centerIn: parent; anchors.verticalCenterOffset: -3; text: "···"; color: Theme.onCoral; font.pixelSize: 16; font.bold: true }
                Accessible.ignored: true
            }
        }
        Text {
            Layout.fillWidth: true
            text: "Cuz Shane can't speak spanish"
            color: Theme.text; font.family: Theme.serif; font.pixelSize: 16; horizontalAlignment: Text.AlignHCenter; lineHeight: 1.2
        }
        Item { Layout.preferredHeight: 22 }

        Repeater {
            model: [
                { key: "inicio", label: "Home", es: "Inicio", icon: "house" },
                { key: "curso", label: "Course", es: "Curso", icon: "book-open" },
                { key: "basicos", label: "Basics", es: "Lo básico", icon: "shapes" },
                { key: "vidareal", label: "Real life", es: "Vida real", icon: "message-square-more" },
                { key: "lab", label: "Conversation Lab", es: "Responde de verdad", icon: "flask-conical" },
                { key: "conversaciones", label: "Conversations", es: "Conversaciones", icon: "message-circle" },
                { key: "vocabulario", label: "Vocabulary", es: "Vocabulario", icon: "languages" },
                { key: "progreso", label: "Progress", es: "Progreso", icon: "chart-column" },
                { key: "revision", label: "Review", es: "Repaso", icon: "refresh-cw" },
                { key: "configuracion", label: "Settings", es: "Configuración", icon: "settings" }
            ]
            delegate: NavItem {
                required property var modelData
                Layout.fillWidth: true
                Layout.preferredHeight: 48
                text: modelData.label
                spanish: modelData.es
                iconName: modelData.icon
                active: side.current === modelData.key
                onClicked: side.navigate(modelData.key)
            }
        }
    }

    Rectangle {   // frosted panel keeps the quote legible over the bright artwork
        visible: quote.visible
        anchors { left: parent.left; right: parent.right; top: quote.top; bottom: quote.bottom; leftMargin: 14; rightMargin: 14; topMargin: -16; bottomMargin: -18 }
        radius: 14
        color: Qt.rgba(Theme.sidebar.r, Theme.sidebar.g, Theme.sidebar.b, 0.85)
    }
    Column {
        id: quote
        visible: side.height >= 900     // quote yields to navigation on short windows
        anchors { left: parent.left; bottom: parent.bottom; leftMargin: 32; bottomMargin: 44 }
        spacing: 14
        Text {
            text: "A new language\nopens up a\nbigger world."
            color: Theme.text; font.family: Theme.serif; font.italic: true; font.pixelSize: 19; lineHeight: 1.15
            style: Text.Raised; styleColor: Qt.rgba(0, 0, 0, 0.35)
        }
        Rectangle { width: 28; height: 1; color: Theme.text2 }
    }
}
