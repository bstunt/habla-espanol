import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

Item {
    id: cp
    property var picked: null          // a finished day whose lessons are shown
PageFrame {
    anchors.fill: parent
    title: "Course"; titleEs: "Curso"
    subtitle: "30 sessions of about an hour each, one a day. Each one opens the day after you finish the one before."
    GridLayout {
        Layout.fillWidth: true
        columns: width > 1100 ? 3 : 2
        columnSpacing: 14; rowSpacing: 14
        Repeater {
            model: app.lib.course || []
            delegate: ItemDelegate {
                id: cd
                required property var modelData
                Layout.fillWidth: true
                Layout.preferredHeight: 150
                enabled: modelData.status !== "locked" && modelData.status !== "tomorrow" && modelData.available
                focusPolicy: Qt.StrongFocus
                Accessible.name: "Session " + modelData.no + ": " + modelData.title + ", " + modelData.status
                onClicked: modelData.status === "completed" ? cp.picked = modelData
                           : (modelData.testGate ? app.startTest(modelData.testGate) : app.openSession(modelData.no))
                background: Rectangle {
                    radius: Theme.radius
                    color: modelData.status === "current" ? Theme.navActive : (cd.hovered && cd.enabled ? Theme.rowHover : Theme.card)
                    border.color: cd.visualFocus ? Theme.blue : (modelData.status === "current" ? Qt.rgba(0.35, 0.65, 1, 0.5) : Theme.borderSoft)
                    border.width: cd.visualFocus ? 2 : 1
                    opacity: modelData.status === "locked" || modelData.status === "tomorrow" ? 0.55 : 1
                }
                contentItem: ColumnLayout {
                    spacing: 6
                    RowLayout {
                        Text { text: "SESSION " + modelData.no; color: modelData.status === "current" ? Theme.text : Theme.text3; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.2; font.weight: Font.Bold; Layout.fillWidth: true }
                        Text { visible: modelData.status === "completed"; text: modelData.testPassed ? "Test ✓" : "Test needed"; color: modelData.testPassed ? Theme.green : Theme.amber; font.family: Theme.sans; font.pixelSize: 12 }
                        Icon { visible: modelData.status === "completed"; name: "circle-check"; color: modelData.needsReview ? Theme.amber : Theme.green; size: 18 }
                        Icon { visible: modelData.status === "locked"; name: "lock"; color: Theme.text3; size: 16 }
                        Text { visible: modelData.status === "tomorrow"; text: "Opens tomorrow"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12 }
                        Icon { visible: modelData.status === "tomorrow"; name: "clock"; color: Theme.text2; size: 16 }
                        Text { visible: !!modelData.testGate; text: "Pass Day " + modelData.testGate + " test first"; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 12 }
                        Text { visible: modelData.status === "current" && !modelData.testGate; text: modelData.modulesDone + "/7"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 13 }
                    }
                    Text { text: modelData.title; color: Theme.text; font.family: Theme.serif; font.pixelSize: 22; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: modelData.titleEs; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 15; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: modelData.mission; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; Layout.fillWidth: true }
                    Item { Layout.fillHeight: true }
                }
            }
        }
    }
}

    // ---------- a finished day: jump into any lesson ----------
    Rectangle {
        anchors.fill: parent
        visible: cp.picked !== null
        color: Qt.rgba(0, 0, 0, 0.55)
        MouseArea { anchors.fill: parent; onClicked: cp.picked = null }
        Card {
            anchors.centerIn: parent
            width: Math.min(parent.width - 80, 620)
            height: Math.min(parent.height - 60, lc.implicitHeight + 52)
            elevated: true
            focus: cp.picked !== null
            Keys.onEscapePressed: cp.picked = null
            MouseArea { anchors.fill: parent }
            ColumnLayout {
                id: lc
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 26 }
                spacing: 8
                RowLayout {
                    spacing: 12; Layout.fillWidth: true
                    ColumnLayout { spacing: 0; Layout.fillWidth: true
                        Text { text: cp.picked ? "SESSION " + cp.picked.no : ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; font.letterSpacing: 1.2; font.weight: Font.Bold }
                        Text { text: cp.picked ? cp.picked.title : ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 26; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        Text { text: cp.picked ? cp.picked.titleEs : ""; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 15 } }
                    IconButton { iconName: "x"; label: "Close"; iconColor: Theme.text; onClicked: cp.picked = null; Layout.alignment: Qt.AlignTop }
                }
                Text { text: "You finished this day. Jump into any lesson; your answers count as extra practice."
                       color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true; Layout.bottomMargin: 4 }
                Repeater {
                    model: cp.picked ? cp.picked.lessons : []
                    delegate: ModuleRow {
                        required property var modelData
                        Layout.fillWidth: true; implicitHeight: 54
                        number: modelData.no; title: modelData.title; desc: modelData.desc
                        minutes: modelData.minutes; iconName: modelData.icon; status: modelData.status
                        onClicked: { var n = cp.picked.no; cp.picked = null; app.redoLesson(n, modelData.no, "curso") }
                    }
                }
                RowLayout {
                    Layout.topMargin: 8; spacing: 12
                    PillButton {
                        text: "Redo the whole day"; primary: false; iconName: "refresh-cw"; implicitWidth: 240
                        onClicked: { var n = cp.picked.no; cp.picked = null; app.redoDay(n, "curso") }
                    }
                    PillButton {
                        text: cp.picked && cp.picked.testPassed ? "Retake the test" : "Take the day test"
                        primary: !(cp.picked && cp.picked.testPassed); iconName: "list-checks"
                        onClicked: { var n = cp.picked.no; cp.picked = null; app.startTest(n) }
                    }
                    Text {
                        visible: !!(cp.picked && cp.picked.testBest)
                        text: cp.picked && cp.picked.testBest ? ((cp.picked.testPassed ? "✓ Passed · " : "Not passed yet · ") + "best " + cp.picked.testBest.best + "/" + cp.picked.testBest.total) : ""
                        color: cp.picked && cp.picked.testPassed ? Theme.green : Theme.amber; font.family: Theme.sans; font.pixelSize: 13
                    }
                }
            }
        }
    }
}
