import QtQuick
import QtQuick.Layouts
import "../components"
import "../exercises"

// Spaced review: quick listen/recall items built from your due concepts.
Rectangle {
    id: rr
    readonly property var items: (app.review.items || [])
    property int idx: 0
    property int correct: 0
    property bool answered: false
    readonly property bool finished: idx >= items.length
    color: Theme.bg
    focus: true
    Keys.onEscapePressed: app.finishReview()

    RowLayout {
        id: top
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 28; topMargin: 30 }
        IconButton { iconName: "arrow-left"; label: "Back to Home"; iconColor: Theme.text; onClicked: app.finishReview() }
        Text { text: "Spaced review"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 26; Layout.fillWidth: true; Layout.leftMargin: 10 }
        Text { visible: !rr.finished; text: (rr.idx + 1) + " of " + rr.items.length; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 }
    }
    Item {
        anchors { left: parent.left; right: parent.right; top: top.bottom; bottom: parent.bottom; margins: 28 }
        ColumnLayout {
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(parent.width, 760)
            spacing: 18
            Loader {
                id: ld
                Layout.fillWidth: true
                active: !rr.finished
                sourceComponent: ChoiceItem {
                    review: true
                    reviewIndex: rr.idx
                    item: ({ prompt: rr.items[rr.idx].prompt,
                             audio: rr.items[rr.idx].kind === "listen" ? rr.items[rr.idx].audio : "",
                             options: rr.items[rr.idx].options,
                             explain: rr.items[rr.idx].es + " = " + rr.items[rr.idx].en })
                    onAnswered: (ok) => { if (ok) rr.correct += 1; rr.answered = true }
                }
            }
            PillButton { visible: rr.answered && !rr.finished; text: rr.idx + 1 < rr.items.length ? "Next" : "Finish"; implicitWidth: 160
                         onClicked: { rr.answered = false; rr.idx += 1; ld.active = false; ld.active = !rr.finished } }
            ColumnLayout {
                visible: rr.finished
                spacing: 14
                Icon { name: "sparkles"; color: Theme.amber; size: 44 }
                Text { text: rr.correct + " of " + rr.items.length + " remembered"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 34 }
                Text { text: "Items you remembered come back later; the others come back sooner."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15 }
                PillButton { text: "Back to Home"; onClicked: app.finishReview() }
            }
        }
    }
}
