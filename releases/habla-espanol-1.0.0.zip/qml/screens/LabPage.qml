import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Conversation Lab · Aprende a responder de verdad.
// A message arrives → what does it mean? → what would you say? → breakdown → same pattern elsewhere.
Item {
    id: lp
    property string tab: "messages"            // messages | decoder | texting
    readonly property var c: lab.card
    readonly property bool inCard: !!(c && c.id)
    property var placed: []                     // tile indexes (level 1)
    property string micFor: ""                  // respond | transfer | decoder | rate
    property string micError: ""
    property string rated: ""                   // which step the pronunciation rating belongs to
    property string decId: ""
    property var decListen: ({})
    property string lastCard: ""

    onCChanged: {
        if (!c || c.id !== lastCard) { placed = []; rated = ""; micError = ""; lastCard = c ? (c.id || "") : "" }
    }
    Component.onCompleted: lab.refresh()
    Component.onDestruction: { audio.stopAll(); if (audio.state === "recording") audio.stopRecording() }

    function verdictText(v) {
        return ({ natural: "Natural ✓", good: "Good ✓", fix: "Almost", off: "Doesn't fit yet", checking: "Checking…",
                  compare: "Compare", shown: "Here's one way" })[v] || ""
    }
    function verdictColor(v) {
        return v === "natural" || v === "good" ? Theme.green : (v === "fix" || v === "compare" || v === "shown" ? Theme.amber : (v === "off" ? Theme.coral : Theme.text2))
    }
    function startMic(kind) {
        micError = ""
        if (audio.state === "recording") { audio.stopRecording(); return }
        audio.stopAll()
        micFor = kind
        speech.setLabReply()
        audio.startRecording()
    }
    function startRate(text, step) {
        micError = ""
        if (audio.state === "recording") { audio.stopRecording(); return }
        audio.stopAll()
        micFor = "rate"; rated = step
        speech.setPracticeReference(text, "es-MX")
        audio.startRecording()
    }
    Connections {
        target: speech
        function onChanged() {
            if (!lp.micFor) return
            if (speech.state === "error") { lp.micError = speech.result.error || "Couldn't hear that."; if (lp.micFor !== "rate") lp.micFor = ""; return }
            if (speech.state !== "done") return
            var heard = (speech.result.heard || "").trim()
            var k = lp.micFor
            if (k === "rate") return               // the rating stays on screen
            lp.micFor = ""
            if (!heard) { lp.micError = "Habla didn't catch any words. Try again a little closer to the mic."; return }
            if (k === "respond") lab.submitText(heard, true)
            else if (k === "transfer") lab.submitTransfer(heard, true)
            else if (k === "decoder") lab.decoderRespond(lp.decId, heard)
        }
    }

    // ---------- small pieces ----------
    component Avatar: Rectangle {
        property var who: ({})
        width: 40; height: 40; radius: 20; color: who.color || Theme.blue
        Text { anchors.centerIn: parent; text: who.initial || "?"; color: "white"; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.Bold }
    }
    component Bubble: Rectangle {        // a chat bubble; mine = the learner's
        id: bub
        property string text: ""
        property string sub: ""
        property bool mine: false
        property string say: ""
        Layout.alignment: bub.mine ? Qt.AlignRight : Qt.AlignLeft
        Layout.maximumWidth: 520
        implicitWidth: Math.min(520, brow.implicitWidth + 30)
        implicitHeight: bcol.implicitHeight + 22
        radius: 18
        color: bub.mine ? Theme.blueDeep : Theme.cardElevated
        border.color: bub.mine ? "transparent" : Theme.border
        RowLayout {
            id: brow
            anchors { fill: parent; leftMargin: 16; rightMargin: 10; topMargin: 11; bottomMargin: 11 }
            spacing: 8
            ColumnLayout { id: bcol; spacing: 3; Layout.fillWidth: true
                Text { id: bt; text: bub.text; color: Theme.text; font.family: Theme.serif; font.pixelSize: 21; wrapMode: Text.WordWrap; Layout.fillWidth: true; textFormat: Text.PlainText }
                Text { id: bs; visible: text !== ""; text: bub.sub; color: bub.mine ? Qt.rgba(1, 1, 1, 0.75) : Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            }
            SayButton { visible: !!bub.say; phrase: bub.say; size: 32; Layout.alignment: Qt.AlignTop }
            SayButton { visible: !!bub.say; phrase: bub.say; slow: true; size: 32; tint: Qt.rgba(1, 1, 1, 0.12); Layout.alignment: Qt.AlignTop }
        }
    }
    component Mic: RoundButton {         // speak instead of typing
        id: micB
        property string kind: ""
        readonly property bool live: audio.state === "recording" && lp.micFor === kind
        readonly property bool busy: speech.state === "checking" && lp.micFor === kind
        Layout.preferredWidth: 46; Layout.preferredHeight: 46
        enabled: !lab.card.checking && (live || ["ready", "saved", "failed", "playback"].indexOf(audio.state) >= 0)
        Accessible.name: live ? "Stop" : "Say your reply"
        onClicked: lp.startMic(kind)
        contentItem: Item { Icon { anchors.centerIn: parent; name: micB.live ? "square" : "mic"; color: "white"; size: 20 } }
        background: Rectangle { radius: 23; color: !micB.enabled ? Qt.rgba(1, 1, 1, 0.1) : (micB.live ? Theme.coralDeep : Theme.coral)
            SequentialAnimation on opacity { running: micB.live; loops: Animation.Infinite
                NumberAnimation { to: 0.55; duration: 500 } NumberAnimation { to: 1; duration: 500 } } }
        ToolTip.visible: hovered; ToolTip.text: live ? "Stop" : "Say it instead of typing"
    }
    component ReplyField: RowLayout {   // type or say a reply
        id: rf
        property string kind: "respond"
        property alias field: tf
        signal submit(string t)
        spacing: 10; Layout.fillWidth: true
        TextField {
            id: tf
            Layout.fillWidth: true; Layout.preferredHeight: 48; leftPadding: 14
            placeholderText: "Escribe tu respuesta… (type your reply)"
            color: Theme.text; font.family: Theme.serif; font.pixelSize: 19; placeholderTextColor: Theme.text3
            enabled: !lab.card.checking
            background: Rectangle { radius: 24; color: Qt.rgba(1, 1, 1, 0.05); border.color: tf.activeFocus ? Theme.blue : Theme.border }
            onAccepted: if (text.trim() !== "") rf.submit(text)
            Accessible.name: "Your reply in Spanish"
        }
        Mic { kind: rf.kind }
        PillButton { text: "Send"; iconName: "message-circle-reply"; enabled: tf.text.trim() !== "" && !lab.card.checking; onClicked: rf.submit(tf.text) }
    }
    component MicStatus: Text {
        property string kind: ""
        visible: text !== ""
        text: (audio.state === "recording" && lp.micFor === kind) ? "Listening… press ■ when you're done"
            : (speech.state === "checking" && lp.micFor === kind) ? "Writing down what you said…"
            : (lp.micError !== "" && (kind === "" || true) ? lp.micError : "")
        color: lp.micError !== "" && audio.state !== "recording" ? Theme.amber : Theme.text2
        font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true
    }
    component Verdict: ColumnLayout {    // the result of a reply
        id: vd
        property var r: ({})
        property bool showModel: true
        visible: !!r.verdict
        spacing: 8; Layout.fillWidth: true
        RowLayout { spacing: 10
            Rectangle { implicitWidth: vt.implicitWidth + 22; implicitHeight: 30; radius: 15
                color: Qt.rgba(lp.verdictColor(vd.r.verdict).r, lp.verdictColor(vd.r.verdict).g, lp.verdictColor(vd.r.verdict).b, 0.16)
                border.color: lp.verdictColor(vd.r.verdict)
                Text { id: vt; anchors.centerIn: parent; text: lp.verdictText(vd.r.verdict); color: lp.verdictColor(vd.r.verdict); font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.Bold } }
            Text { visible: vd.r.source === "ai"; text: "✨ checked by ChatGPT"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
            Text { visible: !!vd.r.accentNote; text: "Watch the accents"; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 12 }
            BusyIndicator { visible: vd.r.verdict === "checking"; running: visible; implicitWidth: 24; implicitHeight: 24 }
        }
        Text { visible: !!vd.r.means; text: "Your reply says: “" + (vd.r.means || "") + "”"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Text { visible: !!vd.r.feedback; text: vd.r.feedback || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Text { visible: !!vd.r.aiError; text: (vd.r.aiError || "") + " Compare it yourself for now."; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        RowLayout { visible: !!vd.r.corrected && vd.r.corrected !== vd.r.text; spacing: 8; Layout.fillWidth: true
            Text { text: "Fixed:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; Layout.preferredWidth: 92 }
            Text { text: vd.r.corrected || ""; color: Theme.spanishAccent; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            SayButton { phrase: vd.r.corrected || ""; size: 30 } }
        RowLayout { visible: !!vd.r.natural && vd.r.natural !== vd.r.text && vd.r.natural !== vd.r.corrected; spacing: 8; Layout.fillWidth: true
            Text { text: "A Mexican\nmight say:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; Layout.preferredWidth: 92 }
            ColumnLayout { spacing: 0; Layout.fillWidth: true
                Text { text: vd.r.natural || ""; color: Theme.spanishAccent; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Text { text: vd.r.natural_en || ""; visible: text !== ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            SayButton { phrase: vd.r.natural || ""; size: 30 } }
        RowLayout { visible: vd.showModel && !!vd.r.model && (vd.r.verdict === "compare" || vd.r.verdict === "shown" || vd.r.verdict === "off" || vd.r.kind === "tiles" || (vd.r.verdict === "fix" && !vd.r.natural)); spacing: 8; Layout.fillWidth: true
            Text { text: vd.r.verdict === "compare" ? "Model reply:" : "One way:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; Layout.preferredWidth: 92 }
            Text { text: vd.r.model || ""; color: Theme.spanishAccent; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            SayButton { phrase: vd.r.model || ""; size: 30 } }
    }
    component RateBox: ColumnLayout {   // say the reply aloud: rating + hear your own take
        id: rb
        property string phrase: ""
        property string step: ""
        spacing: 8; Layout.fillWidth: true
        RowLayout { spacing: 10
            PillButton {
                text: audio.state === "recording" && lp.micFor === "rate" ? "Stop" : "Say it aloud"
                iconName: audio.state === "recording" && lp.micFor === "rate" ? "square" : "mic"; primary: false
                enabled: rb.phrase !== "" && speech.state !== "checking"
                onClicked: lp.startRate(rb.phrase, rb.step)
            }
            PillButton { visible: audio.hasRecording && lp.rated === rb.step; text: "Hear mine"; iconName: "play"; primary: false; onClicked: audio.playRecording() }
            PillButton { visible: audio.hasRecording && lp.rated === rb.step; text: "Compare"; iconName: "headphones"; primary: false; onClicked: audio.compare(rb.phrase) }
        }
        Text { visible: lp.rated === rb.step && lp.micFor === "rate" && speech.state === "checking"; text: "Rating your pronunciation…"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
        RowLayout {
            visible: lp.rated === rb.step && lp.micFor === "rate" && speech.state === "done"; spacing: 14; Layout.fillWidth: true
            Rectangle { width: 54; height: 54; radius: 27; color: "transparent"; border.width: 3
                border.color: (speech.result.score || 0) >= 80 ? Theme.green : ((speech.result.score || 0) >= 60 ? Theme.amber : Theme.coral)
                Text { anchors.centerIn: parent; text: speech.result.score || 0; color: Theme.text; font.family: Theme.sans; font.pixelSize: 20; font.weight: Font.Bold } }
            ColumnLayout { spacing: 2; Layout.fillWidth: true
                Text { text: "Accuracy " + (speech.result.accuracy || 0) + " · Fluency " + (speech.result.fluency || 0) + " · Completeness " + (speech.result.completeness || 0); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                Flow { Layout.fillWidth: true; spacing: 6
                    Repeater { model: speech.result.words || []
                        delegate: Text { required property var modelData; text: modelData.word; font.family: Theme.serif; font.pixelSize: 17
                            color: modelData.accuracy >= 80 ? Theme.green : (modelData.accuracy >= 60 ? Theme.amber : Theme.coral) } } }
                Text { text: speech.result.tip || ""; visible: text !== ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
        }
        Text { visible: lp.rated === rb.step && lp.micFor === "rate" && speech.state === "error"; text: speech.result.error || ""; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    }
    component SectionTitle: Text { color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold; Layout.topMargin: 6 }
    component Hint: Text { color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }

    // ---------- header ----------
    ColumnLayout {
        id: head
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 32; rightMargin: 32; topMargin: 30 }
        spacing: 4
        RowLayout { spacing: 14; Layout.fillWidth: true
            Text { text: "Conversation Lab"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 36; Accessible.role: Accessible.Heading }
            Text { text: "Aprende a responder de verdad"; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 22; Layout.alignment: Qt.AlignBaseline }
            Item { Layout.fillWidth: true }
            PillButton { visible: lp.inCard; text: "Back to the Lab"; iconName: "chevron-left"; primary: false; onClicked: { audio.stopAll(); lab.close() } }
        }
        Text { visible: !lp.inCard; text: "A message comes in. Work out what it means, then answer it yourself — no translator."
               color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        RowLayout { visible: !lp.inCard; spacing: 8; Layout.topMargin: 10
            Repeater {
                model: [{ k: "messages", t: "Messages", i: "message-square" }, { k: "decoder", t: "Mexican Spanish decoder", i: "sparkles" }, { k: "texting", t: "Texting shortcuts", i: "keyboard" }]
                delegate: Button {
                    required property var modelData
                    checkable: false; padding: 10; leftPadding: 16; rightPadding: 16
                    onClicked: { lp.tab = modelData.k; lab.clearDecoder() }
                    contentItem: Row { spacing: 8
                        Icon { name: modelData.i; size: 16; color: lp.tab === modelData.k ? Theme.onBlue : Theme.text2; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: modelData.t; color: lp.tab === modelData.k ? Theme.onBlue : Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold; anchors.verticalCenter: parent.verticalCenter } }
                    background: Rectangle { radius: 18; color: lp.tab === modelData.k ? Theme.blue : (parent.hovered ? Theme.rowHover : Qt.rgba(1, 1, 1, 0.04)); border.color: lp.tab === modelData.k ? "transparent" : Theme.border }
                }
            }
        }
    }

    // =========================================================== HOME: messages
    Flickable {
        id: homeF
        visible: !lp.inCard && lp.tab === "messages"
        anchors { left: parent.left; right: parent.right; top: head.bottom; bottom: parent.bottom; topMargin: 16 }
        contentWidth: width; contentHeight: homeCol.implicitHeight + 40; clip: true; boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar {}
        ColumnLayout {
            id: homeCol
            x: 32; width: parent.width - 64; spacing: 16
            // stats
            RowLayout { spacing: 12; Layout.fillWidth: true
                Repeater {
                    model: [
                        { t: "Stage", v: lab.stats.stageName, s: "of 4: Understand · Respond · Converse · Natural" },
                        { t: "You understand", v: lab.stats.compPct < 0 ? "—" : lab.stats.compPct + "%", s: "picking the meaning, first try" },
                        { t: "You answer on your own", v: lab.stats.prodPct < 0 ? "—" : lab.stats.prodPct + "%", s: "replies at levels 2–3, no hints" },
                        { t: "Streak", v: (lab.stats.streak || 0) + (lab.stats.streak === 1 ? " day" : " days"), s: (lab.stats.own || 0) + " of " + (lab.stats.total || 0) + " messages answered on your own" }
                    ]
                    delegate: Card {
                        required property var modelData
                        Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 104
                        ColumnLayout { anchors { fill: parent; margins: 16 } spacing: 2
                            Text { text: modelData.t; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                            Text { text: modelData.v; color: Theme.text; font.family: Theme.serif; font.pixelSize: 28 }
                            Text { text: modelData.s; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    }
                }
            }
            Text { visible: !!lab.stats.gap; text: "You understand more than you can answer yet — that's normal. Replying at level 2 or 3 is what closes the gap."
                   color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }

            // next up
            Card {
                visible: !!lab.recommended.id
                Layout.fillWidth: true; implicitHeight: nextRow.implicitHeight + 36; elevated: true
                RowLayout { id: nextRow; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 20 } spacing: 18
                    ColumnLayout { spacing: 8; Layout.fillWidth: true
                        RowLayout { spacing: 8
                            Text { text: "Next up"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold }
                            Rectangle { implicitWidth: wt.implicitWidth + 16; implicitHeight: 22; radius: 11; color: lab.recommended.why === "Due again" ? Theme.amber : Theme.navActive
                                Text { id: wt; anchors.centerIn: parent; text: lab.recommended.why || ""; color: lab.recommended.why === "Due again" ? "#1F1606" : Theme.text; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold } }
                            Text { text: lab.recommended.category || ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 } }
                        Rectangle { radius: 18; color: Theme.cardElevated; border.color: Theme.border
                            Layout.maximumWidth: nextRow.width - 200
                            implicitWidth: Math.min(nextRow.width - 200, nt.implicitWidth + 32); implicitHeight: nt.implicitHeight + 20
                            Text { id: nt; anchors.centerIn: parent; width: Math.min(implicitWidth, nextRow.width - 232); text: lab.recommended.text || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 20; wrapMode: Text.WordWrap } }
                    }
                    PillButton { text: "Start"; iconName: "message-circle-reply"; Layout.alignment: Qt.AlignRight | Qt.AlignVCenter; onClicked: lab.openMessage(lab.recommended.id) }
                }
            }
            Text { visible: (lab.stats.due || 0) > 0; text: lab.stats.due + (lab.stats.due === 1 ? " message is" : " messages are") + " due again. They come first."
                   color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }

            SectionTitle { text: "Pick a kind of conversation" }
            GridLayout {
                Layout.fillWidth: true
                columns: Math.max(2, Math.floor(width / 250)); columnSpacing: 12; rowSpacing: 12
                Repeater {
                    model: lab.categories
                    delegate: Button {
                        id: catB
                        required property var modelData
                        Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 112
                        onClicked: lab.openCategory(modelData.id)
                        Accessible.name: modelData.title
                        contentItem: ColumnLayout { spacing: 4
                            RowLayout { spacing: 10
                                Rectangle { width: 34; height: 34; radius: 10; color: Theme.navActive
                                    Icon { anchors.centerIn: parent; name: catB.modelData.icon; size: 18; color: Theme.text } }
                                ColumnLayout { spacing: 0; Layout.fillWidth: true
                                    Text { text: catB.modelData.title; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                                    Text { text: catB.modelData.title_es; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 13 } } }
                            Item { Layout.fillHeight: true }
                            RowLayout { spacing: 8; Layout.fillWidth: true
                                Rectangle { Layout.fillWidth: true; height: 6; radius: 3; color: Qt.rgba(1, 1, 1, 0.08)
                                    Rectangle { width: parent.width * (catB.modelData.done / Math.max(1, catB.modelData.count)); height: 6; radius: 3; color: Theme.green } }
                                Text { text: catB.modelData.done + "/" + catB.modelData.count; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 } }
                        }
                        padding: 14
                        background: Rectangle { radius: 14; color: catB.hovered ? Theme.rowHover : Theme.card; border.color: catB.visualFocus ? Theme.blue : Theme.borderSoft }
                    }
                }
            }
            Text { text: lab.aiReady ? "✨ Replies you write in your own words are checked by ChatGPT." : "Add a ChatGPT key in Settings › ChatGPT checks and replies in your own words get a real check. Without it, you compare with the model replies."
                   color: lab.aiReady ? Theme.text3 : Theme.amber; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true; Layout.topMargin: 6 }
        }
    }

    // =========================================================== A MESSAGE
    Flickable {
        id: cardF
        visible: lp.inCard
        anchors { left: parent.left; right: parent.right; top: head.bottom; bottom: parent.bottom; topMargin: 14 }
        contentWidth: width; contentHeight: cardCol.implicitHeight + 60; clip: true; boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar {}
        function toEnd() { Qt.callLater(function() { cardF.contentY = Math.max(0, cardF.contentHeight - cardF.height) }) }
        ColumnLayout {
            id: cardCol
            x: Math.max(32, (parent.width - 860) / 2); width: Math.min(860, parent.width - 64); spacing: 14
            onImplicitHeightChanged: if (lp.c.step !== "meaning") cardF.toEnd()

            // ---- the chat ----
            Card {
                Layout.fillWidth: true; implicitHeight: chat.implicitHeight + 32
                ColumnLayout { id: chat; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 } spacing: 12
                    RowLayout { spacing: 12
                        Avatar { who: lp.c.contact || ({}) }
                        ColumnLayout { spacing: 0
                            Text { text: (lp.c.contact || {}).name || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold }
                            Text { text: [((lp.c.contact || {}).label || ""), lp.c.category || ""].filter(function(x) { return x }).join(" · "); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 } }
                        Item { Layout.fillWidth: true }
                        Text { text: lp.c.time || ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                    }
                    Bubble { text: lp.c.texting || ""; say: lp.c.standard || ""
                             sub: (lp.c.meaningResult && lp.c.meaningResult.correct) || lp.c.step === "breakdown" || lp.c.step === "transfer" || lp.c.step === "done" ? (lp.c.meaningResult.en || lp.c.en || "") : "" }
                    Bubble { visible: !!(lp.c.result && lp.c.result.text) || !!(lp.c.result && lp.c.result.kind === "tiles" && lp.c.result.correct)
                             mine: true; text: lp.c.result ? (lp.c.result.text || (lp.c.result.kind === "tiles" ? lp.c.result.model : "")) : ""
                             sub: lp.c.result && lp.c.result.spoken ? "🎙 said aloud" : "" }
                }
            }

            // ---- step 1: meaning ----
            Card {
                visible: lp.c.step === "meaning"
                Layout.fillWidth: true; implicitHeight: mcol.implicitHeight + 40
                ColumnLayout { id: mcol; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 } spacing: 10
                    Text { text: "What does " + ((lp.c.contact || {}).name || "she") + " mean?"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
                    Hint { text: "Read it first. Press ▶ to hear it, or the snail to hear it slowly." }
                    Repeater {
                        model: lp.c.meaningOptions || []
                        delegate: OptionButton {
                            required property var modelData
                            required property int index
                            Layout.fillWidth: true
                            text: modelData
                            keyHint: String(index + 1)
                            readonly property var mr: lp.c.meaningResult || ({})
                            result: mr.picked === undefined ? "" : (index === mr.answer && mr.correct ? "correct" : (index === mr.picked && !mr.correct ? "wrong" : (mr.correct ? "dim" : "")))
                            enabled: !(mr.correct)
                            onClicked: lab.answerMeaning(index)
                        }
                    }
                    Text { visible: !!(lp.c.meaningResult && lp.c.meaningResult.picked !== undefined && !lp.c.meaningResult.correct); text: "Not quite — read it again and try another."
                           color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14 }
                    RowLayout { visible: !!(lp.c.meaningResult && lp.c.meaningResult.correct); spacing: 10
                        Text { text: lp.c.meaningResult && lp.c.meaningResult.firstTry ? "✓ Got it first try." : "✓ That's it."; color: Theme.green; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold }
                        Item { Layout.fillWidth: true }
                        PillButton { text: "Now reply"; iconName: "chevron-right"; onClicked: lab.toRespond() } }
                }
            }

            // ---- step 2: what would you say? ----
            Card {
                visible: lp.c.step === "respond"
                Layout.fillWidth: true; implicitHeight: rcol.implicitHeight + 40
                ColumnLayout { id: rcol; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 } spacing: 12
                    readonly property var res: lp.c.result || ({})
                    readonly property int lvl: lp.c.level || 1
                    RowLayout { Layout.fillWidth: true; spacing: 12
                        Text { text: "What would you say?"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
                        Text { text: "¿Qué le contestarías?"; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 16 }
                        Item { Layout.fillWidth: true }
                    }
                    // level picker
                    RowLayout { spacing: 6
                        Repeater {
                            model: [{ n: 1, t: "1 · Guided", s: "arrange the words" }, { n: 2, t: "2 · Assisted", s: "type or say it" }, { n: 3, t: "3 · On your own", s: "just reply" }]
                            delegate: Button {
                                required property var modelData
                                padding: 8; leftPadding: 14; rightPadding: 14
                                enabled: !rcol.res.final && !lp.c.checking
                                onClicked: { lab.setLevel(modelData.n); lp.placed = [] }
                                Accessible.name: "Level " + modelData.t
                                contentItem: Column { spacing: 0
                                    Text { text: modelData.t; color: rcol.lvl === modelData.n ? Theme.onBlue : Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold }
                                    Text { text: modelData.s; color: rcol.lvl === modelData.n ? Qt.rgba(1, 1, 1, 0.8) : Theme.text3; font.family: Theme.sans; font.pixelSize: 11 } }
                                background: Rectangle { radius: 12; color: rcol.lvl === modelData.n ? Theme.blue : (parent.hovered ? Theme.rowHover : Qt.rgba(1, 1, 1, 0.04)); border.color: rcol.lvl === modelData.n ? "transparent" : Theme.border; opacity: parent.enabled || rcol.lvl === modelData.n ? 1 : 0.5 }
                            }
                        }
                    }
                    // the goal (levels 1–2)
                    Rectangle {
                        visible: rcol.lvl < 3
                        Layout.fillWidth: true; implicitHeight: goal.implicitHeight + 22; radius: 12
                        color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.1); border.color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.35)
                        RowLayout { id: goal; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 14 } spacing: 10
                            Icon { name: "target"; size: 18; color: Theme.blue }
                            Text { text: lp.c.intent || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    }
                    Hint { visible: rcol.lvl === 3 && !rcol.res.verdict; text: "Answer however you'd really answer. Short is fine. Any natural reply counts." }

                    // level 1: tiles
                    ColumnLayout {
                        visible: rcol.lvl === 1
                        spacing: 10; Layout.fillWidth: true
                        Rectangle {
                            Layout.fillWidth: true; implicitHeight: Math.max(64, pf.implicitHeight + 20); radius: 12; color: Qt.rgba(1, 1, 1, 0.03)
                            border.color: rcol.res.correct ? Theme.green : (rcol.res.final ? Theme.amber : Theme.border); border.width: rcol.res.final ? 2 : 1
                            Flow { id: pf; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 10 } spacing: 8
                                Repeater { model: lp.placed
                                    delegate: Button { required property var modelData; text: lp.c.tiles[modelData]; enabled: !rcol.res.final; padding: 10
                                        onClicked: { var p = lp.placed.slice(); p.splice(p.indexOf(modelData), 1); lp.placed = p }
                                        contentItem: Text { text: parent.text; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19 }
                                        background: Rectangle { radius: 10; color: Theme.navActive } } }
                                Text { visible: lp.placed.length === 0; text: "Tap the words in order"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14; height: 40; verticalAlignment: Text.AlignVCenter } }
                        }
                        Flow { Layout.fillWidth: true; spacing: 8
                            Repeater { model: lp.c.tiles || []
                                delegate: Button { required property var modelData; required property int index
                                    visible: lp.placed.indexOf(index) < 0; enabled: !rcol.res.final; padding: 10; text: modelData
                                    onClicked: { var p = lp.placed.slice(); p.push(index); lp.placed = p }
                                    contentItem: Text { text: parent.text; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19 }
                                    background: Rectangle { radius: 10; color: parent.hovered ? Theme.rowHover : Theme.cardElevated; border.color: Theme.border } } } }
                        RowLayout { visible: !rcol.res.final; spacing: 10
                            PillButton { text: "Check"; iconName: "check"; enabled: lp.placed.length > 0
                                onClicked: { var w = lp.placed.map(function(i) { return lp.c.tiles[i] }); var r = lab.submitTiles(w); if (!r.correct && !r.final) lp.placed = [] } }
                            PillButton { text: "Clear"; primary: false; enabled: lp.placed.length > 0; onClicked: lp.placed = [] } }
                        Text { visible: rcol.res.kind === "tiles" && !rcol.res.correct && !rcol.res.final; text: "Not that order. One more try."; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14 }
                    }

                    // levels 2–3: type or say
                    ReplyField { id: rfield; visible: rcol.lvl >= 2 && !rcol.res.final && rcol.res.verdict !== "compare"; kind: "respond"; onSubmit: (t) => lab.submitText(t, false) }
                    MicStatus { kind: "respond"; visible: rcol.lvl >= 2 && !rcol.res.final && text !== "" }
                    // hints (level 2)
                    ColumnLayout { visible: rcol.lvl === 2 && !rcol.res.final; spacing: 4; Layout.fillWidth: true
                        Repeater { model: lp.c.hintsShown || []
                            delegate: Text { required property var modelData; text: "💡 " + modelData; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    }

                    Verdict { r: rcol.res }
                    // no ChatGPT: compare yourself
                    ColumnLayout { visible: rcol.res.verdict === "compare" && !rcol.res.final; spacing: 8; Layout.fillWidth: true
                        Hint { text: "Habla can only check replies it knows. Does yours say the same thing as the model reply, in correct Spanish?" }
                        RowLayout { spacing: 10
                            PillButton { text: "Mine matches"; iconName: "check"; onClicked: lab.selfReview(true) }
                            PillButton { text: "Mine was different"; primary: false; onClicked: lab.selfReview(false) }
                            PillButton { text: "Try again"; primary: false; iconName: "rotate-ccw"; onClicked: lab.retry() } } }

                    RowLayout { spacing: 10; Layout.fillWidth: true
                        visible: !rcol.res.final && rcol.res.verdict !== "compare" && rcol.res.verdict !== "checking"
                        PillButton { visible: rcol.lvl === 2 && (lp.c.hintsLeft || 0) > 0; text: "Hint"; iconName: "lightbulb"; primary: false; onClicked: lab.hint() }
                        Item { Layout.fillWidth: true }
                        PillButton { text: "Show me"; iconName: "eye"; primary: false; onClicked: lab.giveUp() } }

                    // after the reply
                    RateBox { visible: rcol.res.final === true; phrase: rcol.res.correct && rcol.res.text ? (rcol.res.corrected || rcol.res.text) : (rcol.res.natural || rcol.res.model || ""); step: "respond" }
                    RowLayout { visible: rcol.res.final === true; spacing: 10; Layout.fillWidth: true
                        PillButton { visible: rcol.res.spoken === true && audio.hasRecording && lp.rated === ""; text: "Hear my take"; iconName: "play"; primary: false; onClicked: audio.playRecording() }
                        PillButton { visible: !rcol.res.correct; text: "Try again"; iconName: "rotate-ccw"; primary: false; onClicked: { lp.placed = []; lab.retry() } }
                        Item { Layout.fillWidth: true }
                        PillButton { text: "See the breakdown"; iconName: "chevron-right"; onClicked: { lp.rated = ""; lab.toBreakdown() } } }
                }
            }

            // ---- step 3: breakdown ----
            Card {
                visible: lp.c.step === "breakdown" || lp.c.step === "transfer" || lp.c.step === "done"
                Layout.fillWidth: true; implicitHeight: bcolm.implicitHeight + 40
                ColumnLayout { id: bcolm; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 } spacing: 12
                    Text { text: "The breakdown"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
                    Text { text: lp.c.en || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Flow { Layout.fillWidth: true; spacing: 8
                        Repeater { model: lp.c.breakdown || []
                            delegate: Rectangle { required property var modelData
                                width: bk.implicitWidth + 24; height: bk.implicitHeight + 16; radius: 10; color: Qt.rgba(1, 1, 1, 0.04); border.color: Theme.border
                                id: chip
                                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: app.say(chip.modelData.es, true) }
                                Column { id: bk; anchors.centerIn: parent; spacing: 2
                                    Text { text: chip.modelData.es; color: Theme.spanishAccent; font.family: Theme.serif; font.pixelSize: 18; anchors.horizontalCenter: parent.horizontalCenter }
                                    Text { text: chip.modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12; anchors.horizontalCenter: parent.horizontalCenter } } } } }
                    Repeater { model: lp.c.notes || []
                        delegate: RowLayout { required property var modelData; spacing: 8; Layout.fillWidth: true
                            Icon { name: "book-open"; size: 16; color: Theme.blue; Layout.alignment: Qt.AlignTop; Layout.topMargin: 2 }
                            Text { text: modelData; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true } } }
                    Rectangle { Layout.fillWidth: true; implicitHeight: rd.implicitHeight + 20; radius: 12; color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.08); border.color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.35)
                        ColumnLayout { id: rd; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 } spacing: 2
                            Text { text: "What it might mean"; color: Theme.amber; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.Bold }
                            Text { text: lp.c.reading || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true } } }
                    SectionTitle { text: "Ways to answer" }
                    Repeater { model: lp.c.replies || []
                        delegate: RowLayout { required property var modelData; spacing: 10; Layout.fillWidth: true
                            Rectangle { implicitWidth: 78; implicitHeight: 24; radius: 12; color: Theme.navActive; Layout.alignment: Qt.AlignTop; Layout.topMargin: 3
                                Text { anchors.centerIn: parent; text: modelData.tone; color: Theme.text; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold } }
                            ColumnLayout { spacing: 0; Layout.fillWidth: true
                                Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                Text { text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                            SayButton { phrase: modelData.es; size: 32 }
                            SayButton { phrase: modelData.es; slow: true; size: 32; tint: Qt.rgba(1, 1, 1, 0.12) } } }
                    Hint { text: lp.c.tones || "" }
                    RowLayout { visible: lp.c.step === "breakdown"; Layout.fillWidth: true
                        Item { Layout.fillWidth: true }
                        PillButton { text: "Use it somewhere new"; iconName: "chevron-right"; onClicked: { lp.rated = ""; lab.toTransfer() } } }
                }
            }

            // ---- step 4: same pattern, new situation ----
            Card {
                visible: lp.c.step === "transfer" || lp.c.step === "done"
                Layout.fillWidth: true; implicitHeight: tcol.implicitHeight + 40
                ColumnLayout { id: tcol; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 } spacing: 12
                    readonly property var tres: lp.c.transferResult || ({})
                    readonly property var tw: (lp.c.transfer || {}).contact || ({})
                    Text { text: "Same pattern, new situation"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
                    RowLayout { spacing: 12
                        Avatar { who: tcol.tw }
                        ColumnLayout { spacing: 0
                            Text { text: tcol.tw.name || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold }
                            Text { text: tcol.tw.label || ""; visible: text !== ""; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 } } }
                    Bubble { text: (lp.c.transfer || {}).es || ""; say: (lp.c.transfer || {}).es || ""; sub: tcol.tres.final ? (tcol.tres.en || "") : "" }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: tg.implicitHeight + 22; radius: 12
                        color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.1); border.color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.35)
                        RowLayout { id: tg; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 14 } spacing: 10
                            Icon { name: "target"; size: 18; color: Theme.blue }
                            Text { text: (lp.c.transfer || {}).intent || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true } } }
                    Bubble { visible: !!tcol.tres.text; mine: true; text: tcol.tres.text || ""; sub: tcol.tres.spoken ? "🎙 said aloud" : "" }
                    ReplyField { visible: !tcol.tres.final && tcol.tres.verdict !== "compare"; kind: "transfer"; onSubmit: (t) => lab.submitTransfer(t, false) }
                    MicStatus { kind: "transfer"; visible: !tcol.tres.final && text !== "" }
                    Verdict { r: tcol.tres }
                    RowLayout { visible: tcol.tres.verdict === "compare" && !tcol.tres.final; spacing: 10
                        PillButton { text: "Mine matches"; iconName: "check"; onClicked: lab.selfReview(true) }
                        PillButton { text: "Mine was different"; primary: false; onClicked: lab.selfReview(false) } }
                    RateBox { visible: tcol.tres.final === true && lp.c.step === "transfer"; phrase: tcol.tres.correct && tcol.tres.text ? (tcol.tres.corrected || tcol.tres.text) : (tcol.tres.natural || tcol.tres.model || ""); step: "transfer" }
                    RowLayout { spacing: 10; Layout.fillWidth: true; visible: lp.c.step === "transfer"
                        PillButton { visible: !tcol.tres.final && tcol.tres.verdict !== "checking"; text: "Show me"; iconName: "eye"; primary: false; onClicked: lab.showTransferAnswer() }
                        PillButton { visible: tcol.tres.final === true && tcol.tres.spoken === true && audio.hasRecording && lp.rated === ""; text: "Hear my take"; iconName: "play"; primary: false; onClicked: audio.playRecording() }
                        Item { Layout.fillWidth: true }
                        PillButton { visible: tcol.tres.final === true; text: "Finish"; iconName: "check"; onClicked: { lp.rated = ""; lab.finish() } } }
                }
            }

            // ---- done ----
            Card {
                visible: lp.c.step === "done"
                Layout.fillWidth: true; implicitHeight: dcol.implicitHeight + 40; elevated: true
                ColumnLayout { id: dcol; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 } spacing: 10
                    Text { text: "¡Listo!"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 28 }
                    Repeater {
                        model: [
                            { ok: !!(lp.c.meaningResult && lp.c.meaningResult.firstTry), t: "Understood it" + ((lp.c.meaningResult && lp.c.meaningResult.firstTry) ? " first try" : " (on a second look)") },
                            { ok: !!(lp.c.result && lp.c.result.correct), t: "Replied" + (lp.c.result && lp.c.result.correct ? " at level " + (lp.c.level || 1) + ((lp.c.hintsShown || []).length ? " with a hint" : "") : " — this one comes back soon") },
                            { ok: !!(lp.c.transferResult && lp.c.transferResult.correct), t: "Used it with someone new" }
                        ]
                        delegate: RowLayout { required property var modelData; spacing: 10
                            Icon { name: modelData.ok ? "circle-check" : "circle-alert"; size: 20; color: modelData.ok ? Theme.green : Theme.amber }
                            Text { text: modelData.t; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15 } } }
                    RowLayout { spacing: 10; Layout.topMargin: 6
                        PillButton { text: "Next message"; iconName: "message-circle-reply"; onClicked: { lp.placed = []; lab.nextMessage() } }
                        PillButton { text: "Back to the Lab"; primary: false; onClicked: lab.close() } }
                }
            }
        }
    }

    // =========================================================== DECODER
    RowLayout {
        visible: !lp.inCard && lp.tab === "decoder"
        anchors { left: parent.left; right: parent.right; top: head.bottom; bottom: parent.bottom; leftMargin: 32; rightMargin: 32; topMargin: 16; bottomMargin: 24 }
        spacing: 18
        Card {
            Layout.preferredWidth: 270; Layout.fillHeight: true
            ListView {
                id: decList
                anchors.fill: parent; anchors.margins: 8
                clip: true; spacing: 2; model: lab.decoder
                ScrollBar.vertical: ScrollBar {}
                currentIndex: 0
                delegate: Button {
                    required property var modelData
                    required property int index
                    width: decList.width - 8; implicitHeight: 52
                    onClicked: { decList.currentIndex = index; lp.decListen = ({}); lab.clearDecoder() }
                    contentItem: Column { spacing: 1
                        Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17 }
                        Text { text: modelData.en; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; elide: Text.ElideRight; width: parent.width } }
                    background: Rectangle { radius: 10; color: decList.currentIndex === index ? Theme.navActive : (parent.hovered ? Theme.rowHover : "transparent") }
                }
            }
        }
        Flickable {
            Layout.fillWidth: true; Layout.fillHeight: true
            contentWidth: width; contentHeight: dd.implicitHeight + 30; clip: true; boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {}
            ColumnLayout {
                id: dd
                width: Math.min(parent.width, 780); spacing: 14
                readonly property var d: lab.decoder[decList.currentIndex] || ({})
                onDChanged: lp.decId = d.id || ""
                RowLayout { spacing: 12
                    Text { text: dd.d.es || ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 36 }
                    SayButton { phrase: dd.d.es || ""; size: 38 }
                    SayButton { phrase: dd.d.es || ""; slow: true; size: 38; tint: Qt.rgba(1, 1, 1, 0.12) }
                    Rectangle { implicitWidth: rg.implicitWidth + 18; implicitHeight: 26; radius: 13; color: Theme.navActive
                        Text { id: rg; anchors.centerIn: parent; text: dd.d.register || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Bold } } }
                Text { text: dd.d.en || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Text { visible: !!dd.d.literal; text: "Literally: " + (dd.d.literal || ""); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14; font.italic: true }
                Hint { text: dd.d.usage || "" }
                Text { visible: !!dd.d.caution; text: "⚠️ " + (dd.d.caution || ""); color: Theme.amber; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }

                SectionTitle { text: "How it sounds in a chat" }
                Repeater { model: dd.d.examples || []
                    delegate: Card { required property var modelData; Layout.fillWidth: true; implicitHeight: exc.implicitHeight + 24
                        ColumnLayout { id: exc; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 } spacing: 8
                            Repeater { model: modelData
                                delegate: Bubble { required property var modelData; mine: modelData.who === "b"; text: modelData.es; sub: modelData.en; say: modelData.es } } } } }

                SectionTitle { text: "Listen: what does it mean?" }
                RowLayout { spacing: 10
                    PillButton { text: "Play"; iconName: "volume-2"; onClicked: app.say((dd.d.listen || {}).es, false) }
                    PillButton { text: "Slowly"; iconName: "snail"; primary: false; onClicked: app.say((dd.d.listen || {}).es, true) }
                    Text { visible: lp.decListen.answer !== undefined; text: "“" + ((dd.d.listen || {}).es || "") + "”"; color: Theme.spanishAccent; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                Repeater { model: (dd.d.listen || {}).options || []
                    delegate: OptionButton { required property var modelData; required property int index
                        Layout.fillWidth: true; text: modelData
                        result: lp.decListen.answer === undefined ? "" : (index === lp.decListen.answer ? "correct" : (index === lp.decListen.picked ? "wrong" : "dim"))
                        enabled: lp.decListen.answer === undefined
                        onClicked: { var r = lab.decoderListen(dd.d.id, index); lp.decListen = { answer: r.answer, picked: index } } } }

                SectionTitle { text: "Your turn" }
                Bubble { text: (dd.d.respond || {}).incoming_es || ""; sub: (dd.d.respond || {}).incoming_en || ""; say: (dd.d.respond || {}).incoming_es || "" }
                Rectangle {
                    Layout.fillWidth: true; implicitHeight: dg.implicitHeight + 22; radius: 12
                    color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.1); border.color: Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.35)
                    RowLayout { id: dg; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 14 } spacing: 10
                        Icon { name: "target"; size: 18; color: Theme.blue }
                        Text { text: (dd.d.respond || {}).intent || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true } } }
                Bubble { visible: !!lab.decoderResult.text; mine: true; text: lab.decoderResult.text || "" }
                ReplyField { visible: !lab.decoderResult.final && lab.decoderResult.verdict !== "compare" && lab.decoderResult.verdict !== "checking"; kind: "decoder"; onSubmit: (t) => lab.decoderRespond(dd.d.id, t) }
                MicStatus { kind: "decoder"; visible: text !== "" && !lab.decoderResult.final }
                Verdict { r: lab.decoderResult }
                RowLayout { visible: !!lab.decoderResult.verdict && lab.decoderResult.verdict !== "checking"; spacing: 10
                    PillButton { text: "Try again"; iconName: "rotate-ccw"; primary: false; onClicked: lab.clearDecoder() }
                    PillButton { text: "Next expression"; iconName: "chevron-right"
                        onClicked: { decList.currentIndex = Math.min(decList.count - 1, decList.currentIndex + 1); lp.decListen = ({}); lab.clearDecoder() } } }
            }
        }
    }

    // =========================================================== TEXTING
    Flickable {
        visible: !lp.inCard && lp.tab === "texting"
        anchors { left: parent.left; right: parent.right; top: head.bottom; bottom: parent.bottom; topMargin: 16 }
        contentWidth: width; contentHeight: txCol.implicitHeight + 40; clip: true; boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar {}
        ColumnLayout {
            id: txCol
            x: 32; width: Math.min(parent.width - 64, 900); spacing: 12
            Hint { text: "Casual texts often skip ¿ ¡ and accents, and shorten words. You'll see these a lot. You never have to use them yourself — and in anything formal, write the words out." }
            Repeater { model: lab.texting
                delegate: Card { required property var modelData; Layout.fillWidth: true; implicitHeight: tr.implicitHeight + 28
                    RowLayout { id: tr; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 16 } spacing: 18
                        ColumnLayout { Layout.preferredWidth: 180; Layout.minimumWidth: 180; Layout.maximumWidth: 180; spacing: 2
                            Text { text: modelData.text; color: Theme.spanishAccent; font.family: Theme.sans; font.pixelSize: 26; font.weight: Font.Bold }
                            Text { text: "= " + modelData.standard; color: Theme.text; font.family: Theme.serif; font.pixelSize: 16 }
                            Text { text: modelData.en; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                        ColumnLayout { Layout.fillWidth: true; spacing: 3
                            RowLayout { spacing: 8
                                Text { text: "“" + modelData.example + "”"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18 }
                                Text { text: "→"; color: Theme.text3; font.pixelSize: 16 }
                                Text { text: modelData.example_standard; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                SayButton { phrase: modelData.example_standard; size: 30 } }
                            Text { text: modelData.example_en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                            Text { text: modelData.note; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    } } }
        }
    }
}
