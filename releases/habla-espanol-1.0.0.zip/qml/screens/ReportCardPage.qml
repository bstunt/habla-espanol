import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Dialogs
import QtCore
import "../components"

// Weekly report card, school style. The paper card is what gets exported as a JPG.
Item {
    id: rp
    property int offset: 0
    property string lang: "en"
    property var r: app ? app.reportCard(offset, lang) : ({})
    property string saved: ""
    Connections { target: app; function onLibraryChanged() { rp.r = app.reportCard(rp.offset, rp.lang) } }
    onOffsetChanged: { r = app.reportCard(offset, lang); saved = "" }
    onLangChanged: { r = app.reportCard(offset, lang); saved = "" }
    readonly property var lb: r.labels || ({})

    // paper palette: fixed so the exported card looks the same in every theme
    readonly property color ink: "#1F2A44"
    readonly property color ink2: "#55607A"
    readonly property color red: "#C8323C"
    readonly property color paperC: "#FBF6EA"
    readonly property color rule: "#D9CFBC"
    readonly property color trim: "#1E5FA8"
    readonly property color trim2: "#E8A33B"

    function gradeColor(g) {
        if (g === "I") return ink2
        var c = g.charAt(0)
        return c === "A" ? "#2E8F5E" : (c === "B" ? "#1E5FA8" : (c === "C" ? "#B7791F" : red))
    }

    Flickable {
        id: fl
        anchors.fill: parent
        contentWidth: width
        contentHeight: col.implicitHeight + 60
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: fl.contentHeight > fl.height ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }

        ColumnLayout {
            id: col
            x: 32; y: 30; width: fl.width - 64
            spacing: 18

            // ---------- header + controls ----------
            RowLayout {
                Layout.fillWidth: true; spacing: 14
                ColumnLayout { spacing: 4; Layout.fillWidth: true
                    RowLayout { spacing: 14
                        Text { text: "Report card"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 36; Accessible.role: Accessible.Heading }
                        Text { text: "Boleta"; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 22; Layout.alignment: Qt.AlignBaseline } }
                    Text { text: "Your last 7 days graded like school, from your own answers. Subjects without enough work get an I (incomplete) instead of a guess."
                           color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                PillButton { text: "Back to Progress"; primary: false; iconName: "arrow-left"; onClicked: app.goTo("progreso") }
            }
            RowLayout {
                Layout.fillWidth: true; spacing: 12
                IconButton { iconName: "chevron-left"; label: "Previous week"; iconColor: Theme.text; enabled: !!rp.r.hasEarlier; opacity: enabled ? 1 : 0.35; onClicked: rp.offset -= 1 }
                Text { text: rp.r.weekLabel || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold
                       Layout.preferredWidth: 230; horizontalAlignment: Text.AlignHCenter }
                IconButton { iconName: "chevron-right"; label: "Next week"; iconColor: Theme.text; enabled: rp.offset < 0; opacity: enabled ? 1 : 0.35; onClicked: rp.offset += 1 }
                Text { visible: rp.offset === 0; text: "Last 7 days"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                Item { Layout.fillWidth: true }
                // language
                Rectangle {
                    implicitWidth: lg.implicitWidth + 8; implicitHeight: 40; radius: 20; color: Qt.rgba(1, 1, 1, 0.05); border.color: Theme.border
                    Row { id: lg; anchors.centerIn: parent; spacing: 4
                        Repeater { model: [{ k: "en", t: "English" }, { k: "es", t: "Español" }]
                            delegate: Rectangle {
                                required property var modelData
                                width: lt.implicitWidth + 30; height: 32; radius: 16
                                color: rp.lang === modelData.k ? Theme.blue : (lm.containsMouse ? Theme.rowHover : "transparent")
                                Text { id: lt; anchors.centerIn: parent; text: modelData.t; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold
                                       color: rp.lang === modelData.k ? Theme.onBlue : Theme.text2 }
                                MouseArea { id: lm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: rp.lang = modelData.k }
                                Accessible.role: Accessible.RadioButton; Accessible.name: modelData.t; Accessible.checked: rp.lang === modelData.k
                            } } }
                }
                PillButton { text: "Export JPG"; iconName: "download"; onClicked: saveDlg.open() }
            }
            Text { visible: rp.saved !== ""; text: "Saved to " + rp.saved; color: Theme.green; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WrapAnywhere; Layout.fillWidth: true }

            // ---------- the paper card (scaled to fit, exported at full size) ----------
            Item {
                Layout.fillWidth: true
                readonly property real k: Math.min(1, width / card.width)
                implicitHeight: card.height * k
                Rectangle {
                    id: card
                    width: 920
                    height: paperCol.implicitHeight + 92
                    transformOrigin: Item.TopLeft
                    scale: parent.k
                    x: (parent.width - width * parent.k) / 2
                    color: rp.paperC
                    radius: 6
                    // double school border with a talavera-blue and marigold trim
                    Rectangle { anchors.fill: parent; anchors.margins: 14; color: "transparent"; border.color: rp.trim; border.width: 3; radius: 3 }
                    Rectangle { anchors.fill: parent; anchors.margins: 21; color: "transparent"; border.color: rp.trim2; border.width: 1.5; radius: 2 }
                    Repeater {   // corner tiles
                        model: 4
                        delegate: Rectangle {
                            required property int index
                            width: 22; height: 22; rotation: 45; color: rp.trim
                            x: index % 2 === 0 ? 3 : card.width - 25; y: index < 2 ? 3 : card.height - 25
                            Rectangle { anchors.centerIn: parent; width: 9; height: 9; color: rp.trim2 }
                        }
                    }

                    ColumnLayout {
                        id: paperCol
                        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 52; rightMargin: 52; topMargin: 46 }
                        spacing: 16

                        // header
                        RowLayout {
                            Layout.fillWidth: true; spacing: 18
                            ColumnLayout { spacing: 0; Layout.fillWidth: true
                                Text { text: "Habla"; color: rp.ink; font.family: Theme.script; font.pixelSize: 46 }
                                Text { text: rp.lb.school || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 13; font.letterSpacing: 0.5 } }
                            ColumnLayout { spacing: 2; Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                                Text { text: (rp.lb.title || "").toUpperCase(); color: rp.ink; font.family: Theme.serif; font.pixelSize: 28; font.letterSpacing: 2; Layout.alignment: Qt.AlignRight }
                                Text { text: rp.r.weekLabel || ""; color: rp.ink2; font.family: Theme.serif; font.italic: true; font.pixelSize: 15; Layout.alignment: Qt.AlignRight } }
                        }
                        Rectangle { Layout.fillWidth: true; height: 2; color: rp.ink }

                        // student line
                        RowLayout {
                            Layout.fillWidth: true; spacing: 30
                            Repeater {
                                model: [[rp.lb.student, rp.r.student], [rp.lb.level, rp.r.levelValue]]
                                delegate: RowLayout {
                                    required property var modelData
                                    spacing: 8
                                    Text { text: (modelData[0] || "") + ":"; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 13 }
                                    Text { text: modelData[1] || ""; color: rp.ink; font.family: Theme.serif; font.pixelSize: 17; font.weight: Font.DemiBold }
                                }
                            }
                            Item { Layout.fillWidth: true }
                        }

                        // grades table + overall
                        RowLayout {
                            Layout.fillWidth: true; spacing: 22
                            ColumnLayout {
                                Layout.fillWidth: true; spacing: 0
                                RowLayout {
                                    Layout.fillWidth: true; Layout.bottomMargin: 6; spacing: 12
                                    Text { text: rp.lb.subject || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold; font.letterSpacing: 1; Layout.preferredWidth: 190 }
                                    Text { text: rp.lb.grade || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold; font.letterSpacing: 1; Layout.preferredWidth: 64; horizontalAlignment: Text.AlignHCenter }
                                    Text { text: rp.lb.score || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold; font.letterSpacing: 1; Layout.preferredWidth: 50; horizontalAlignment: Text.AlignHCenter }
                                    Text { text: rp.lb.comment || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold; font.letterSpacing: 1; Layout.fillWidth: true }
                                }
                                Repeater {
                                    model: rp.r.subjects || []
                                    delegate: ColumnLayout {
                                        required property var modelData
                                        Layout.fillWidth: true; spacing: 0
                                        Rectangle { Layout.fillWidth: true; height: 1; color: rp.rule }
                                        RowLayout {
                                            Layout.fillWidth: true; Layout.topMargin: 9; Layout.bottomMargin: 9; spacing: 12
                                            Text { text: modelData.name; color: rp.ink; font.family: Theme.serif; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.preferredWidth: 190 }
                                            Item { Layout.preferredWidth: 64; implicitHeight: 40
                                                Rectangle { anchors.centerIn: parent; width: 44; height: 40; radius: 20; color: "transparent"
                                                            border.color: rp.gradeColor(modelData.grade); border.width: 2; rotation: -6; opacity: modelData.graded ? 0.85 : 0.35 }
                                                Text { anchors.centerIn: parent; text: modelData.grade; color: rp.gradeColor(modelData.grade)
                                                       font.family: Theme.script; font.pixelSize: 24 } }
                                            Text { text: modelData.score === null || modelData.score === undefined ? "—" : modelData.score; color: rp.ink
                                                   font.family: Theme.sans; font.pixelSize: 15; Layout.preferredWidth: 50; horizontalAlignment: Text.AlignHCenter }
                                            Text { text: modelData.comment; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                        }
                                    }
                                }
                                Rectangle { Layout.fillWidth: true; height: 1; color: rp.rule }
                            }
                            // overall
                            Rectangle {
                                Layout.preferredWidth: 170; Layout.alignment: Qt.AlignTop; Layout.topMargin: 22
                                implicitHeight: ov.implicitHeight + 34; radius: 8
                                color: "transparent"; border.color: rp.ink; border.width: 2
                                ColumnLayout {
                                    id: ov; anchors { left: parent.left; right: parent.right; top: parent.top; topMargin: 16 } spacing: 2
                                    Text { text: (rp.lb.overall || "").toUpperCase(); color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; font.weight: Font.Bold; font.letterSpacing: 1; Layout.alignment: Qt.AlignHCenter; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; Layout.maximumWidth: 150 }
                                    Text { text: rp.r.overallGrade || "I"; color: rp.gradeColor(rp.r.overallGrade || "I"); font.family: Theme.script; font.pixelSize: 72; Layout.alignment: Qt.AlignHCenter }
                                    Text { visible: rp.r.overallScore !== null && rp.r.overallScore !== undefined; text: (rp.r.overallScore || 0) + " / 100"; color: rp.ink; font.family: Theme.sans; font.pixelSize: 14; Layout.alignment: Qt.AlignHCenter }
                                    Text { visible: rp.r.gpa !== null && rp.r.gpa !== undefined; text: (rp.lb.gpa || "") + " " + Number(rp.r.gpa || 0).toFixed(2); color: rp.ink2; font.family: Theme.sans; font.pixelSize: 13; Layout.alignment: Qt.AlignHCenter }
                                }
                            }
                        }

                        // attendance strip
                        RowLayout {
                            Layout.fillWidth: true; spacing: 10
                            Text { text: (rp.lb.attendance || "") + ":"; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 13 }
                            Repeater {
                                model: rp.r.attendance || []
                                delegate: Column {
                                    required property var modelData
                                    spacing: 2
                                    Rectangle { width: 34; height: 26; radius: 4; color: modelData.on ? "#2E8F5E" : "transparent"; border.color: modelData.on ? "#2E8F5E" : rp.rule; border.width: 1.5
                                        Text { anchors.centerIn: parent; text: modelData.on ? "✓" : ""; color: "white"; font.pixelSize: 14; font.bold: true } }
                                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: modelData.d; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11 }
                                }
                            }
                            Text { text: (rp.lb.minutes || "").replace("{m}", rp.r.minutes || 0); color: rp.ink; font.family: Theme.sans; font.pixelSize: 13; Layout.leftMargin: 8 }
                            Item { Layout.fillWidth: true }
                        }

                        // what we learned
                        Text { text: rp.lb.learned || ""; color: rp.ink; font.family: Theme.serif; font.pixelSize: 21; Layout.topMargin: 4 }
                        Rectangle { Layout.fillWidth: true; height: 1; color: rp.ink }
                        RowLayout {
                            Layout.fillWidth: true; spacing: 30
                            ColumnLayout {
                                Layout.preferredWidth: 1; Layout.fillWidth: true; Layout.alignment: Qt.AlignTop; spacing: 12
                                Repeater {
                                    model: [
                                        { h: rp.lb.days, items: (rp.r.days || []).map(function (d) { return (rp.lang === "es" ? "Día " : "Day ") + d.no + " · " + d.title }) },
                                        { h: rp.lb.basics, items: rp.r.basics || [] },
                                        { h: rp.lb.scen, items: rp.r.scenarios || [] }
                                    ]
                                    delegate: ColumnLayout {
                                        required property var modelData
                                        spacing: 3; Layout.fillWidth: true
                                        Text { text: modelData.h || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Bold; font.letterSpacing: 0.5 }
                                        Text { visible: modelData.items.length === 0; text: "—"; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 14 }
                                        Repeater { model: modelData.items
                                            delegate: Text { required property var modelData; text: "• " + modelData; color: rp.ink; font.family: Theme.serif; font.pixelSize: 15; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                                    }
                                }
                            }
                            ColumnLayout {
                                Layout.preferredWidth: 1.3; Layout.fillWidth: true; Layout.alignment: Qt.AlignTop; spacing: 4
                                Text { text: (rp.lb.phrases || "") + " (" + (rp.r.newPhraseCount || 0) + ")"; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Bold; font.letterSpacing: 0.5 }
                                Text { visible: (rp.r.newPhrases || []).length === 0; text: "—"; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 14 }
                                GridLayout {
                                    columns: 2; columnSpacing: 12; rowSpacing: 3; Layout.fillWidth: true
                                    Repeater { model: rp.r.newPhrases || []
                                        delegate: Text { required property var modelData; Layout.fillWidth: true; Layout.preferredWidth: 1; wrapMode: Text.WordWrap
                                            textFormat: Text.StyledText
                                            text: "<b>" + modelData.es + "</b> <font color='" + rp.ink2 + "'>" + modelData.en + "</font>"
                                            color: rp.ink; font.family: Theme.serif; font.pixelSize: 14 } }
                                }
                                Text { visible: (rp.r.newPhrasesMore || 0) > 0; text: (rp.lb.more || "").replace("{n}", rp.r.newPhrasesMore); color: rp.ink2; font.family: Theme.sans; font.pixelSize: 12 }
                                Text { text: (rp.lb.practiced || "").replace("{n}", rp.r.practicedCount || 0); color: rp.ink2; font.family: Theme.sans; font.pixelSize: 12; Layout.topMargin: 4 }
                            }
                        }

                        // teacher's note
                        Rectangle {
                            Layout.fillWidth: true; Layout.topMargin: 6
                            implicitHeight: nt.implicitHeight + 30; radius: 6; color: "#F3EAD6"; border.color: rp.rule
                            ColumnLayout { id: nt; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 15 } spacing: 6
                                Text { text: rp.lb.note || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Bold; font.letterSpacing: 0.5 }
                                Text { text: rp.r.note || ""; color: rp.ink; font.family: Theme.serif; font.italic: true; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                Text { text: "— " + (rp.lb.sign || ""); color: rp.red; font.family: Theme.script; font.pixelSize: 22; Layout.alignment: Qt.AlignRight } }
                        }
                        Text { text: rp.lb.scale || ""; color: rp.ink2; font.family: Theme.sans; font.pixelSize: 11; Layout.alignment: Qt.AlignHCenter }
                    }
                }
            }
        }
    }

    FileDialog {
        id: saveDlg
        fileMode: FileDialog.SaveFile
        defaultSuffix: "jpg"
        nameFilters: ["JPEG image (*.jpg)"]
        currentFolder: StandardPaths.standardLocations(StandardPaths.PicturesLocation)[0]
        selectedFile: currentFolder + "/" + (rp.r.fileStem || "Habla report card") + ".jpg"
        onAccepted: {
            var path = app.localPath(selectedFile.toString())
            card.grabToImage(function (res) { if (res.saveToFile(path)) rp.saved = path }, Qt.size(card.width * 2, card.height * 2))
        }
    }
}
