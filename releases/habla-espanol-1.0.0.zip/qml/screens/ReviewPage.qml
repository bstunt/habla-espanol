import QtQuick
import QtQuick.Layouts
import "../components"

PageFrame {
    title: "Review"; titleEs: "Repaso"
    subtitle: "Phrases come back just before you'd forget them. Ones you miss come back sooner."
    Card {
        Layout.fillWidth: true; implicitHeight: 170; elevated: true
        RowLayout {
            anchors.fill: parent; anchors.margins: 26; spacing: 22
            Icon { name: "refresh-cw"; color: Theme.amber; size: 44 }
            ColumnLayout { spacing: 6; Layout.fillWidth: true
                Text { text: (app.lib.reviewsDue || 0) > 0 ? app.lib.reviewsDue + (app.lib.reviewsDue === 1 ? " phrase is" : " phrases are") + " due now" : "Nothing due right now"
                       color: Theme.text; font.family: Theme.serif; font.pixelSize: 30 }
                Text { text: (app.lib.reviewsScheduled || 0) === 0 ? "Reviews appear once you've practiced your first phrases."
                             : app.lib.reviewsScheduled + " phrases scheduled" + (app.lib.nextReview ? " · next: " + app.lib.nextReview : "")
                       color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15 } }
            PillButton { text: "Start review"; iconName: "play"; implicitWidth: 200; enabled: (app.lib.reviewsDue || 0) > 0; opacity: enabled ? 1 : 0.45; onClicked: app.startReview() }
        }
    }
    Text { text: "Up next"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold; visible: (app.dash.reviews || []).length > 0 }
    Repeater {
        model: app.dash.reviews || []
        delegate: Rectangle {
            required property var modelData
            Layout.fillWidth: true; height: 58; radius: 12; color: Theme.card; border.color: Theme.borderSoft
            RowLayout {
                anchors.fill: parent; anchors.margins: 10; spacing: 14
                Rectangle { width: 38; height: 38; radius: 9; color: modelData.tint
                    Icon { anchors.centerIn: parent; name: modelData.icon; color: Theme.text; size: 18 } }
                ColumnLayout { spacing: 0; Layout.fillWidth: true
                    Text { text: modelData.concept; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17; Layout.fillWidth: true }
                    Text { text: modelData.practice; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true } }
                Text { text: modelData.due; color: modelData.dueToday ? Theme.coral : Theme.amber; font.family: Theme.sans; font.pixelSize: 14 }
            }
        }
    }

    Text { visible: (app.lib.skippedSpeaking || []).length > 0; Layout.topMargin: 10
           text: "Speaking you skipped"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
    Text { visible: (app.lib.skippedSpeaking || []).length > 0
           text: "You skipped these without a microphone. Once one is connected, say each one and it leaves this list."
           color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    Repeater {
        model: app.lib.skippedSpeaking || []
        delegate: Rectangle {
            required property var modelData
            Layout.fillWidth: true; height: 62; radius: 12; color: Theme.card; border.color: Theme.borderSoft
            RowLayout {
                anchors.fill: parent; anchors.margins: 10; anchors.leftMargin: 14; spacing: 14
                Rectangle { width: 38; height: 38; radius: 9; color: Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.18)
                    Icon { anchors.centerIn: parent; name: "mic"; color: Theme.coral; size: 18 } }
                ColumnLayout { spacing: 0; Layout.fillWidth: true
                    Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: modelData.where; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true } }
                PillButton { text: "Say it"; iconName: "mic"; implicitWidth: 130; implicitHeight: 40; onClicked: app.practiceSkipped(modelData.id) }
            }
        }
    }
}
