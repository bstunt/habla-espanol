import QtQuick
import QtQuick.Layouts
import "../components"

// End-of-session summary: completion, what was demonstrated, what comes back in review.
Rectangle {
    id: sm
    readonly property var s: app.summary
    color: Theme.bg
    ColumnLayout {
        anchors.centerIn: parent
        width: Math.min(parent.width - 80, 760)
        spacing: 18
        Icon { name: "trophy"; color: Theme.amber; size: 54; Layout.alignment: Qt.AlignHCenter }
        Text { text: s.courseDone ? "¡Felicidades! You finished all 30 sessions." : "Session " + s.sessionNo + " complete"; color: Theme.text; font.family: Theme.serif; font.pixelSize: 38; Layout.alignment: Qt.AlignHCenter; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Text { text: s.title + (s.titleEs ? " · " + s.titleEs : ""); color: Theme.text2; font.family: Theme.serif; font.italic: true; font.pixelSize: 19; Layout.alignment: Qt.AlignHCenter }
        Card {
            Layout.fillWidth: true; implicitHeight: col.implicitHeight + 40
            ColumnLayout {
                id: col
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 22 }
                spacing: 10
                Text { visible: s.exitTotal > 0; text: "Final check: " + s.exitCorrect + " of " + s.exitTotal + " on your own"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold }
                Repeater {
                    model: s.objectives || []
                    delegate: RowLayout {
                        required property var modelData
                        spacing: 10
                        Rectangle { width: 20; height: 20; radius: 10
                            color: modelData.state === "demonstrated" ? Theme.green : "transparent"
                            border.color: modelData.state === "pending" ? Qt.rgba(1, 1, 1, 0.35) : Theme.green; border.width: 2
                            Text { anchors.centerIn: parent; visible: modelData.state !== "pending"; text: "✓"; color: modelData.state === "demonstrated" ? Theme.text : Theme.green; font.pixelSize: 11 } }
                        Text { text: modelData.text; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15 }
                        Text { text: "· " + modelData.stateLabel; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                    }
                }
                Text { text: "Finishing a session isn't the same as mastering it. What you found hard comes back in spaced review over the next days."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true; Layout.topMargin: 6 }
            }
        }
        Text {
            visible: s.testPassed === false && !s.courseDone
            text: "One last step: the Day " + s.testDay + " test. 30 questions, and you need 90% (27) to open Day " + s.nextNo + ". You can retake it as often as you like."
            color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; font.weight: Font.DemiBold; wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true
        }
        Text {
            visible: !!s.nextLocked && !!s.testPassed
            text: "Day " + s.nextNo + " (" + s.nextTitle + ") opens tomorrow. Today you can practice Basics or review what you've learned."
            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15; wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true
        }
        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            spacing: 12
            PillButton { text: "Back to Home"; primary: false; onClicked: app.backToDashboard() }
            PillButton { visible: s.testPassed === false; text: "Take the Day " + s.testDay + " test"; iconName: "list-checks"; onClicked: app.startTest(s.testDay) }
            PillButton { visible: !!s.nextAvailable; text: "Start next: " + s.nextTitle; iconName: "play"; onClicked: app.continueSession() }
            PillButton { visible: !!s.nextLocked && !!s.testPassed; text: "Practice Basics"; iconName: "shapes"; onClicked: app.goTo("basicos") }
        }
    }
}
