import QtQuick
import QtQuick.Layouts
import "../components"

// Progress: everything here comes from what you've actually done. Separate measures,
// never combined into one score.
PageFrame {
    id: pp
    readonly property var p: app.lib.progress || ({})
    readonly property var c: p.charts || ({})
    property var week: app ? app.reportCard(0, "en") : ({})
    Connections { target: app; function onLibraryChanged() { pp.week = app.reportCard(0, "en") } }
    title: "Progress"; titleEs: "Progreso"
    subtitle: "Finishing days, practicing, showing a skill on your own and remembering it later are tracked separately. None of it is turned into one score."

    component Legend: ColumnLayout {
        property var items: []
        property bool percent: false
        readonly property real total: { var t = 0; for (var i = 0; i < items.length; i++) t += items[i].value; return t }
        spacing: 7
        Repeater {
            model: parent.items
            delegate: RowLayout {
                required property var modelData
                spacing: 8
                Rectangle { width: 12; height: 12; radius: 3; color: modelData.color }
                Text { text: modelData.label; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true }
                Text { text: parent.parent.percent && parent.parent.total > 0 ? Math.round(modelData.value * 100 / parent.parent.total) + "%" : modelData.value
                       color: Theme.text; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.DemiBold }
            }
        }
    }

    // ---------- headline numbers ----------
    GridLayout {
        Layout.fillWidth: true
        columns: 4; columnSpacing: 14; rowSpacing: 14
        Repeater {
            model: [
                { v: (pp.p.completed || 0) + " / " + (pp.p.total || 30), l: "Days completed" },
                { v: (pp.c.streak || 0) + ((pp.c.streak || 0) === 1 ? " day" : " days"), l: "Current streak" },
                { v: (pp.p.minutes || 0) + " min", l: "Active practice time" },
                { v: (pp.p.demonstrated || 0) + " / " + (pp.p.conceptsTotal || 0), l: "Course phrases shown on your own" }
            ]
            delegate: Card {
                required property var modelData
                Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 104
                ColumnLayout { anchors.fill: parent; anchors.margins: 18; spacing: 4
                    Text { text: modelData.v; color: Theme.text; font.family: Theme.serif; font.pixelSize: 30 }
                    Text { text: modelData.l; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            }
        }
    }

    // ---------- weekly report card ----------
    Card {
        Layout.fillWidth: true
        implicitHeight: 92
        RowLayout {
            anchors.fill: parent; anchors.margins: 18; spacing: 16
            Rectangle { width: 52; height: 52; radius: 13; color: "#FBF6EA"
                Text { anchors.centerIn: parent; text: (pp.week.overallGrade || "I"); color: "#C8323C"; font.family: Theme.script; font.pixelSize: 30 } }
            ColumnLayout { spacing: 2; Layout.fillWidth: true
                Text { text: "Report card · last 7 days"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold }
                Text { text: "Grades for listening, grammar, pronunciation, conversation, memory and attendance, plus what you learned. Export it as a JPG, in English or Spanish."
                       color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            PillButton { text: "Open report card"; primary: false; iconName: "trophy"; onClicked: app.goTo("boleta") }
        }
    }

    // ---------- day tests ----------
    ChartCard {
        id: dtc
        readonly property var ts: pp.p.tests || ({})
        title: "Day tests"
        note: "30 questions at the end of each day. 90% (27) or more to pass."
        Text { visible: (dtc.ts.finished || 0) === 0; text: "Finish a day to take its test. Your scores will show up here."
               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }
        GridLayout {
            visible: (dtc.ts.finished || 0) > 0
            Layout.fillWidth: true; columns: 4; columnSpacing: 12; rowSpacing: 12
            Repeater {
                model: [
                    { v: (dtc.ts.passed || 0) + " / " + (dtc.ts.finished || 0), l: "Tests passed" },
                    { v: (dtc.ts.firstTry || 0) + " / " + (dtc.ts.taken || 0), l: "Passed on the first try" },
                    { v: dtc.ts.avgBest === null || dtc.ts.avgBest === undefined ? "—" : dtc.ts.avgBest + "%", l: "Average best score" },
                    { v: String(dtc.ts.attempts || 0), l: "Tests taken (with retakes)" }
                ]
                delegate: Rectangle {
                    required property var modelData
                    Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 74; radius: 12
                    color: Qt.rgba(1, 1, 1, 0.03); border.color: Theme.borderSoft
                    ColumnLayout { anchors.fill: parent; anchors.margins: 12; spacing: 2
                        Text { text: modelData.v; color: Theme.text; font.family: Theme.serif; font.pixelSize: 24 }
                        Text { text: modelData.l; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                }
            }
        }
        // best score per day, with the 90% line
        Item {
            visible: (dtc.ts.finished || 0) > 0
            Layout.fillWidth: true; implicitHeight: 190; Layout.topMargin: 6
            readonly property real plotH: 140
            Rectangle {   // 90% pass line
                x: 0; width: parent.width; height: 1; y: 18 + parent.plotH * 0.1
                color: Theme.green; opacity: 0.6
            }
            Text { x: parent.width - width; y: 18 + parent.plotH * 0.1 - 16; text: "90% to pass"; color: Theme.green; font.family: Theme.sans; font.pixelSize: 11 }
            Row {
                x: 0; y: 0; height: parent.height; spacing: 10
                Repeater {
                    model: dtc.ts.days || []
                    delegate: Column {
                        required property var modelData
                        width: 40; spacing: 4
                        Text { width: parent.width; horizontalAlignment: Text.AlignHCenter; height: 14
                               text: modelData.taken ? modelData.pct + "%" : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 11 }
                        Item { width: parent.width; height: 140
                            Rectangle { anchors.fill: parent; radius: 6; color: Qt.rgba(1, 1, 1, 0.05); border.color: modelData.taken ? "transparent" : Theme.border }
                            Rectangle { anchors.bottom: parent.bottom; width: parent.width; radius: 6
                                height: parent.height * (modelData.pct / 100)
                                color: modelData.passed ? Theme.green : Theme.amber } }
                        Text { width: parent.width; horizontalAlignment: Text.AlignHCenter; text: "D" + modelData.day; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 11 }
                        Text { width: parent.width; horizontalAlignment: Text.AlignHCenter
                               text: !modelData.taken ? "not yet" : (modelData.attempts === 1 ? "1 try" : modelData.attempts + " tries")
                               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 10 }
                        Accessible.role: Accessible.StaticText
                        Accessible.name: "Day " + modelData.day + ": " + (modelData.taken ? modelData.pct + " percent best, " + modelData.attempts + " tries" + (modelData.passed ? ", passed" : ", not passed") : "not taken")
                    }
                }
            }
        }
        // where test points are lost
        RowLayout {
            visible: (dtc.ts.taken || 0) > 0
            Layout.fillWidth: true; spacing: 20
            Repeater {
                model: dtc.ts.bySkill || []
                delegate: ColumnLayout {
                    required property var modelData
                    readonly property int n: modelData.correct + modelData.missed
                    Layout.fillWidth: true; Layout.preferredWidth: 1; spacing: 4
                    RowLayout { Layout.fillWidth: true
                        Text { text: modelData.label + " on tests"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true }
                        Text { text: n ? modelData.correct + " / " + n + " (" + modelData.pct + "%)" : "—"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.DemiBold } }
                    Rectangle { Layout.fillWidth: true; height: 8; radius: 4; color: Qt.rgba(1, 1, 1, 0.08)
                        Rectangle { width: n ? parent.width * modelData.correct / n : 0; height: 8; radius: 4; color: (modelData.pct || 0) >= 90 ? Theme.green : Theme.amber } }
                }
            }
        }
    }

    // ---------- what to work on next ----------
    ChartCard {
        title: "What to work on next"
        note: "Picked from your own answers: where you missed the most, what's fading, and what's ready to try for real."
        Text { visible: (pp.p.recommend || []).length === 0; text: "Nothing stands out yet. Keep going with today's session and suggestions will show up here as you practice."
               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Repeater {
            model: pp.p.recommend || []
            delegate: Rectangle {
                required property var modelData
                required property int index
                Layout.fillWidth: true
                implicitHeight: rr.implicitHeight + 24
                radius: 12
                color: index === 0 ? Theme.navActive : Qt.rgba(1, 1, 1, 0.03)
                border.color: index === 0 ? Qt.rgba(Theme.blue.r, Theme.blue.g, Theme.blue.b, 0.45) : Theme.borderSoft
                RowLayout {
                    id: rr
                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; leftMargin: 14; rightMargin: 14 }
                    spacing: 14
                    Rectangle { width: 40; height: 40; radius: 11; color: modelData.tint
                        Icon { anchors.centerIn: parent; name: modelData.icon; color: "white"; size: 20 } }
                    ColumnLayout { spacing: 2; Layout.fillWidth: true
                        Text { text: modelData.title; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        Text { text: modelData.why; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    PillButton { text: modelData.button; primary: index === 0; Layout.minimumWidth: 170
                                 onClicked: app.openRecommended(modelData.action) }
                }
            }
        }
    }

    // ---------- practice over time + mix ----------
    RowLayout {
        Layout.fillWidth: true; spacing: 14
        ChartCard {
            Layout.preferredWidth: 2
            title: "Practice per day"
            note: "Minutes of active practice over the last two weeks."
            BarChart { Layout.fillWidth: true; model: pp.c.daily || []; unit: ""; emptyText: "Your practice days will show up here." }
        }
        ChartCard {
            Layout.preferredWidth: 1
            title: "Where your practice goes"
            note: "Share of your answers by skill."
            RowLayout {
                spacing: 16; Layout.fillWidth: true
                DonutChart { hole: 0; segments: pp.c.mix || []; Layout.preferredWidth: 120; Layout.preferredHeight: 120 }
                Legend { items: pp.c.mix || []; percent: true; Layout.fillWidth: true }
            }
        }
    }

    // ---------- phrases, accuracy, reviews ----------
    RowLayout {
        Layout.fillWidth: true; spacing: 14
        ChartCard {
            Layout.preferredWidth: 1
            title: "Course phrases"
            note: "Across all 30 days."
            RowLayout {
                spacing: 16; Layout.fillWidth: true
                DonutChart {
                    segments: pp.c.phrases || []; Layout.preferredWidth: 120; Layout.preferredHeight: 120
                    centerText: String(pp.p.demonstrated || 0)
                }
                Legend { items: pp.c.phrases || []; Layout.fillWidth: true }
            }
        }
        ChartCard {
            Layout.preferredWidth: 1
            title: "Accuracy by skill"
            note: "Checked answers: correct vs missed."
            Repeater {
                model: pp.c.accuracy || []
                delegate: ColumnLayout {
                    required property var modelData
                    readonly property int n: modelData.correct + modelData.missed
                    spacing: 4; Layout.fillWidth: true
                    RowLayout { Layout.fillWidth: true
                        Text { text: modelData.label; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true }
                        Text { text: n ? modelData.correct + " / " + n : "—"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.DemiBold } }
                    Rectangle {
                        Layout.fillWidth: true; height: 8; radius: 4; color: Qt.rgba(1, 1, 1, 0.08)
                        Rectangle { width: n ? parent.width * modelData.correct / n : 0; height: 8; radius: 4; color: modelData.color }
                    }
                }
            }
        }
        ChartCard {
            Layout.preferredWidth: 1
            title: "Reviews coming up"
            note: (app.lib.reviewsScheduled || 0) + " phrases scheduled. Missed ones come back sooner."
            BarChart { Layout.fillWidth: true; implicitHeight: 150; model: pp.c.forecast || []; color: Theme.amber; emptyText: "No reviews in the next week." }
        }
    }

    // ---------- speaking + other areas ----------
    RowLayout {
        Layout.fillWidth: true; spacing: 14
        ChartCard {
            Layout.preferredWidth: 2
            title: "Pronunciation ratings"
            note: "Your rated takes over time (0–100, from Microsoft Azure). Your last 30 takes."
            LineChart { Layout.fillWidth: true; points: pp.c.speaking || []; color: Theme.coral
                        emptyText: "Say a phrase in a speaking exercise to see your ratings here." }
        }
        ChartCard {
            Layout.preferredWidth: 1
            title: "Everything you've finished"
            Repeater {
                model: [
                    { l: "30-day course", d: pp.p.completed || 0, t: pp.p.total || 30, col: Theme.blue },
                    { l: "Basics units", d: pp.c.basicsDone || 0, t: pp.c.basicsTotal || 0, col: Theme.green },
                    { l: "Vida Real scenarios", d: pp.c.vrDone || 0, t: pp.c.vrTotal || 0, col: Theme.coral }
                ]
                delegate: RowLayout {
                    required property var modelData
                    spacing: 14; Layout.fillWidth: true
                    DonutChart {
                        Layout.preferredWidth: 54; Layout.preferredHeight: 54; hole: 0.62
                        segments: [{ label: "done", value: modelData.d, color: modelData.col },
                                   { label: "left", value: Math.max(0, modelData.t - modelData.d), color: Qt.rgba(1, 1, 1, 0.16) }]
                    }
                    ColumnLayout { spacing: 1; Layout.fillWidth: true
                        Text { text: modelData.l; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                        Text { text: modelData.d + " of " + modelData.t; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 } }
                }
            }
        }
    }

    // ---------- skills ----------
    Text { text: "Skills"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold; Layout.topMargin: 6 }
    GridLayout {
        Layout.fillWidth: true
        columns: 2; columnSpacing: 14; rowSpacing: 14
        Repeater {
            model: pp.p.skills || []
            delegate: Card {
                required property var modelData
                Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: 96
                RowLayout {
                    anchors.fill: parent; anchors.margins: 18; spacing: 16
                    Rectangle { width: 46; height: 46; radius: 12; color: modelData.tint
                        Icon { anchors.centerIn: parent; name: modelData.icon; color: Theme.text; size: 22 } }
                    ColumnLayout { spacing: 3; Layout.fillWidth: true
                        Text { text: modelData.label; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.Medium }
                        Text { text: modelData.stateLabel; color: modelData.assessed > 0 ? Theme.text : Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }
                        Text { text: modelData.successful + " of " + modelData.assessed + " checked answers correct"
                               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                }
            }
        }
    }

    // ---------- end-of-day checks ----------
    ChartCard {
        title: "End-of-day checks"
        note: "Answered on your own, without hints. 70% or more counts as passed."
        Text { visible: (pp.p.exitScores || []).length === 0; text: "Your end-of-day checks will appear here."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }
        Flow {
            visible: (pp.p.exitScores || []).length > 0
            Layout.fillWidth: true; spacing: 10
            Repeater {
                model: pp.p.exitScores || []
                delegate: Column {
                    required property var modelData
                    readonly property real r: modelData.correct / Math.max(1, modelData.total)
                    spacing: 4
                    Rectangle {
                        width: 34; height: 90; radius: 6; color: Qt.rgba(1, 1, 1, 0.06)
                        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: parent.height * r; radius: 6
                                    color: r >= 0.7 ? Theme.green : Theme.amber }
                        Text { anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 4 } text: modelData.correct + "/" + modelData.total
                               color: Theme.text; font.family: Theme.sans; font.pixelSize: 10 }
                    }
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "D" + modelData.session; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 11 }
                    Accessible.role: Accessible.StaticText; Accessible.name: "Day " + modelData.session + ": " + modelData.correct + " of " + modelData.total
                }
            }
        }
    }
}
