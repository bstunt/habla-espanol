import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// End-of-day test: 30 questions, 90% to pass. Answers aren't marked until the end.
Item {
    id: dt
    readonly property var t: app.test || ({})
    readonly property var q: t.q || ({})
    property var chosen: []          // build: tiles picked, in order
    property bool confirmQuit: false
    focus: true

    // reset local state for each new question
    property int qKey: t.done ? -1 : (t.index === undefined ? -1 : t.index)
    onQKeyChanged: {
        chosen = (q.kind === "build" && Array.isArray(t.answer)) ? t.answer.slice() : []
        if (typeof typed !== "undefined" && typed) typed.text = (q.kind === "type" && t.answer) ? t.answer : ""
        if (q.kind === "type" && typed) typed.forceActiveFocus(); else dt.forceActiveFocus()
        if (q.audio && !q.show_text) audio.say(q.audio, false)
    }

    function canNext() {
        if (t.review) return false
        if (q.kind === "choice") return t.answer !== null && t.answer !== undefined
        if (q.kind === "build") return chosen.length > 0
        if (q.kind === "type") return typed.text.trim() !== ""
        return false
    }
    function next() {
        if (!canNext()) return
        if (q.kind === "build") app.testAnswer(chosen)
        if (q.kind === "type") { app.testAnswer(typed.text); if (app.test.review) return }
        app.testNext()
    }
    Keys.onReturnPressed: next()
    Keys.onEnterPressed: next()
    Keys.onPressed: (e) => {
        if (q.kind === "choice" && e.key >= Qt.Key_1 && e.key <= Qt.Key_4 && (e.key - Qt.Key_1) < (q.options || []).length) {
            app.testAnswer(e.key - Qt.Key_1); e.accepted = true
        }
    }

    Rectangle { anchors.fill: parent; color: Theme.bg }

    // ---------- top bar ----------
    RowLayout {
        id: bar
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 28; rightMargin: 28; topMargin: 22 }
        spacing: 16
        IconButton { iconName: t.done ? "arrow-left" : "x"; label: t.done ? "Back" : "Leave test"; iconColor: Theme.text
                     onClicked: t.done ? app.testQuit() : (dt.confirmQuit = true) }
        ColumnLayout { spacing: 0; Layout.fillWidth: true
            Text { text: "Day " + (t.day || "") + " test · " + (t.title || ""); color: Theme.text; font.family: Theme.serif; font.pixelSize: 24 }
            Text { text: (t.count || 30) + " questions · pass with " + (t.need || 27) + " or more (90%)"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 } }
        ColumnLayout { visible: !t.done; spacing: 5; Layout.preferredWidth: 300
            Text { text: "Question " + ((t.index || 0) + 1) + " of " + (t.count || 30); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.alignment: Qt.AlignRight }
            Rectangle { Layout.fillWidth: true; height: 8; radius: 4; color: Qt.rgba(1, 1, 1, 0.08)
                Rectangle { width: parent.width * ((t.answered || 0) / Math.max(1, t.count || 30)); height: 8; radius: 4; color: Theme.blue } } }
    }

    // ---------- a question ----------
    Flickable {
        visible: !t.done
        anchors { left: parent.left; right: parent.right; top: bar.bottom; bottom: foot.top; topMargin: 20; bottomMargin: 10 }
        contentWidth: width; contentHeight: qcol.implicitHeight + 20; clip: true; boundsBehavior: Flickable.StopAtBounds
        ColumnLayout {
            id: qcol
            width: Math.min(parent.width - 56, 820); x: (parent.width - width) / 2
            spacing: 16
            Text { text: q.prompt || ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 22; font.weight: Font.DemiBold; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            // audio and/or the Spanish shown
            RowLayout {
                visible: !!q.audio || !!q.extra
                spacing: 14; Layout.fillWidth: true
                RoundButton {
                    visible: !!q.audio
                    Layout.preferredWidth: 56; Layout.preferredHeight: 56; Accessible.name: "Play"
                    onClicked: audio.say(q.audio, false)
                    contentItem: Item { Icon { anchors.centerIn: parent; name: "volume-2"; color: Theme.onBlue; size: 26 } }
                    background: Rectangle { radius: 28; color: Theme.blue } }
                RoundButton {
                    visible: !!q.audio
                    Layout.preferredWidth: 46; Layout.preferredHeight: 46; Accessible.name: "Play slowly"
                    onClicked: audio.say(q.audio, true)
                    contentItem: Item { Icon { anchors.centerIn: parent; name: "snail"; color: Theme.text; size: 22 } }
                    background: Rectangle { radius: 23; color: Qt.rgba(1, 1, 1, 0.08) } }
                Text { visible: !!q.extra || (!!q.audio && !!q.show_text); text: q.extra || (q.show_text ? q.audio : "") || ""
                       color: Theme.text; font.family: Theme.serif; font.pixelSize: 30; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                Item { visible: !q.extra && !q.show_text; Layout.fillWidth: true }
            }

            // multiple choice
            ColumnLayout {
                visible: q.kind === "choice"
                spacing: 10; Layout.fillWidth: true
                Repeater {
                    model: q.kind === "choice" ? q.options : []
                    delegate: OptionButton {
                        required property var modelData
                        required property int index
                        Layout.fillWidth: true
                        text: modelData; keyHint: String(index + 1)
                        spanish: /[áéíóúñ¿¡]/i.test(modelData) || (q.prompt || "").indexOf("How do you say") === 0
                        background: Rectangle {
                            radius: 12
                            color: dt.t.answer === index ? Theme.navActive : (parent.hovered ? Theme.rowHover : Qt.rgba(1, 1, 1, 0.035))
                            border.color: dt.t.answer === index ? Theme.blue : (parent.visualFocus ? Theme.blue : Theme.border)
                            border.width: dt.t.answer === index ? 2 : 1 }
                        onClicked: app.testAnswer(index)
                    }
                }
            }

            // build the sentence
            ColumnLayout {
                visible: q.kind === "build"
                spacing: 12; Layout.fillWidth: true
                Rectangle {
                    Layout.fillWidth: true; implicitHeight: Math.max(64, picked.implicitHeight + 24); radius: 12
                    color: Qt.rgba(1, 1, 1, 0.03); border.color: Theme.border
                    Flow { id: picked; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 } spacing: 8
                        Repeater { model: dt.chosen
                            delegate: Rectangle { required property var modelData; required property int index
                                width: pt.implicitWidth + 24; height: 40; radius: 10; color: Theme.navActive; border.color: Theme.blue
                                Text { id: pt; anchors.centerIn: parent; text: modelData; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18 }
                                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                    onClicked: { var c = dt.chosen.slice(); c.splice(index, 1); dt.chosen = c } } } } }
                    Text { visible: dt.chosen.length === 0; anchors.centerIn: parent; text: "Tap the words in order"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 14 }
                }
                Flow { Layout.fillWidth: true; spacing: 8
                    Repeater { model: q.kind === "build" ? q.tiles : []
                        delegate: Rectangle { required property var modelData; required property int index
                            readonly property bool used: { var n = 0, m = 0; for (var i = 0; i < dt.chosen.length; i++) if (dt.chosen[i] === modelData) n++
                                                           for (var j = 0; j <= index; j++) if (q.tiles[j] === modelData) m++; return m <= n }
                            width: tt.implicitWidth + 24; height: 40; radius: 10; opacity: used ? 0.3 : 1
                            color: Qt.rgba(1, 1, 1, 0.05); border.color: Theme.border
                            Text { id: tt; anchors.centerIn: parent; text: modelData; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18 }
                            MouseArea { anchors.fill: parent; enabled: !parent.used; cursorShape: Qt.PointingHandCursor
                                onClicked: { var c = dt.chosen.slice(); c.push(modelData); dt.chosen = c } } } } }
                PillButton { visible: dt.chosen.length > 0; text: "Clear"; primary: false; implicitHeight: 36; onClicked: dt.chosen = [] }
            }

            // type it
            ColumnLayout {
                visible: q.kind === "type"
                spacing: 10; Layout.fillWidth: true
                TextField {
                    id: typed
                    Layout.fillWidth: true; Layout.preferredHeight: 52; leftPadding: 14
                    enabled: !dt.t.review
                    placeholderText: "Type your answer in Spanish"
                    color: Theme.text; font.family: Theme.serif; font.pixelSize: 20; placeholderTextColor: Theme.text3
                    background: Rectangle { radius: 12; color: Qt.rgba(1, 1, 1, 0.05); border.color: typed.activeFocus ? Theme.blue : Theme.border }
                    onAccepted: dt.next()
                    Accessible.name: "Your answer"
                }
                RowLayout { spacing: 6
                    Text { text: "Accents:"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                    Repeater { model: ["á", "é", "í", "ó", "ú", "ñ", "¿", "¡"]
                        delegate: Rectangle { required property var modelData
                            width: 32; height: 30; radius: 7; color: Qt.rgba(1, 1, 1, 0.05); border.color: Theme.border
                            Text { anchors.centerIn: parent; text: modelData; color: Theme.text; font.pixelSize: 15 }
                            MouseArea { anchors.fill: parent; onClicked: { typed.insert(typed.cursorPosition, modelData); typed.forceActiveFocus() } } } } }
                Text { visible: !!q.hint; text: "Starts like: " + (q.hint || ""); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                // not in the list of accepted answers: compare with the model
                Rectangle {
                    visible: !!dt.t.review
                    Layout.fillWidth: true; implicitHeight: rv.implicitHeight + 28; radius: 12
                    color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.1); border.color: Qt.rgba(Theme.amber.r, Theme.amber.g, Theme.amber.b, 0.4)
                    ColumnLayout { id: rv; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 } spacing: 8
                        Text { text: "Habla couldn't check that one. Compare it with this answer:"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                        Text { text: dt.t.review ? dt.t.review.model : ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 20; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        Text { text: "Be honest: does yours mean the same thing and is it correct Spanish?"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        RowLayout { spacing: 10
                            PillButton { text: "Yes, same meaning"; onClicked: { app.testSelfReview(true); app.testNext() } }
                            PillButton { text: "No, mine was wrong"; primary: false; onClicked: { app.testSelfReview(false); app.testNext() } } }
                    }
                }
            }
        }
    }

    // footer
    RowLayout {
        id: foot
        visible: !t.done
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 28; rightMargin: 28; bottomMargin: 22 }
        spacing: 12
        PillButton { text: "Previous"; primary: false; enabled: (t.index || 0) > 0 && !t.review; onClicked: app.testBack() }
        Item { Layout.fillWidth: true }
        Text { text: "No answers are marked until the end."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
        PillButton { text: (t.index || 0) + 1 >= (t.count || 30) ? "Finish test" : "Next"; enabled: dt.canNext(); onClicked: dt.next() }
    }

    // ---------- results ----------
    Flickable {
        visible: !!t.done
        anchors { left: parent.left; right: parent.right; top: bar.bottom; bottom: parent.bottom; topMargin: 20 }
        contentWidth: width; contentHeight: rcol.implicitHeight + 40; clip: true; boundsBehavior: Flickable.StopAtBounds
        ColumnLayout {
            id: rcol
            width: Math.min(parent.width - 56, 860); x: (parent.width - width) / 2
            spacing: 16
            Card {
                Layout.fillWidth: true; implicitHeight: sc.implicitHeight + 50
                ColumnLayout { id: sc; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 26 } spacing: 8
                    Text { text: t.passed ? "🎉" : "💪"; font.pixelSize: 48; Layout.alignment: Qt.AlignHCenter }
                    Text { text: (t.correct || 0) + " / " + (t.count || 30) + "  ·  " + (t.pct || 0) + "%"; color: t.passed ? Theme.green : Theme.amber
                           font.family: Theme.serif; font.pixelSize: 44; Layout.alignment: Qt.AlignHCenter }
                    Text { text: t.passed ? "Passed! Day " + t.day + " is done." : "Not yet. You need " + (t.need || 27) + " to pass."
                           color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold; Layout.alignment: Qt.AlignHCenter }
                    Text { text: t.passed ? (t.nextOpen ? "Day " + (t.day + 1) + " is open." : (t.nextLock ? t.nextLock + "." : ""))
                                          : "Retake it as many times as you like. Each try has new questions in a new order, with the choices shuffled."
                           color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                    Text { visible: !!t.best; text: t.best ? ("Best score: " + t.best.best + " / " + t.best.total + " · attempts: " + t.best.attempts) : ""
                           color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; Layout.alignment: Qt.AlignHCenter }
                    RowLayout { spacing: 12; Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 8
                        PillButton { visible: !t.passed; text: "Retake test"; iconName: "refresh-cw"; onClicked: app.startTest(t.day) }
                        PillButton { visible: !t.passed; text: "Redo Day " + t.day + " lessons"; primary: false; onClicked: { app.testQuit(); app.goTo("curso") } }
                        PillButton { visible: !!t.passed && !!t.nextOpen; text: "Start Day " + (t.day + 1); iconName: "play"; onClicked: { app.testQuit(); app.continueSession() } }
                        PillButton { text: "Back to Home"; primary: !!t.passed && !t.nextOpen; onClicked: app.testQuit() } }
                }
            }
            Text { visible: (t.misses || []).length > 0; text: "What you missed (" + (t.misses || []).length + ")"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; font.weight: Font.DemiBold }
            Repeater {
                model: t.misses || []
                delegate: Card {
                    required property var modelData
                    Layout.fillWidth: true; implicitHeight: mc.implicitHeight + 28
                    ColumnLayout { id: mc; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 } spacing: 4
                        Text { text: modelData.prompt + (modelData.extra ? "  " + modelData.extra : ""); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        RowLayout { spacing: 8; Layout.fillWidth: true
                            Icon { name: "circle-alert"; color: Theme.coral; size: 16 }
                            Text { text: modelData.yours; color: Theme.text; font.family: Theme.serif; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true; font.strikeout: true } }
                        RowLayout { spacing: 8; Layout.fillWidth: true
                            Icon { name: "circle-check"; color: Theme.green; size: 16 }
                            Text { text: modelData.right; color: Theme.text; font.family: Theme.serif; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                    }
                }
            }
        }
    }

    // leave mid-test
    Rectangle {
        visible: dt.confirmQuit
        anchors.fill: parent; color: Qt.rgba(0, 0, 0, 0.55)
        MouseArea { anchors.fill: parent; onClicked: dt.confirmQuit = false }
        Card {
            anchors.centerIn: parent; width: 440; height: lq.implicitHeight + 48; elevated: true
            MouseArea { anchors.fill: parent }
            ColumnLayout { id: lq; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 24 } spacing: 12
                Text { text: "Leave the test?"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold }
                Text { text: "This attempt won't count. Next time you'll get new questions."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                RowLayout { spacing: 10
                    PillButton { text: "Keep going"; onClicked: dt.confirmQuit = false }
                    PillButton { text: "Leave"; primary: false; onClicked: { dt.confirmQuit = false; app.testQuit() } } } }
        }
    }
}
