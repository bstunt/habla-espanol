import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Inicio. Every number and state on this screen comes from app.dash,
// which Python builds from the local database. Nothing is hardcoded.
Flickable {
    id: page
    readonly property var d: app.dash
    signal openSection(string key)
    // The layout is composed at the 1536x1024 design size (minus sidebar) and
    // scaled uniformly to fit smaller windows (down to 86%), so the composition
    // never reflows into a cramped mobile-like stack. Below that it scrolls.
    readonly property real designW: 1278
    readonly property real designH: 1010
    readonly property real fit: Math.min(1.0, width / designW)
    contentWidth: width
    contentHeight: Math.max(height, (content.implicitHeight + 28) * fit)
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    ScrollBar.vertical: ScrollBar { policy: page.contentHeight > page.height + 1 ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }

    // column widths derived from the 1536px design
    readonly property real gutter: Theme.gap
    // Fill whatever width the stage provides (wider screens get wider cards).
    readonly property real innerW: Math.max(designW, width / fit) - 2 * 16
    readonly property real colRight: Math.round(innerW * 0.305)
    readonly property real colLeft: innerW - colRight - gutter
    readonly property real colA: Math.round(colLeft * 0.575)
    readonly property real colB: colLeft - colA - gutter

    ColumnLayout {
        id: content
        x: 16 * page.fit
        y: 14
        width: page.innerW
        scale: page.fit
        transformOrigin: Item.TopLeft
        spacing: page.gutter

        // ---------- top band: greeting + hero | progress + motivation ----------
        RowLayout {
            spacing: page.gutter
            Layout.fillWidth: true

            ColumnLayout {
                Layout.preferredWidth: page.colLeft
                spacing: 14
                // greeting
                RowLayout {
                    spacing: 16
                    Layout.topMargin: 30; Layout.leftMargin: 8
                    Text { text: "👋"; font.pixelSize: 38 }
                    ColumnLayout {
                        spacing: 2
                        Text {
                            text: d.learnerName ? "Hi, " + d.learnerName : "Hi there"
                            color: Theme.text; font.family: Theme.serif; font.pixelSize: 36; font.weight: Font.Medium
                            Accessible.role: Accessible.Heading
                        }
                        Text { text: "Let's learn some Spanish."; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19 }
                    }
                    // first run: ask for a name (used in greetings and conversations)
                    RowLayout {
                        visible: !d.learnerName
                        spacing: 10
                        Layout.leftMargin: 24
                        TextField {
                            id: firstName
                            Layout.preferredWidth: 220; Layout.preferredHeight: 40
                            placeholderText: "What's your first name?"
                            color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; placeholderTextColor: Theme.text3
                            background: Rectangle { radius: 20; color: Qt.rgba(1, 1, 1, 0.06); border.color: firstName.activeFocus ? Theme.blue : Theme.border }
                            leftPadding: 16
                            onAccepted: if (text.trim()) app.setName(text.trim())
                        }
                        PillButton { text: "Save"; implicitWidth: 96; implicitHeight: 40; enabled: firstName.text.trim() !== ""; onClicked: app.setName(firstName.text.trim()) }
                    }
                }
                // hero
                Item {
                    id: hero
                    Layout.fillWidth: true
                    Layout.preferredHeight: 322
                    Layout.topMargin: 2
                    HeroArt { anchors.fill: parent }
                    Rectangle { anchors.fill: parent; radius: Theme.radius; color: "transparent"; border.color: Theme.borderSoft }
                    ColumnLayout {
                        anchors { left: parent.left; bottom: parent.bottom; leftMargin: 26; bottomMargin: 30 }
                        spacing: 6
                        width: parent.width * 0.55
                        Text { text: "Session " + d.sessionNo + " of " + d.total; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19 }
                        Text {
                            text: d.sessionTitle; color: Theme.text; font.family: Theme.serif; font.pixelSize: 42; font.weight: Font.DemiBold
                            Accessible.role: Accessible.Heading
                        }
                        Text { visible: d.sessionTitleEs !== ""; text: d.sessionTitleEs; color: Theme.text; opacity: 0.85; font.family: Theme.serif; font.italic: true; font.pixelSize: 18; Layout.topMargin: -4 }
                        Text { text: d.mission; color: Theme.text; font.family: Theme.serif; font.pixelSize: 18; wrapMode: Text.WordWrap; Layout.preferredWidth: 340; Layout.topMargin: 4 }
                        Rectangle {
                            visible: !!d.testDue
                            Layout.topMargin: 10
                            implicitWidth: testRow.implicitWidth + 24; implicitHeight: 34; radius: 17
                            color: Qt.rgba(0, 0, 0, 0.45)
                            RowLayout { id: testRow; anchors.centerIn: parent; spacing: 8
                                Icon { name: "list-checks"; color: Theme.text; size: 16 }
                                Text { text: "Pass the Day " + d.testDue + " test (90%) to open this day" + (d.testBest ? " · best " + d.testBest.best + "/" + d.testBest.total : "")
                                       color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold } }
                        }
                        Rectangle {
                            visible: !!d.locked && !d.testDue
                            Layout.topMargin: 10
                            implicitWidth: lockRow.implicitWidth + 24; implicitHeight: 34; radius: 17
                            color: Qt.rgba(0, 0, 0, 0.45)
                            RowLayout { id: lockRow; anchors.centerIn: parent; spacing: 8
                                Icon { name: "clock"; color: Theme.text; size: 16 }
                                Text { text: (d.lockLabel || "") + ". Today: Basics or review."; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold } }
                        }
                        RowLayout {
                            spacing: 12; Layout.topMargin: 14
                            PillButton { visible: !!d.testDue; text: "Take the Day " + d.testDue + " test"; iconName: "list-checks"; implicitWidth: 258; onClicked: app.startTest(d.testDue) }
                            PillButton { visible: !d.allDone && !d.locked && !d.testDue; text: d.resumeLabel; iconName: "play"; implicitWidth: 258; onClicked: app.continueSession() }
                            PillButton { visible: !d.allDone && d.locked && !d.testDue; text: "Practice Basics"; iconName: "shapes"; implicitWidth: 258; onClicked: page.openSection("basicos") }
                            PillButton { visible: d.allDone; text: "Practice with review"; iconName: "refresh-cw"; implicitWidth: 258; onClicked: page.openSection("revision") }
                            PillButton { text: "View course"; primary: false; implicitWidth: 158; onClicked: page.openSection("curso") }
                        }
                    }
                }
            }

            ColumnLayout {
                Layout.preferredWidth: page.colRight
                Layout.fillHeight: true          // bottom edge lines up with the hero
                spacing: page.gutter
                // progress
                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 138
                    Layout.topMargin: 48
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 20; spacing: 14
                        RowLayout {
                            Text { text: "Your progress"; color: Theme.text; font.family: Theme.sans; font.pixelSize: Theme.fsLg; font.weight: Font.DemiBold; Layout.fillWidth: true }
                            Text { text: d.progressPct + "%"; color: Theme.blue; font.family: Theme.sans; font.pixelSize: 14
                                   Accessible.name: d.completed + " of " + d.total + " sessions completed" }
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: 10; radius: 5; color: Qt.rgba(1, 1, 1, 0.12)
                            Rectangle { width: Math.max(parent.height, parent.width * d.progressPct / 100); visible: d.progressPct > 0; height: parent.height; radius: 5; color: Theme.blue }
                        }
                        RowLayout {
                            spacing: 8
                            Repeater {
                                model: d.dots
                                delegate: Rectangle {
                                    required property var modelData
                                    width: modelData.kind === "gap" ? 26 : 38; height: 38; radius: 19
                                    color: modelData.state === "current" ? Theme.blue : (modelData.state === "done" ? Theme.green : "transparent")
                                    border.color: modelData.kind === "gap" ? "transparent" : (modelData.state === "current" ? Qt.lighter(Theme.blue, 1.3) : Qt.rgba(1, 1, 1, 0.35))
                                    border.width: modelData.state === "current" ? 3 : 1.5
                                    Text { anchors.centerIn: parent; text: modelData.kind === "gap" ? "···" : (modelData.state === "done" ? "✓" : modelData.n)
                                           color: modelData.state === "current" ? Theme.onBlue : Theme.text; font.family: Theme.sans; font.pixelSize: 15 }
                                }
                            }
                        }
                    }
                }
                // carousel: random Spanish words and Mexican culture facts
                DiscoverCard {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    Layout.minimumHeight: 200
                }
            }
        }

        // ---------- bottom band: three columns ----------
        RowLayout {
            spacing: page.gutter
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignTop

            // column A: today's session
            Card {
                Layout.preferredWidth: page.colA
                Layout.preferredHeight: 518
                Layout.alignment: Qt.AlignTop
                ColumnLayout {
                    anchors.fill: parent; anchors.margins: 14; anchors.topMargin: 18; spacing: 8
                    readonly property bool redo: (d.doneDay || 0) > 0
                    RowLayout {
                        Layout.leftMargin: 12; Layout.rightMargin: 8; Layout.bottomMargin: parent.redo ? 0 : 6
                        Text { text: parent.parent.redo ? "Day " + d.doneDay + " · done" : "Today's session"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.DemiBold; Layout.fillWidth: true; Accessible.role: Accessible.Heading }
                        Icon { visible: parent.parent.redo; name: "circle-check"; color: Theme.green; size: 18 }
                        Icon { visible: !parent.parent.redo; name: "clock"; color: Theme.text2; size: 16 }
                        Text { visible: !parent.parent.redo; text: "About " + d.sessionMinutes + " minutes"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                    }
                    Text {
                        visible: parent.redo
                        Layout.leftMargin: 12; Layout.bottomMargin: 4; Layout.fillWidth: true; wrapMode: Text.WordWrap
                        text: "Click any lesson to do it again." + (d.locked ? " " + d.lockLabel + "." : "")
                        color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13
                    }
                    Repeater {
                        model: parent.redo ? d.doneModules : d.modules
                        delegate: ModuleRow {
                            required property var modelData
                            Layout.fillWidth: true
                            implicitHeight: (d.doneDay || 0) > 0 ? 54 : 58
                            number: modelData.no; title: modelData.title; desc: modelData.desc
                            minutes: modelData.minutes; iconName: modelData.icon
                            status: modelData.status; current: modelData.current
                            onClicked: (d.doneDay || 0) > 0 ? app.redoLesson(d.doneDay, modelData.no, "") : app.openModule(modelData.no)
                        }
                    }
                    Item { Layout.fillHeight: true }
                }
            }

            // column B: objectives + phrases
            ColumnLayout {
                Layout.preferredWidth: page.colB
                Layout.alignment: Qt.AlignTop
                spacing: page.gutter
                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 254
                    CardHeader { id: objH; x: 18; y: 18; width: parent.width - 36; title: "Session goals"; icon: "target" }
                    Column {
                        anchors { left: parent.left; top: objH.bottom; leftMargin: 18; topMargin: 12 }
                        width: parent.width - 36
                        spacing: 9
                        Repeater {
                            model: d.objectives
                            delegate: Row {
                                required property var modelData
                                spacing: 10
                                width: parent.width
                                Accessible.name: modelData.text + ": " + modelData.stateLabel
                                Rectangle {
                                    width: 20; height: 20; radius: 10
                                    color: modelData.state === "demonstrated" ? Theme.coral : "transparent"
                                    border.color: modelData.state === "pending" ? Qt.rgba(1, 1, 1, 0.35) : Theme.coral
                                    border.width: 2
                                    Text { anchors.centerIn: parent; visible: modelData.state !== "pending"; text: "✓"
                                           color: modelData.state === "demonstrated" ? Theme.text : Theme.coral; font.pixelSize: 11; font.weight: Font.Bold }
                                }
                                Text { text: modelData.text; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; width: parent.width - 30; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight }
                            }
                        }
                    }
                }
                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 250
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 14; anchors.topMargin: 16; spacing: 4
                        CardHeader { Layout.leftMargin: 4; Layout.fillWidth: true; title: "Key words and phrases"; trailing: "›"; trailingColor: Theme.text2; Layout.bottomMargin: 6; onTrailingClicked: page.openSection("vocabulario") }
                        Repeater {
                            model: d.phrases
                            delegate: Rectangle {
                                required property var modelData
                                required property int index
                                Layout.fillWidth: true; height: 30; radius: 6
                                color: index % 2 === 0 ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                                RowLayout {
                                    anchors.fill: parent; anchors.leftMargin: 10; anchors.rightMargin: 4; spacing: 8
                                    Text { text: modelData.es; color: Theme.text; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.Medium; Layout.preferredWidth: parent.width * 0.52; elide: Text.ElideRight }
                                    Text { text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12; Layout.fillWidth: true; elide: Text.ElideRight }
                                    IconButton {
                                        iconName: "volume-2"; iconSize: 15; implicitWidth: 24; implicitHeight: 26; iconColor: Theme.text
                                        label: "Play: " + modelData.es
                                        onClicked: app.say(modelData.es, false)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // column C: review + skills
            ColumnLayout {
                Layout.preferredWidth: page.colRight
                Layout.alignment: Qt.AlignTop
                spacing: page.gutter
                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 290
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 14; anchors.topMargin: 16; spacing: 8
                        CardHeader { Layout.leftMargin: 6; Layout.fillWidth: true; title: "Spaced review"; icon: "refresh-cw"; iconColor: Theme.amber; trailing: d.reviews.length ? "View all" : ""; Layout.bottomMargin: 4; onTrailingClicked: page.openSection("revision") }
                        Repeater {
                            model: d.reviews
                            delegate: Rectangle {
                                required property var modelData
                                Layout.fillWidth: true; height: 52; radius: 10; color: Qt.rgba(1, 1, 1, 0.035); border.color: Theme.borderSoft
                                RowLayout {
                                    anchors.fill: parent; anchors.margins: 8; spacing: 12
                                    Rectangle { width: 36; height: 36; radius: 9; color: modelData.tint
                                        Icon { anchors.centerIn: parent; name: modelData.icon; color: Theme.text; size: 18 } }
                                    ColumnLayout { spacing: 0; Layout.fillWidth: true
                                        Text { text: modelData.concept; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.Medium; Layout.fillWidth: true; elide: Text.ElideRight }
                                        Text { text: modelData.practice; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true; elide: Text.ElideRight } }
                                    Text { text: modelData.due; color: modelData.dueToday ? Theme.coral : Theme.amber; font.family: Theme.sans; font.pixelSize: 13 }
                                }
                            }
                        }
                        // honest empty state on first launch
                        ColumnLayout {
                            visible: d.reviews.length === 0
                            Layout.fillWidth: true; Layout.fillHeight: true
                            spacing: 8
                            Item { Layout.fillHeight: true }
                            Icon { name: "refresh-cw"; color: Theme.text3; size: 30; Layout.alignment: Qt.AlignHCenter }
                            Text { text: "No reviews scheduled yet."; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; Layout.alignment: Qt.AlignHCenter }
                            Text { text: "They'll appear once you practice\nyour first phrases."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; horizontalAlignment: Text.AlignHCenter; Layout.alignment: Qt.AlignHCenter }
                            Item { Layout.fillHeight: true }
                        }
                        Item { Layout.fillHeight: true; visible: d.reviews.length > 0 }
                    }
                }
                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 214
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 18; anchors.bottomMargin: 12; spacing: 8
                        CardHeader { Layout.fillWidth: true; title: "Progress by skill"; trailing: "View details"; Layout.bottomMargin: 2; onTrailingClicked: page.openSection("progreso") }
                        Repeater {
                            model: d.skills
                            delegate: RowLayout {
                                required property var modelData
                                Layout.fillWidth: true; spacing: 12
                                Accessible.name: modelData.label + ": " + modelData.stateLabel
                                Rectangle { width: 30; height: 30; radius: 8; color: modelData.tint
                                    Icon { anchors.centerIn: parent; name: modelData.icon; color: Theme.text; size: 16 } }
                                ColumnLayout { spacing: 1; Layout.fillWidth: true
                                    Text { text: modelData.label; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                                    Text { text: modelData.stateLabel; color: modelData.assessed ? Theme.text : Theme.text3; font.family: Theme.sans; font.pixelSize: 12; font.italic: !modelData.assessed; elide: Text.ElideRight; Layout.fillWidth: true }
                                }
                                Text { visible: modelData.count > 0; text: modelData.count + (modelData.count === 1 ? " record" : " records"); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12 }
                            }
                        }
                    }
                }
            }
        }
    }
}
