import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Dialogs
import "../components"

PageFrame {
    id: sp
    title: "Settings"; titleEs: "Configuración"
    property bool confirmReset: false
    property string exported: ""

    component Section: Card {
        id: sec
        default property alias inner: c.data
        property string heading
        Layout.fillWidth: true; implicitHeight: c.implicitHeight + hd.implicitHeight + 56
        Text { id: hd; x: 22; y: 20; text: sec.heading; color: Theme.text; font.family: Theme.sans; font.pixelSize: 18; font.weight: Font.DemiBold }
        ColumnLayout {
            id: c
            anchors { left: parent.left; right: parent.right; top: hd.bottom; margins: 22; topMargin: 12 }
            spacing: 12
        }
    }

    Section {
        heading: "Your name"
        Text { text: "Used in greetings and in conversations, where partners call you by name."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 }
        RowLayout {
            spacing: 12
            TextField {
                id: nameF
                leftPadding: 14; rightPadding: 14; verticalAlignment: TextInput.AlignVCenter
                Layout.preferredWidth: 320; Layout.preferredHeight: 44
                text: (app.lib.settings || {}).name || ""
                placeholderText: "Your first name"
                color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.05); border.color: nameF.activeFocus ? Theme.blue : Theme.border }
                onAccepted: app.setName(text)
            }
            PillButton { text: "Save"; implicitWidth: 110; onClicked: app.setName(nameF.text) }
        }
    }

    Section {
        heading: "Theme"
        Text { text: "Pick the colors Habla uses. Each one is named for a color of Mexico."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 }
        Flow {
            Layout.fillWidth: true
            spacing: 12
            Repeater {
                model: Theme.themeOrder
                delegate: ItemDelegate {
                    id: sw
                    required property var modelData
                    readonly property var th: Theme.themes[modelData]
                    readonly property bool on: Theme.themeName === modelData
                    width: 176; height: 112
                    focusPolicy: Qt.StrongFocus
                    Accessible.name: th.label + (on ? ", selected" : "")
                    Accessible.role: Accessible.RadioButton
                    onClicked: app.setTheme(modelData)
                    background: Rectangle {
                        radius: 14; color: sw.th.card
                        border.color: sw.on ? sw.th.secondary : (sw.visualFocus ? Theme.text : (sw.hovered ? Theme.border : Theme.borderSoft))
                        border.width: sw.on || sw.visualFocus ? 2 : 1
                    }
                    contentItem: Column {
                        spacing: 8
                        // mini preview: hero field with the theme's flags
                        Rectangle {
                            width: parent.width; height: 46; radius: 9
                            gradient: Gradient { orientation: Gradient.Horizontal
                                GradientStop { position: 0; color: sw.th.heroA } GradientStop { position: 1; color: sw.th.heroB } }
                            Row {
                                anchors { right: parent.right; top: parent.top; rightMargin: 8 }
                                spacing: 4
                                Repeater { model: sw.th.flags
                                    delegate: Rectangle { required property var modelData; width: 10; height: 13; color: modelData; radius: 1 } }
                            }
                            Rectangle { anchors { left: parent.left; bottom: parent.bottom; margins: 8 }
                                width: 46; height: 14; radius: 7; color: sw.th.primary }
                        }
                        Row {
                            spacing: 6
                            Text { text: sw.th.label; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold }
                            Text { visible: sw.on; text: "✓"; color: sw.th.secondary; font.pixelSize: 14; font.weight: Font.Bold }
                        }
                        Text { text: sw.th.es; color: Theme.spanishAccent; font.family: Theme.serif; font.italic: true; font.pixelSize: 12 }
                    }
                }
            }
        }
    }

    Section {
        heading: "Voices and pronunciation ratings (Microsoft Azure)"
        Text {
            text: "Natural Mexican Spanish voices come packed inside the app, so every lesson plays them offline with no key. "
                  + "An Azure Speech key is optional: add one (free tier) to get your pronunciation rated and your spoken replies written down, and to download the few lines that use your own name."
            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        Text {
            text: azure.have >= azure.needed && azure.needed > 0
                  ? "✓ All " + Number(azure.needed).toLocaleString(Qt.locale("en_US"), "f", 0) + " voice lines ready."
                  : Number(azure.have).toLocaleString(Qt.locale("en_US"), "f", 0) + " of " + Number(azure.needed).toLocaleString(Qt.locale("en_US"), "f", 0) + " voice lines ready."
            color: azure.have >= azure.needed && azure.needed > 0 ? Theme.green : Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold
        }

        // ---------- this month's Azure usage ----------
        Rectangle {
            Layout.fillWidth: true; Layout.topMargin: 4
            implicitHeight: useCol.implicitHeight + 32; radius: 12
            color: Qt.rgba(1, 1, 1, 0.03); border.color: Theme.borderSoft
            Component.onCompleted: azure.refreshUsage()
            ColumnLayout {
                id: useCol
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 }
                spacing: 12
                RowLayout { Layout.fillWidth: true
                    Text { text: "Azure free tier this month"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; Layout.fillWidth: true }
                    PillButton { text: "Refresh"; primary: false; iconName: "refresh-cw"; implicitHeight: 34; onClicked: azure.refreshUsage() } }
                Repeater {
                    model: [
                        { l: "Voices downloaded", used: azure.usedChars, free: azure.freeChars,
                          txt: Number(azure.usedChars).toLocaleString(Qt.locale("en_US"), "f", 0) + " of " + Number(azure.freeChars).toLocaleString(Qt.locale("en_US"), "f", 0) + " characters" },
                        { l: "Pronunciation ratings", used: azure.usedSttMinutes, free: azure.freeSttMinutes,
                          txt: Number(azure.usedSttMinutes).toLocaleString(Qt.locale("en_US"), "f", 1) + " of " + azure.freeSttMinutes + " minutes of audio" }
                    ]
                    delegate: ColumnLayout {
                        required property var modelData
                        readonly property real f: modelData.free > 0 ? Math.min(1, modelData.used / modelData.free) : 0
                        Layout.fillWidth: true; spacing: 5
                        RowLayout { Layout.fillWidth: true
                            Text { text: modelData.l; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; Layout.fillWidth: true }
                            Text { text: modelData.txt; color: Theme.text; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.DemiBold } }
                        Rectangle { Layout.fillWidth: true; height: 10; radius: 5; color: Qt.rgba(1, 1, 1, 0.08)
                            Rectangle { width: Math.max(f > 0 ? 6 : 0, parent.width * f); height: 10; radius: 5
                                        color: f >= 0.9 ? Theme.danger : (f >= 0.7 ? Theme.amber : Theme.green) } }
                        Text { text: Math.round((1 - f) * 100) + "% left"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                    }
                }
                Text {
                    text: "Counted by Habla on this Mac and reset on the 1st of each month."
                          + (azure.usageEstimated ? " Voices downloaded before this meter existed are estimated from the files' dates." : "")
                          + " Playing voices you've already downloaded is free. The free tier never charges you: if a limit is reached, Azure pauses until next month and Habla uses the Mac's voice meanwhile."
                    color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true
                }
            }
        }
        RowLayout {
            spacing: 12
            visible: !azure.running
            TextField {
                id: azKey
                leftPadding: 14; rightPadding: 14; verticalAlignment: TextInput.AlignVCenter
                Layout.preferredWidth: 330; Layout.preferredHeight: 42
                echoMode: TextInput.Password
                placeholderText: azure.hasSavedKey ? "Saved key in Keychain (leave empty to use it)" : "Azure Speech key"
                color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.05); border.color: azKey.activeFocus ? Theme.blue : Theme.border }
                Accessible.name: "Azure Speech key"
            }
            TextField {
                id: azRegion
                leftPadding: 14; rightPadding: 14; verticalAlignment: TextInput.AlignVCenter
                Layout.preferredWidth: 150; Layout.preferredHeight: 42
                text: azure.region
                placeholderText: "Region, e.g. westus2"
                color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.05); border.color: azRegion.activeFocus ? Theme.blue : Theme.border }
                Accessible.name: "Azure region"
            }
            HCheckBox { id: azRemember; checked: true; text: "Remember key" }
        }
        RowLayout {
            spacing: 12
            PillButton { visible: !azure.running; text: azure.have > 0 ? "Download remaining voices" : "Download voices"; iconName: "download"; implicitWidth: 270
                         enabled: azure.have < azure.needed; opacity: enabled ? 1 : 0.45
                         onClicked: { azure.start(azKey.text, azRegion.text, azRemember.checked); azKey.text = "" } }
            PillButton { visible: azure.running; text: "Pause download"; primary: false; implicitWidth: 200; onClicked: azure.cancel() }
            PillButton { visible: azure.hasSavedKey && !azure.running; text: "Forget saved key"; primary: false; implicitWidth: 190; onClicked: azure.forgetKey() }
        }
        Rectangle {
            visible: azure.running
            Layout.fillWidth: true; height: 8; radius: 4; color: Qt.rgba(1, 1, 1, 0.1)
            Rectangle { width: parent.width * azure.done / Math.max(1, azure.total); height: 8; radius: 4; color: Theme.blue }
        }
        Text { visible: azure.status !== ""; text: azure.status; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Text { visible: azure.error !== ""; text: azure.error; color: Theme.danger; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Text {
            text: "Need a key? Create a free Azure account, add a \"Speech\" resource on the Free (F0) tier, then copy Key 1 and the Region from its \"Keys and Endpoint\" page. "
                  + "The same key also transcribes and rates your speaking. Only lesson text (and your first name, in lines that use it) and what you say in speaking exercises are sent to Microsoft. The key is stored in your Mac's Keychain, never in Habla's files."
            color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
    }

    Section {
        heading: "ChatGPT checks (OpenAI)"
        Text {
            text: "Optional. In Conversation Lab, ChatGPT checks replies you write in your own words and tells you how a Mexican would say it. "
                  + "Without a key, you compare your reply with the model replies yourself. Get an API key at platform.openai.com (API credits are billed separately from a ChatGPT subscription; each check costs a fraction of a cent). "
                  + "Only the message and your reply are sent, as text. The key is stored in your Mac's Keychain."
            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        Text { text: lab.aiReady ? "✓ OpenAI key saved · model " + lab.aiModel : "No OpenAI key yet."
               color: lab.aiReady ? Theme.green : Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold }
        RowLayout {
            spacing: 12
            TextField {
                id: oaKey
                leftPadding: 14; rightPadding: 14; verticalAlignment: TextInput.AlignVCenter
                Layout.preferredWidth: 330; Layout.preferredHeight: 42
                echoMode: TextInput.Password
                placeholderText: lab.aiReady ? "Saved key in Keychain (leave empty to keep it)" : "OpenAI API key"
                color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.05); border.color: oaKey.activeFocus ? Theme.blue : Theme.border }
                Accessible.name: "OpenAI API key"
            }
            TextField {
                id: oaModel
                leftPadding: 14; rightPadding: 14; verticalAlignment: TextInput.AlignVCenter
                Layout.preferredWidth: 170; Layout.preferredHeight: 42
                text: lab.aiModel
                placeholderText: "Model"
                color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; placeholderTextColor: Theme.text3
                background: Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.05); border.color: oaModel.activeFocus ? Theme.blue : Theme.border }
                Accessible.name: "OpenAI model"
            }
            PillButton { text: "Save"; implicitHeight: 42; onClicked: { lab.setOpenAI(oaKey.text, oaModel.text); oaKey.text = "" } }
            PillButton { visible: lab.aiReady; text: "Forget key"; primary: false; implicitHeight: 42; onClicked: lab.forgetOpenAI() }
        }
        Text { visible: lab.aiReady; text: azure.aiCalls + " ChatGPT checks this month (" + Number(azure.aiTokens).toLocaleString(Qt.locale("en_US"), "f", 0) + " tokens). Check your balance at platform.openai.com."
               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    }

    Section {
        visible: updater.enabled
        heading: "Updates"
        Text { text: "Habla Español " + updater.current + " · checks for new versions automatically and asks before updating. Your progress is kept."
               color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        RowLayout { spacing: 12
            PillButton { text: updater.state === "checking" ? "Checking…" : "Check for updates"; iconName: "refresh-cw"; primary: false; enabled: updater.state !== "checking" && updater.state !== "downloading"; onClicked: updater.check() }
            PillButton { visible: updater.available; text: "Update to " + updater.latest; iconName: "download"; onClicked: updater.update() }
            Text { text: updater.state === "current" ? "✓ You have the latest version." : (updater.lastChecked ? "Last checked " + updater.lastChecked : "")
                   color: updater.state === "current" ? Theme.green : Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
        }
    }

    Section {
        heading: "Microphone"
        Text {
            text: audio.inputNames.length > 1
                  ? "Choose the microphone Habla listens with. Press Test and speak: the bar moves when that microphone hears you."
                  : "No microphone was found. Connect one, or check System Settings › Sound › Input."
            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        RowLayout {
            visible: audio.inputNames.length > 1
            spacing: 12
            HComboBox {
                id: micBox
                Layout.preferredWidth: 360
                model: audio.inputNames
                currentIndex: audio.inputIndex
                onActivated: (i) => audio.setInput(i)
                Accessible.name: "Microphone"
            }
            PillButton { text: audio.monitoring ? "Stop test" : "Test"; primary: false; iconName: "mic"; implicitWidth: 130
                         onClicked: audio.monitoring ? audio.stopMonitor() : audio.startMonitor() }
        }
        Rectangle {
            visible: audio.monitoring
            Layout.preferredWidth: 360; height: 10; radius: 5; color: Qt.rgba(1, 1, 1, 0.1)
            Rectangle { width: parent.width * audio.level; height: 10; radius: 5; color: audio.level > 0.05 ? Theme.green : Theme.text3
                        Behavior on width { NumberAnimation { duration: 80 } } }
        }
        Text { visible: audio.monitoring && audio.level < 0.02; text: "Not hearing anything yet. Speak, or try another microphone. If it stays empty, Habla may not have microphone permission yet."
               color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        HCheckBox {
            id: autoStopBox
            checked: audio.autoStop
            onToggled: audio.setAutoStop(checked)
            text: "Stop listening automatically when I finish speaking"
        }
        Text { visible: audio.inputMissing; text: "Your chosen microphone isn't connected, so Habla is using the Mac's default for now."
               color: Theme.amber; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        Component.onDestruction: audio.stopMonitor()
        onVisibleChanged: if (!visible) audio.stopMonitor()
    }

    Section {
        heading: "Spanish voice"
        Text {
            text: voice.available
                  ? "Used for any line that doesn't have a downloaded voice yet. Pick a Mexican Spanish (es-MX) voice if you have one. You can download more in System Settings › Accessibility › Spoken Content › System Voice › Manage Voices."
                  : "No Spanish voice was found on this Mac. Add one in System Settings › Accessibility › Spoken Content › System Voice › Manage Voices (look for Spanish (Mexico), e.g. Paulina), then reopen Habla."
            color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true
        }
        RowLayout {
            visible: voice.available
            spacing: 12
            HComboBox {
                id: vbox
                Layout.preferredWidth: 360
                model: voice.voiceNames
                currentIndex: Math.max(0, voice.voiceNames.indexOf(voice.currentVoice))
                onActivated: (i) => app.setVoice(voice.voiceNames[i])
            }
            PillButton { text: "Test"; primary: false; iconName: "play"; implicitWidth: 110; onClicked: app.say("Hola, ¿cómo estás? Me llamo Ana. Mucho gusto.", false) }
        }
        RowLayout {
            visible: voice.available
            spacing: 12
            Text { text: "Speed"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 }
            Slider { id: rateS; from: -0.5; to: 0.3; value: voice.rate; Layout.preferredWidth: 300; onMoved: app.setRate(value) }
            Text { text: rateS.value < -0.15 ? "Slower" : (rateS.value > 0.1 ? "Faster" : "Natural"); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
        }
    }

    Section {
        heading: "Your voice and privacy"
        Text { text: "Your progress stays on this Mac. In speaking exercises, what you say is sent to Microsoft Azure to transcribe and rate it, then deleted; Habla doesn't keep your voice."
                    + (((app.lib.settings || {}).recordings || 0) > 0 ? " " + (app.lib.settings || {}).recordings + " voice clips from an older version of Habla are still saved; you can delete them." : ""); color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        RowLayout {
            spacing: 12
            PillButton { text: "Delete old voice clips"; primary: false; iconName: "trash"; implicitWidth: 260; enabled: ((app.lib.settings || {}).recordings || 0) > 0; onClicked: app.deleteRecordings() }
            PillButton { text: "Export progress…"; primary: false; iconName: "download"; implicitWidth: 230; onClicked: saveDlg.open() }
        }
        Text { visible: sp.exported !== ""; text: "Saved to " + sp.exported; color: Theme.green; font.family: Theme.sans; font.pixelSize: 13; wrapMode: Text.WrapAnywhere; Layout.fillWidth: true }
    }

    Section {
        heading: "Start over"
        Text { text: "Erase all progress, answers and review history on this Mac. Your name and voice settings are kept."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        RowLayout {
            spacing: 12
            PillButton { visible: !sp.confirmReset; text: "Reset progress…"; primary: false; implicitWidth: 210; onClicked: sp.confirmReset = true }
            Text { visible: sp.confirmReset; text: "This can't be undone. Are you sure?"; color: Theme.danger; font.family: Theme.sans; font.pixelSize: 14 }
            PillButton { visible: sp.confirmReset; text: "Yes, erase everything"; implicitWidth: 240; onClicked: { app.resetProgress(); sp.confirmReset = false } }
            PillButton { visible: sp.confirmReset; text: "Cancel"; primary: false; implicitWidth: 120; onClicked: sp.confirmReset = false }
        }
    }

    FileDialog {
        id: saveDlg
        fileMode: FileDialog.SaveFile
        defaultSuffix: "habla"
        nameFilters: ["Habla progress (*.habla)"]
        onAccepted: sp.exported = app.exportProgress(selectedFile.toString())
    }
}
