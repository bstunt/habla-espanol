import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

PageFrame {
    id: vp
    title: "Vocabulary"; titleEs: "Vocabulario"
    subtitle: "Everything the course teaches, by session. Status comes from your own answers."
    property string q: ""
    function matches(it) {
        if (q === "") return true
        var s = (it.es + " " + it.en).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
        return s.indexOf(q.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")) >= 0
    }
    TextField {
        Layout.preferredWidth: 420; Layout.preferredHeight: 44
        placeholderText: "Search Spanish or English…"
        color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; placeholderTextColor: Theme.text3
        onTextChanged: vp.q = text
        background: Rectangle { radius: 22; color: Qt.rgba(1, 1, 1, 0.05); border.color: parent.activeFocus ? Theme.blue : Theme.border }
        leftPadding: 18
    }
    RowLayout {
        spacing: 18
        Repeater {
            model: [{ c: Theme.green, t: "Shown on your own" }, { c: Theme.amber, t: "Practiced" }, { c: Qt.rgba(1, 1, 1, 0.3), t: "Not yet" }]
            delegate: RowLayout { required property var modelData; spacing: 6
                Rectangle { width: 10; height: 10; radius: 5; color: modelData.c }
                Text { text: modelData.t; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13 } }
        }
    }
    Repeater {
        model: app.lib.vocab || []
        delegate: ColumnLayout {
            id: grp
            required property var modelData
            Layout.fillWidth: true
            spacing: 8
            visible: modelData.items.some(function (it) { return vp.matches(it) })
            Text { text: "Session " + modelData.no + " · " + modelData.title + (modelData.unlocked ? "" : "  (locked)"); color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13; font.weight: Font.DemiBold; Layout.topMargin: 6 }
            GridLayout {
                Layout.fillWidth: true
                columns: 2; columnSpacing: 10; rowSpacing: 8
                Repeater {
                    model: grp.modelData.items
                    delegate: Rectangle {
                        required property var modelData
                        visible: vp.matches(modelData)
                        Layout.fillWidth: true; implicitHeight: 54; radius: 10
                        color: Theme.card; border.color: Theme.borderSoft
                        opacity: grp.modelData.unlocked ? 1 : 0.5
                        RowLayout {
                            anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 8; spacing: 12
                            Rectangle { width: 10; height: 10; radius: 5
                                color: modelData.state === "demonstrated" ? Theme.green : (modelData.state === "practiced" ? Theme.amber : Qt.rgba(1, 1, 1, 0.3)) }
                            ColumnLayout { spacing: 0; Layout.fillWidth: true
                                Text { text: modelData.es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 17; elide: Text.ElideRight; Layout.fillWidth: true }
                                Text { text: modelData.en; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true } }
                            IconButton { iconName: "volume-2"; iconSize: 16; label: "Play " + modelData.es; onClicked: app.say(modelData.es, false) }
                        }
                    }
                }
            }
        }
    }
}
