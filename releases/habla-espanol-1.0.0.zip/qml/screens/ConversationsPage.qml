import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

PageFrame {
    title: "Conversations"; titleEs: "Conversaciones"
    subtitle: "Replay any conversation mission you've unlocked. Each one branches, so try different replies."
    Card {
        Layout.fillWidth: true; implicitHeight: liveRow.implicitHeight + 36; elevated: true
        RowLayout {
            id: liveRow
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 20 }
            spacing: 16
            Icon { name: "sparkles"; color: Theme.amber; size: 28 }
            ColumnLayout { spacing: 2; Layout.fillWidth: true
                Text { text: "Live conversation partner"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 17; font.weight: Font.DemiBold }
                Text { text: "Open-ended spoken practice with an AI partner, online. Not available yet."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
            Rectangle { radius: 10; color: Qt.rgba(1, 1, 1, 0.08); implicitWidth: soon.implicitWidth + 20; implicitHeight: 28
                Text { id: soon; anchors.centerIn: parent; text: "Coming soon"; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12 } }
        }
    }
    Repeater {
        model: app.lib.conversations || []
        delegate: Card {
            required property var modelData
            Layout.fillWidth: true; implicitHeight: row.implicitHeight + 32
            RowLayout {
                id: row
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 18 }
                spacing: 16
                Rectangle { width: 46; height: 46; radius: 23; color: Theme.coral
                    Text { anchors.centerIn: parent; text: (modelData.partner || "?").charAt(0).toUpperCase(); color: Theme.onCoral; font.family: Theme.sans; font.pixelSize: 19; font.weight: Font.Bold } }
                ColumnLayout { spacing: 3; Layout.fillWidth: true
                    Text { text: "Session " + modelData.session + " · " + modelData.title + " · with " + modelData.partner; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                    Text { text: modelData.goal; color: Theme.text; font.family: Theme.sans; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: modelData.setting; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                PillButton { text: modelData.practiced ? "Practice again" : "Practice"; primary: !modelData.practiced; implicitWidth: 170; onClicked: app.practiceExercise(modelData.id) }
            }
        }
    }
}
