import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "../components"

// Vida Real: practice conversations you'll actually have. Always open.
Item {
    id: vr
    readonly property var lib: app.lib.vidaReal || ({ categories: [], available: 0, total: 0 })
    property string level: ""          // "" | beginner | developing | intermediate
    property string skill: ""          // "" | listening | speaking | conversation
    property string show: "all"        // all | recommended | practiced
    property var picked: null          // scenario shown in the start panel
    onPickedChanged: if (picked) sheet.mode = picked.mode

    function visibleIn(sc) {
        if (level && sc.level !== level) return false
        if (skill && (sc.skills || []).indexOf(skill) < 0) return false
        if (show === "recommended" && !sc.recommended) return false
        if (show === "practiced" && !(sc.status === "completed" || sc.status === "in_progress")) return false
        return true
    }
    function count(cat) { var n = 0; for (var i = 0; i < cat.scenarios.length; i++) if (visibleIn(cat.scenarios[i])) n++; return n }

    PageFrame {
        id: frame
        anchors.fill: parent
        title: "Vida Real"; titleEs: "Practica para la vida real"
        subtitle: "Conversations you'll actually have. Learn the phrases, act it out, and handle what changes. Always open, and you can repeat any of them."

        // filters
        Flow {
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: [
                    { g: "show", v: "all", t: "All" }, { g: "show", v: "recommended", t: "Recommended for you" }, { g: "show", v: "practiced", t: "Practiced" },
                    { g: "sep" },
                    { g: "level", v: "beginner", t: "Beginner" }, { g: "level", v: "developing", t: "Developing" }, { g: "level", v: "intermediate", t: "Intermediate" },
                    { g: "sep" },
                    { g: "skill", v: "listening", t: "Listening" }, { g: "skill", v: "speaking", t: "Speaking" }, { g: "skill", v: "conversation", t: "Conversation" }
                ]
                delegate: Item {
                    required property var modelData
                    width: modelData.g === "sep" ? 10 : chip.width; height: 32
                    Rectangle {
                        id: chip
                        visible: modelData.g !== "sep"
                        readonly property bool on: modelData.g === "show" ? vr.show === modelData.v
                                                 : (modelData.g === "level" ? vr.level === modelData.v : vr.skill === modelData.v)
                        width: ct.implicitWidth + 26; height: 32; radius: 16
                        color: on ? Theme.navActive : "transparent"; border.color: on ? Theme.blue : Theme.border
                        Text { id: ct; anchors.centerIn: parent; text: modelData.t || ""; color: chip.on ? Theme.text : Theme.text2; font.family: Theme.sans; font.pixelSize: 13 }
                        MouseArea {
                            anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (modelData.g === "show") vr.show = modelData.v
                                else if (modelData.g === "level") vr.level = vr.level === modelData.v ? "" : modelData.v
                                else vr.skill = vr.skill === modelData.v ? "" : modelData.v
                            }
                        }
                        Accessible.role: Accessible.Button; Accessible.name: (modelData.t || "") + (on ? ", selected" : "")
                    }
                }
            }
        }
        Text { text: vr.lib.available + " of " + vr.lib.total + " scenarios ready. More are on the way."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }

        Repeater {
            model: vr.lib.categories
            delegate: ColumnLayout {
                id: catCol
                required property var modelData
                Layout.fillWidth: true
                spacing: 10
                visible: vr.count(modelData) > 0
                RowLayout {
                    spacing: 12; Layout.topMargin: 8
                    Text { text: catCol.modelData.emoji; font.pixelSize: 24 }
                    Text { text: catCol.modelData.title_es; color: Theme.text; font.family: Theme.serif; font.pixelSize: 24 }
                    Text { text: catCol.modelData.title + " · " + catCol.modelData.desc; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; Layout.alignment: Qt.AlignBaseline; elide: Text.ElideRight; Layout.fillWidth: true }
                }
                GridLayout {
                    Layout.fillWidth: true
                    columns: width > 880 ? 3 : 2
                    columnSpacing: 12; rowSpacing: 12
                    Repeater {
                        model: catCol.modelData.scenarios
                        delegate: ItemDelegate {
                            id: card
                            required property var modelData
                            visible: vr.visibleIn(modelData)
                            Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.preferredHeight: 128
                            enabled: modelData.available
                            focusPolicy: Qt.StrongFocus
                            Accessible.name: modelData.title + (modelData.available ? ", " + modelData.status : ", coming soon")
                            onClicked: vr.picked = modelData
                            background: Rectangle {
                                radius: Theme.radius
                                color: card.hovered && card.enabled ? Theme.rowHover : Theme.card
                                border.color: card.visualFocus ? Theme.blue : (card.modelData.recommended ? Qt.rgba(Theme.coral.r, Theme.coral.g, Theme.coral.b, 0.45) : Theme.borderSoft)
                                border.width: card.visualFocus ? 2 : 1
                                opacity: card.modelData.available ? 1 : 0.5
                            }
                            contentItem: ColumnLayout {
                                spacing: 4
                                RowLayout {
                                    spacing: 8
                                    Text { text: card.modelData.emoji; font.pixelSize: 22 }
                                    Item { Layout.fillWidth: true }
                                    Text { visible: !card.modelData.available; text: "Coming soon"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                                    Text { visible: card.modelData.recommended && card.modelData.status === "new"; text: "Recommended"; color: Theme.coral; font.family: Theme.sans; font.pixelSize: 12; font.weight: Font.DemiBold }
                                    Text { visible: card.modelData.status === "in_progress"; text: "In progress"; color: Theme.blue; font.family: Theme.sans; font.pixelSize: 12 }
                                    Icon { visible: card.modelData.status === "completed"; name: "circle-check"; color: Theme.green; size: 17 }
                                    Text { visible: card.modelData.timesCompleted > 1; text: "×" + card.modelData.timesCompleted; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                                }
                                Text { text: card.modelData.titleEs; color: Theme.text; font.family: Theme.serif; font.pixelSize: 19; elide: Text.ElideRight; Layout.fillWidth: true }
                                Text { text: card.modelData.title; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true }
                                Item { Layout.fillHeight: true }
                                Text {
                                    visible: card.modelData.available
                                    text: ({ beginner: "Beginner", developing: "Developing", intermediate: "Intermediate" })[card.modelData.level] + " · " + card.modelData.minutes + " min"
                                          + (card.modelData.recommendedAfter > 1 ? " · after Day " + card.modelData.recommendedAfter : "")
                                    color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12
                                }
                            }
                        }
                    }
                }
            }
        }
        Text {
            visible: { var n = 0; for (var i = 0; i < vr.lib.categories.length; i++) n += vr.count(vr.lib.categories[i]); return n === 0 }
            text: "Nothing matches these filters yet."; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 15
        }
    }

    // ---------- start panel ----------
    Rectangle {
        anchors.fill: parent
        visible: vr.picked !== null
        color: Qt.rgba(0, 0, 0, 0.55)
        MouseArea { anchors.fill: parent; onClicked: vr.picked = null }
        Keys.onEscapePressed: vr.picked = null
        Card {
            id: sheet
            anchors.centerIn: parent
            width: Math.min(parent.width - 80, 640)
            height: sheetCol.implicitHeight + 56
            elevated: true
            property string mode: "guided"
            MouseArea { anchors.fill: parent }        // keep clicks inside the panel
            ColumnLayout {
                id: sheetCol
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 28 }
                spacing: 12
                RowLayout {
                    spacing: 12; Layout.fillWidth: true
                    Text { text: vr.picked ? vr.picked.emoji : ""; font.pixelSize: 34 }
                    ColumnLayout { spacing: 0; Layout.fillWidth: true
                        Text { text: vr.picked ? vr.picked.titleEs : ""; color: Theme.text; font.family: Theme.serif; font.pixelSize: 28 }
                        Text { text: vr.picked ? vr.picked.title : ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14 } }
                    IconButton { iconName: "x"; label: "Close"; iconColor: Theme.text; onClicked: vr.picked = null }
                }
                Text { text: vr.picked ? vr.picked.setting : ""; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 14; font.italic: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                GridLayout {
                    columns: 2; columnSpacing: 14; rowSpacing: 6
                    Text { text: "Your goal"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                    Text { text: vr.picked ? vr.picked.goal : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: "You are"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                    Text { text: vr.picked ? vr.picked.yourRole : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: "Talking to"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                    Text { text: vr.picked ? vr.picked.theirRole : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                    Text { text: "About"; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 13 }
                    Text { text: vr.picked ? vr.picked.minutes + " minutes · 7 steps, from learning the phrases to handling a surprise" : ""; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                }
                Text { text: "How much help do you want?"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 15; font.weight: Font.DemiBold; Layout.topMargin: 6 }
                RowLayout {
                    spacing: 10; Layout.fillWidth: true
                    Repeater {
                        model: [
                            { v: "guided", t: "Guided", d: "English shown, suggested replies, slower audio." },
                            { v: "assisted", t: "Assisted", d: "Spanish first. Hints and English when you ask." },
                            { v: "independent", t: "Independent", d: "Audio first, no English. Like the real thing." }
                        ]
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool on: sheet.mode === modelData.v
                            Layout.fillWidth: true; Layout.preferredWidth: 1; implicitHeight: md.implicitHeight + 22; radius: 12
                            color: on ? Theme.navActive : Qt.rgba(1, 1, 1, 0.03); border.color: on ? Theme.blue : Theme.border; border.width: on ? 2 : 1
                            ColumnLayout { id: md; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 11 } spacing: 3
                                Text { text: modelData.t; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14; font.weight: Font.DemiBold }
                                Text { text: modelData.d; color: Theme.text2; font.family: Theme.sans; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true } }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: sheet.mode = modelData.v }
                            Accessible.role: Accessible.RadioButton; Accessible.name: modelData.t + ": " + modelData.d
                        }
                    }
                }
                Text { text: "You can pick a different level any time. It doesn't label you."; color: Theme.text3; font.family: Theme.sans; font.pixelSize: 12 }
                RowLayout {
                    spacing: 12; Layout.topMargin: 6
                    PillButton {
                        visible: !!(vr.picked && vr.picked.status === "in_progress")
                        text: "Continue"; iconName: "play"; implicitWidth: 180
                        onClicked: { var id = vr.picked.id; vr.picked = null; app.resumeScenario(id) }
                    }
                    PillButton {
                        text: vr.picked && vr.picked.status === "in_progress" ? "Start over" : (vr.picked && vr.picked.status === "completed" ? "Practice again" : "Practicar")
                        primary: !(vr.picked && vr.picked.status === "in_progress")
                        iconName: vr.picked && vr.picked.status === "in_progress" ? "" : "play"; implicitWidth: 190
                        onClicked: { var id = vr.picked.id; var m = sheet.mode; vr.picked = null; app.startScenario(id, m) }
                    }
                }
            }
        }
    }
}
