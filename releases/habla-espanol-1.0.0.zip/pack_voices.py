"""Pack the full Habla's Azure voices into this edition (run by the full Habla's
"Make Habla Español" button, or on first launch).  python pack_voices.py <src voices> <dest>"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from habla import bundle_voices as bv  # noqa: E402

if __name__ == "__main__":
    info = bv.import_voices(Path(sys.argv[1]), Path(sys.argv[2]), bv.all_lines(ROOT), log=lambda m: print(m, flush=True))
    print(json.dumps(info), flush=True)
