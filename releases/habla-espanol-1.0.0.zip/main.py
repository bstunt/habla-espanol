"""Habla Español — the gift edition of Habla (strictly learning Spanish).

Run:   python main.py
Flags: --demo           use a separate demo database with sample evidence
       --name NAME      set the learner's display name
       --audio-test     open straight into the listening/speaking lab
       --data-dir DIR   override where progress is stored
       --no-audio       skip all audio devices (headless/CI)
       --screenshot PNG render, save a screenshot and quit (fidelity checks)
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from PySide6.QtCore import QStandardPaths, QTimer, QUrl
from PySide6.QtGui import QFontDatabase, QGuiApplication, QIcon
from PySide6.QtQml import QQmlApplicationEngine


def base_dir() -> Path:
    # PyInstaller unpacks bundled files under sys._MEIPASS.
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--name")
    ap.add_argument("--audio-test", action="store_true")
    ap.add_argument("--data-dir")
    ap.add_argument("--no-audio", action="store_true")
    ap.add_argument("--screenshot")
    ap.add_argument("--screen", choices=["dashboard", "workspace"], default="dashboard")
    ap.add_argument("--exercise", help="open one exercise by id (testing)")
    ap.add_argument("--section", help="open a sidebar section (testing)")
    ap.add_argument("--delay", type=int, default=1200, help="screenshot delay (ms)")
    ap.add_argument("--size", default="1280x853",
                    help="Initial window size. The interface scales to fit any size (see Main.qml).")
    args, qt_args = ap.parse_known_args()

    APP_NAME = "Habla Español"
    QGuiApplication.setOrganizationName("Habla")      # read the full Habla's folder first (voice packing)
    QGuiApplication.setApplicationName("Habla")
    app = QGuiApplication([sys.argv[0], *qt_args])
    full_habla = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation))
    QGuiApplication.setOrganizationName(APP_NAME)
    QGuiApplication.setApplicationName(APP_NAME)

    root = base_dir()
    sys.path.insert(0, str(root))
    from habla.app import AppState, seed_demo
    from habla.audio import AudioController
    from habla.content import Curriculum
    from habla.db import Database
    from habla.icons import IconProvider, RoundedImageProvider

    app.setWindowIcon(QIcon(str(root / "assets" / "icon" / "habla_512.png")))
    for f in (root / "assets" / "fonts").glob("*.[ot]tf"):
        QFontDatabase.addApplicationFont(str(f))

    data = Path(args.data_dir) if args.data_dir else Path(
        QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation))
    if args.demo:
        data = data / "demo"
    data.mkdir(parents=True, exist_ok=True)

    cur = Curriculum.load(root / "content" / "v1" / "curriculum.json")
    fresh = not (data / "habla.db").exists()
    db = Database(data / "habla.db")
    if args.demo and fresh:
        seed_demo(db, cur)
    if args.name:
        db.set_display_name(args.name)

    from PySide6.QtCore import QSettings
    from habla.voice import Voice
    settings = QSettings()
    audio_on = not args.no_audio and os.environ.get("HABLA_NO_AUDIO") != "1"
    voice = Voice(enabled=audio_on, preferred=str(settings.value("voice", "") or ""),
                  rate=float(settings.value("rate", 0.0) or 0.0))
    bundled_voices = root / "assets" / "audio" / "voices"
    audio = AudioController(root / "assets" / "audio" / "reference", data / "recordings", enabled=audio_on, voice=voice,
                            voices_dir=data / "voices", settings=settings, bundled_dir=bundled_voices)
    state = AppState(db, cur, root / "assets", audio, voice=voice, demo=args.demo, settings=settings)
    from habla.content import load_basics
    basics = load_basics(root / "content" / "v1" / "basics.json")
    state.set_basics(basics)
    disc = root / "content" / "v1" / "discover.json"
    if disc.exists():
        import json as _json
        state.set_discover(_json.loads(disc.read_text(encoding="utf-8")))
    from habla.content import load_scenarios
    scen_manifest, scenarios = load_scenarios(root / "content" / "v1" / "scenarios")
    state.set_scenarios(scen_manifest, scenarios)
    from habla import usage
    usage.configure(data / "azure_usage.json")
    from habla.pronunciation import SpeechCheck
    speech = SpeechCheck(audio, data / "recordings", settings)
    state.attach_speech(speech)
    discover_lines = ["Hola, ¿cómo estás? Me llamo Ana. Mucho gusto."]       # Settings voice test
    try:
        import json as _j
        for w in _j.loads((root / "content" / "v1" / "discover.json").read_text(encoding="utf-8")).get("words", []):
            discover_lines.append(w.get("es", ""))          # Home carousel words
    except Exception:
        pass
    # Keys included by whoever made this copy: move them into this Mac's Keychain, then delete the file.
    gift_keys = root.parent / "gift_keys.json"
    if gift_keys.exists():
        try:
            import json as _kj
            from habla import azure_voices as _az, ai_replies as _ai
            k = _kj.loads(gift_keys.read_text(encoding="utf-8"))
            if k.get("azure_key") and not _az.keychain_get():
                _az.keychain_set(k["azure_key"])
                settings.setValue("azure_region", k.get("azure_region", "westus2"))
            if k.get("openai_key") and not _az.keychain_get(_ai.KEYCHAIN_SERVICE):
                _az.keychain_set(k["openai_key"], _ai.KEYCHAIN_SERVICE)
                settings.setValue("openai_model", k.get("openai_model", _ai.DEFAULT_MODEL))
            if _az.keychain_get() or not k.get("azure_key"):
                gift_keys.unlink()
        except Exception as e:
            print("gift keys:", e)
    from habla.lab import Lab, spanish_lines as lab_lines
    lab = Lab(root / "content" / "v1" / "lab", db, settings, cur.version)
    from habla.azure_voices import AzureVoices
    extra_lines = discover_lines + lab_lines(lab.content)
    # First launch on a Mac that has the full Habla: pack its Azure voices into this app.
    from habla import bundle_voices as bv
    if not bv.bundled(bundled_voices):
        src = next((d / "voices" for d in (full_habla, Path.home() / "Library" / "Application Support" / "Habla",
                                           Path.home() / "Library" / "Application Support" / "Habla" / "Habla")
                    if (d / "voices").is_dir()), None)
        if src is not None and src.resolve() != bundled_voices.resolve():
            bv.notify("Packing the voices into Habla Español… about a minute.")
            try:
                info = bv.import_voices(src, bundled_voices, bv.all_lines(root))
                bv.notify(f"Packed {info['voices']:,} voices. Habla Español is ready to share.")
            except Exception as e:  # never block the app over this
                print("bundle_voices failed:", e)
    azure = AzureVoices(cur, data / "voices", settings, lambda: db.learner()["display_name"], basics=basics,
                         scenarios=list(scenarios.values()), extra=extra_lines, bundled_dir=bundled_voices)

    engine = QQmlApplicationEngine()
    engine.addImageProvider("icon", IconProvider(root / "assets" / "icons"))
    engine.addImageProvider("rounded", RoundedImageProvider(root / "assets"))
    engine.rootContext().setContextProperty("app", state)
    engine.rootContext().setContextProperty("audio", audio)
    engine.rootContext().setContextProperty("voice", voice)
    engine.rootContext().setContextProperty("azure", azure)
    engine.rootContext().setContextProperty("speech", speech)
    engine.rootContext().setContextProperty("lab", lab)
    from habla.updater import Updater
    updater = Updater(root, settings, auto=not args.screenshot and not args.no_audio)
    engine.rootContext().setContextProperty("updater", updater)
    engine.load(QUrl.fromLocalFile(str(root / "qml" / "Main.qml")))
    if not engine.rootObjects():
        return 1
    win = engine.rootObjects()[0]
    w, h = (int(x) for x in args.size.split("x"))
    win.setWidth(w)
    win.setHeight(h)

    state.refreshLibrary()
    if args.audio_test:
        state.openModule(5)
    elif args.screen == "workspace":
        state.continueSession()
    elif args.exercise:
        state.practiceExercise(args.exercise)
    if args.section:
        engine.rootObjects()[0].setProperty("section", args.section)

    if args.screenshot:
        def grab():
            win.grabWindow().save(args.screenshot)
            app.quit()
        QTimer.singleShot(args.delay, grab)

    rc = app.exec()
    speech.shutdown()
    db.close()
    return rc


if __name__ == "__main__":
    sys.exit(main())
